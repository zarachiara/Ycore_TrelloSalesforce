#!/bin/bash

cp ~/.m2/repository/org/jacoco/org.jacoco.agent/0.7.1.201405082137/org.jacoco.agent-0.7.1.201405082137-runtime.jar lib/jacocoagent.jar
