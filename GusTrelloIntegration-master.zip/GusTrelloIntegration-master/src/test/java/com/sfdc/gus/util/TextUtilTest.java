package com.sfdc.gus.util;

import org.junit.Test;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import static org.junit.Assert.*;
import static org.hamcrest.Matchers.*;

import java.security.MessageDigest;

public class TextUtilTest {
    @Test
    public void isNullEmptyOrWhitespaceTest() {
        assertThat("Detects null", TextUtil.isNullEmptyOrWhitespace(null), is(true));
        assertThat("Detects only spaces", TextUtil.isNullEmptyOrWhitespace("          "), is(true));

        assertThat("Detects tabs and spaces", TextUtil.isNullEmptyOrWhitespace(" \t \t  \t\t"), is(true));
        assertThat("Detects newlines and return carriages", TextUtil.isNullEmptyOrWhitespace(" \t\r\n\n\r\n\n"), is(true));

        for (int ic=33; ic <= 126; ic++) {
            assertThat("Denies each ASCII character #" + ic + "(" + (char) ic + ")", TextUtil.isNullEmptyOrWhitespace(" " + (char) ic + " "), is(false));
        }
    }

    @Test
    public void getMD5HashTest() {
        assertThat("MD5 agrees with OSX's md5 command-line tool", TextUtil.getMD5Hash("testinghash"), is("369611a49efa3981ef4e5734e60bab51"));
        assertThat("MD5 works on a rediculously long string", TextUtil.getMD5Hash(
                    "haoesaoesntaonsehidanshodiunatoedusanhudisnaehudasnhudisnehudisnteudi-antudisnoehudiasntudiasehnodiasentudiosenuhdiesnuhisoetnudi"
                    + "haoesaoesntaonsehidanshodiunatoedusanhudisnaehudasnhudisnehudisnteudi-antudisnoehudiasntudiasehnodiasentudiosenuhdiesnuhisoetnudi"
                    + "haoesaoesntaonsehidanshodiunatoedusanhudisnaehudasnhudisnehudisnteudi-antudisnoehudiasntudiasehnodiasentudiosenuhdiesnuhisoetnudi"
                    + "haoesaoesntaonsehidanshodiunatoedusanhudisnaehudasnhudisnehudisnteudi-antudisnoehudiasntudiasehnodiasentudiosenuhdiesnuhisoetnudi"
                    + "haoesaoesntaonsehidanshodiunatoedusanhudisnaehudasnhudisnehudisnteudi-antudisnoehudiasntudiasehnodiasentudiosenuhdiesnuhisoetnudi"
                    + "haoesaoesntaonsehidanshodiunatoedusanhudisnaehudasnhudisnehudisnteudi-antudisnoehudiasntudiasehnodiasentudiosenuhdiesnuhisoetnudi"
                    + "haoesaoesntaonsehidanshodiunatoedusanhudisnaehudasnhudisnehudisnteudi-antudisnoehudiasntudiasehnodiasentudiosenuhdiesnuhisoetnudi"
                    + "haoesaoesntaonsehidanshodiunatoedusanhudisnaehudasnhudisnehudisnteudi-antudisnoehudiasntudiasehnodiasentudiosenuhdiesnuhisoetnudi"
                    + "haoesaoesntaonsehidanshodiunatoedusanhudisnaehudasnhudisnehudisnteudi-antudisnoehudiasntudiasehnodiasentudiosenuhdiesnuhisoetnudi"
                    + "haoesaoesntaonsehidanshodiunatoedusanhudisnaehudasnhudisnehudisnteudi-antudisnoehudiasntudiasehnodiasentudiosenuhdiesnuhisoetnudi"
                    + "haoesaoesntaonsehidanshodiunatoedusanhudisnaehudasnhudisnehudisnteudi-antudisnoehudiasntudiasehnodiasentudiosenuhdiesnuhisoetnudi"
                    + "haoesaoesntaonsehidanshodiunatoedusanhudisnaehudasnhudisnehudisnteudi-antudisnoehudiasntudiasehnodiasentudiosenuhdiesnuhisoetnudi"
                    + "haoesaoesntaonsehidanshodiunatoedusanhudisnaehudasnhudisnehudisnteudi-antudisnoehudiasntudiasehnodiasentudiosenuhdiesnuhisoetnudi"
                    + "haoesaoesntaonsehidanshodiunatoedusanhudisnaehudasnhudisnehudisnteudi-antudisnoehudiasntudiasehnodiasentudiosenuhdiesnuhisoetnudi"
                    + "haoesaoesntaonsehidanshodiunatoedusanhudisnaehudasnhudisnehudisnteudi-antudisnoehudiasntudiasehnodiasentudiosenuhdiesnuhisoetnudi"
                    + "haoesaoesntaonsehidanshodiunatoedusanhudisnaehudasnhudisnehudisnteudi-antudisnoehudiasntudiasehnodiasentudiosenuhdiesnuhisoetnudi"
                    + "haoesaoesntaonsehidanshodiunatoedusanhudisnaehudasnhudisnehudisnteudi-antudisnoehudiasntudiasehnodiasentudiosenuhdiesnuhisoetnudi"
                    + "haoesaoesntaonsehidanshodiunatoedusanhudisnaehudasnhudisnehudisnteudi-antudisnoehudiasntudiasehnodiasentudiosenuhdiesnuhisoetnudi"
                    + "haoesaoesntaonsehidanshodiunatoedusanhudisnaehudasnhudisnehudisnteudi-antudisnoehudiasntudiasehnodiasentudiosenuhdiesnuhisoetnudi"
                    + "haoesaoesntaonsehidanshodiunatoedusanhudisnaehudasnhudisnehudisnteudi-antudisnoehudiasntudiasehnodiasentudiosenuhdiesnuhisoetnudi"
                    + "haoesaoesntaonsehidanshodiunatoedusanhudisnaehudasnhudisnehudisnteudi-antudisnoehudiasntudiasehnodiasentudiosenuhdiesnuhisoetnudi"
                    + "haoesaoesntaonsehidanshodiunatoedusanhudisnaehudasnhudisnehudisnteudi-antudisnoehudiasntudiasehnodiasentudiosenuhdiesnuhisoetnudi"
                    + "haoesaoesntaonsehidanshodiunatoedusanhudisnaehudasnhudisnehudisnteudi-antudisnoehudiasntudiasehnodiasentudiosenuhdiesnuhisoetnudi"
                    + "haoesaoesntaonsehidanshodiunatoedusanhudisnaehudasnhudisnehudisnteudi-antudisnoehudiasntudiasehnodiasentudiosenuhdiesnuhisoetnudi"
                    + "haoesaoesntaonsehidanshodiunatoedusanhudisnaehudasnhudisnehudisnteudi-antudisnoehudiasntudiasehnodiasentudiosenuhdiesnuhisoetnudi"
                    + "haoesaoesntaonsehidanshodiunatoedusanhudisnaehudasnhudisnehudisnteudi-antudisnoehudiasntudiasehnodiasentudiosenuhdiesnuhisoetnudi"
                    + "haoesaoesntaonsehidanshodiunatoedusanhudisnaehudasnhudisnehudisnteudi-antudisnoehudiasntudiasehnodiasentudiosenuhdiesnuhisoetnudi"
                    + "haoesaoesntaonsehidanshodiunatoedusanhudisnaehudasnhudisnehudisnteudi-antudisnoehudiasntudiasehnodiasentudiosenuhdiesnuhisoetnudi"
                    + "haoesaoesntaonsehidanshodiunatoedusanhudisnaehudasnhudisnehudisnteudi-antudisnoehudiasntudiasehnodiasentudiosenuhdiesnuhisoetnudi"
                    + "haoesaoesntaonsehidanshodiunatoedusanhudisnaehudasnhudisnehudisnteudi-antudisnoehudiasntudiasehnodiasentudiosenuhdiesnuhisoetnudi"
                    ),
                    notNullValue());
    }

    @Test
    public void escapeStringTest() {
        assertThat("Return carriage becomes readable", TextUtil.escapeString("\r"), is("[\\r]"));
        assertThat("Newline becomes readable", TextUtil.escapeString("\n"), is("[\\n]"));
        assertThat("Tabs becomes readable", TextUtil.escapeString("\t"), is("[\\t]"));
        assertThat("Comination of multiple of many get replaced properly", TextUtil.escapeString("\r\r\n\n\t\t\r\n\t"), is("[\\r][\\r][\\n][\\n][\\t][\\t][\\r][\\n][\\t]"));
        assertThat("Comination of multiple of many get replaced properly with other letters interspersed", TextUtil.escapeString("a\rb\rc\nd\ne\tf\tg\rh\ni\tj"), is("a[\\r]b[\\r]c[\\n]d[\\n]e[\\t]f[\\t]g[\\r]h[\\n]i[\\t]j"));
    }
}
