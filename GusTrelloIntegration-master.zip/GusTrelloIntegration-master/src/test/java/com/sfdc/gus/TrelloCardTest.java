package com.sfdc.gus;

import static org.junit.Assert.*;
import org.junit.Test;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Map;

public class TrelloCardTest {

    @Test
    public void testConstructors() {
        try {
            JSONObject json = new JSONObject("{\"name\":\"test card:5\",\"desc\":\"Description\\n"+GusContext.GUS_ENDPOINT+"/aoeu\",\"id\":\"1\"}");
            TrelloCard tc = new TrelloCard(json);
            assertTrue(tc.id.equals("1"));
            assertTrue(tc.points == 5);
            assertTrue(tc.name.equals("test card"));
            assertTrue(tc.desc.contains("Description"));
            assertTrue(tc.gusWorkItemUrl.equals(GusContext.GUS_ENDPOINT+"/aoeu"));
            assertTrue(tc.gusId.equals("aoeu"));

            GusWorkItem gwi = new GusWorkItem(new JSONObject("{\"Id\":\"1\",\"Subject__c\":\"New Card\",\"Details__c\":\"New Description\"}"));

            tc = new TrelloCard(gwi);
            assertTrue(tc.gusId.equals("1"));
            assertTrue(tc.name.equals("New Card"));
            assertTrue(tc.desc.contains("New Description"));
            assertTrue(tc.desc.contains(GusContext.GUS_ENDPOINT + "/1"));

            assertTrue(tc.equals(gwi));
            assertFalse(tc.same(gwi));
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false);
        }
    }

    // for code coverage, we run all of the getters
    @Test
    public void runGetters() {
        try {
            JSONObject json = new JSONObject("{\"name\":\"test card:5\",\"desc\":\"Description\\n"+GusContext.GUS_ENDPOINT+"/aoeu\",\"id\":\"1\"}");
            TrelloCard tc = new TrelloCard(json);

            tc.getName();
            tc.getId();
            tc.getDesc();
            tc.getPoints();
            tc.getGusId();
            tc.getGusWorkItemUrl();
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false);
        }
    }

    @Test
    public void testSetters() {
        try {
            JSONObject json = new JSONObject("{\"name\":\"test card:5\",\"desc\":\"Description\\n"+GusContext.GUS_ENDPOINT+"/aoeu\",\"id\":\"1\"}");
            TrelloCard tc = new TrelloCard(json);

            assertTrue(tc.gusId.equals("aoeu"));
            tc.setGusId("2");
            assertTrue(tc.gusId.equals("2"));

            tc.setName("other name");
            Map<String, String> changes = tc.getChangedValuesMap();
            assertNotNull(changes);
            assertTrue(changes.containsKey("name"));
            assertTrue(changes.get("name").equals("other name"));

            tc.setDesc("other desc");
            assertTrue(changes.containsKey("desc"));
            assertTrue(changes.get("desc").equals("other desc"));

            String oldDesc = tc.desc;
            tc.setGusWorkItemUrl("aoeu");
            assertTrue(tc.desc.equals(oldDesc + "\r\naoeu\r\n"));

            tc.desc = "";
            tc.setGusWorkItemUrl("aoeu");
            assertTrue(tc.desc.equals("aoeu"));

            assertTrue(tc.getGusWorkItemUrl() != null && tc.getGusWorkItemUrl().length() > 0);
            assertTrue(tc.hasGusWorkItem());
            tc.gusWorkItemUrl = "";
            assertFalse(tc.hasGusWorkItem());
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false);
        }
    }

    @Test
    public void testUpdateDesc() {
        try {
            JSONObject json = new JSONObject("{\"name\":\"test card:5\",\"desc\":\"Description\\n"+GusContext.GUS_ENDPOINT+"/aoeu\",\"id\":\"1\"}");
            TrelloCard tc = new TrelloCard(json);

            assertTrue(tc != null);
            assertTrue(tc.oldHash == null);
            assertFalse(tc.desc.contains("Hash: "));
            tc.updateDesc();
            assertTrue(tc.desc.contains("Hash: "));

            String oldHash = "";
            int idx = tc.desc.indexOf("Hash: ");
            if(idx > -1) {
                oldHash = tc.desc.substring(idx + 6, idx + 6 + 32);
            }

            assertTrue(oldHash.length() == 32);
            tc.setDesc("other description");
            tc.updateDesc();
            assertTrue(tc.desc.contains("Hash: "));

            String newHash = "";
            idx = tc.desc.indexOf("Hash: ");
            if(idx > -1) {
                newHash = tc.desc.substring(idx + 6, idx + 6 + 32);
            }

            assertTrue(newHash.length() == 32);
            assertFalse(newHash.equals(oldHash));

        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false);
        }
    }

    @Test
    public void testIsChangedToString() {
        try {
            JSONObject json = new JSONObject("{\"name\":\"test card:5\",\"desc\":\"Description\\n"+GusContext.GUS_ENDPOINT+"/aoeu\",\"id\":\"1\"}");
            TrelloCard tc = new TrelloCard(json);

            tc.updateDesc();
            int idx = tc.desc.indexOf("Hash: ");
            if(idx > -1) {
                tc.oldHash = tc.desc.substring(idx + 6, idx + 6 + 32);
            }

            assertFalse(tc.isChanged());
            tc.setName("new name");
            assertTrue(tc.isChanged());

            String str = tc.toString();
            assertTrue(str.contains("{Card Id: 1"));
            assertTrue(str.contains(", Name: new name"));

            String query = tc.getCreateQuery();
            assertTrue(query.contains("&name=new%20name"));
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false);
        }
    }
}