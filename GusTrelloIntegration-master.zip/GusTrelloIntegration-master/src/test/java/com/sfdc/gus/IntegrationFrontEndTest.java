package com.sfdc.gus;

import static org.junit.Assert.*;
import static org.hamcrest.Matchers.*;

import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import spark.Spark;

import java.io.IOException;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringWriter;
import java.io.Writer;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.net.URI;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;

import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.security.cert.X509Certificate;
import javax.net.ssl.SSLContext;
import java.security.SecureRandom;
import javax.net.ssl.HttpsURLConnection;

import org.apache.http.HttpEntityEnclosingRequest;
import org.apache.http.HttpResponse;
import org.apache.http.HttpRequest;
import org.apache.http.Header;
import org.apache.http.NameValuePair;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.protocol.HttpContext;

import org.apache.http.entity.StringEntity;
import org.apache.http.client.CookieStore;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.client.utils.URLEncodedUtils;
import org.apache.http.impl.client.BasicCookieStore;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.message.BasicNameValuePair;

import com.sfdc.gus.ProjectThread;
import com.sfdc.gus.config.DatabaseHelper;
import com.sfdc.gus.config.ProjectConfig;
import com.sfdc.gus.http.Utf8ResponseHandler;
import com.sfdc.gus.testHelpers.MockGus;
import com.sfdc.gus.testHelpers.MockTrello;
import com.sfdc.gus.security.AESDualCrypt;

public class IntegrationFrontEndTest {

    private static class UrlResponse {
        public Map<String, List<String>> headers;
        private String body;
        private int status;
        private HttpResponse rawResponse;

        public String toString() {
            return "{status="+status+", headers="+headers+", body="+body+"}";
        }
    }

    private static DatabaseHelper db = null;
    private static SessionFactory sf = null;
    private static IntegrationFrontEnd ife = null;
    private static MockGus mg = null;
    private static MockTrello mockTrello = null;

    private final String un = "test_user";
    private final String pw = "test_password";
    private final String tok = "test_accessToken";

    @AfterClass
    public static void takedown() {
        ife.stop();
        mg.stop();
        mockTrello.stop();

        for(ProjectConfig pc : db.getAllProjectConfigs()) {
            db.deleteUser(pc);
        }
        db.close();
    }

    @BeforeClass
    public static void setup() {
        // We already test ProjectThreads, have any spawned from this end themselves
        ProjectThread.globalkeepalive = false;
        sf = createSessionFactory();
        db = createDBHelper(sf);
        AESDualCrypt crypter = new AESDualCrypt("12345abcdefg");

        mg = new MockGus();
        mg.run();

        mockTrello = new MockTrello();
        mockTrello.run();

        ife = new IntegrationFrontEnd(sf, crypter);
        ife.run();

        try {
            // Need the server to finish setting up
            Thread.sleep(1000);
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Make sure a Trello API Key is set. Otherwise, we'll get errors upon a user's login
        db.setGlobalProperty("appkey", crypter.encrypt("test_APIKey"));

    }

    private static SessionFactory createSessionFactory() {
        SessionFactory sessionFactory = null;
        try {
            Configuration hbcfg = new Configuration()
                        .configure(); // configures settings from hibernate.cfg.xml

            ServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder().applySettings(hbcfg.getProperties()).build();

            if (! hbcfg.getProperty("hibernate.connection.url").contains("test")) {
                // This is junit. We want to be in the testing environment. If test isn't in the database name, prevent any tests from changing the DB
                System.err.println("junit tests must be ran as the test profile. Please run 'lein with-profile test junit' instead");
                sessionFactory = null;
            } else {
                sessionFactory = hbcfg.buildSessionFactory(serviceRegistry);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return sessionFactory;
    }

    private static DatabaseHelper createDBHelper(SessionFactory sessFac) {
        if (sessFac != null) {
            return new DatabaseHelper(sessFac);
        } else {
            return null;
        }
    }

    private static UrlResponse doMethod(String requestMethod, int port, String path, String body, Map<String, String> params) {
        return doMethod(requestMethod, port, path, body, params, null, true);
    }

    private static UrlResponse doMethod(String requestMethod, int port, String path, String body, Map<String, String> params, boolean use_https) {
        return doMethod(requestMethod, port, path, body, params, null, use_https);
    }
    private static UrlResponse doMethod(String requestMethod, int port, String path, String body, Map<String, String> params, CookieStore cookies) {
        return doMethod(requestMethod, port, path, body, params, cookies, true);
    }
    private static UrlResponse doMethod(String requestMethod, int port, String path, String body, Map<String, String> params, CookieStore cookies, boolean use_https) {
        UrlResponse response = new UrlResponse();
        try {
            getResponse(requestMethod, port, path, body, response, params, cookies, use_https);
        } catch (IOException e) {
            e.printStackTrace();
        }

        return response;
    }

    private static CloseableHttpClient buildHttpClient(boolean use_https) { 
        // System.out.println("https is " + use_https);
        // if(!use_https) 
        //     return HttpClientBuilder.create().build(); 
        // Create a trust manager that does not validate certificate chains
        TrustManager[] trustAllCerts = new TrustManager[]{new X509TrustManager(){
            public X509Certificate[] getAcceptedIssuers(){return new X509Certificate[0];}
            public void checkClientTrusted(X509Certificate[] certs, String authType){}
            public void checkServerTrusted(X509Certificate[] certs, String authType){}
        }};

        // Install the all-trusting trust manager
        try {
            SSLContext sc = SSLContext.getInstance("TLS");
            sc.init(null, trustAllCerts, new SecureRandom());
            return HttpClientBuilder.create().setSslcontext(sc).build(); 
            //HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
        } catch (Exception e) {
            ;
        }
        return null;
    }
    
    private static CloseableHttpClient buildHttpClient(CookieStore cookies, boolean use_https) { 
        // System.out.println("https is " + use_https);
        // if(!use_https) 
        //     return HttpClientBuilder.create().setDefaultCookieStore(cookies).build(); 
        // Create a trust manager that does not validate certificate chains
        TrustManager[] trustAllCerts = new TrustManager[]{new X509TrustManager(){
            public X509Certificate[] getAcceptedIssuers(){return null;}
            public void checkClientTrusted(X509Certificate[] certs, String authType){}
            public void checkServerTrusted(X509Certificate[] certs, String authType){}
        }};

        // Install the all-trusting trust manager
        try {
            SSLContext sc = SSLContext.getInstance("TLS");
            sc.init(null, trustAllCerts, new SecureRandom());
            return HttpClientBuilder.create().setSslcontext(sc).setDefaultCookieStore(cookies).build(); 
            //HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
        } catch (Exception e) {
            ;
        }
        return null;
    }

    private static void getResponse(String requestMethod, int port, String path, String body, UrlResponse response, Map<String, String> params, CookieStore cookies, boolean use_https)
            throws MalformedURLException, IOException, ProtocolException {

        List<NameValuePair> paramsNVP = convertMapToNVP(params);

        CloseableHttpClient httpClient;
        if (cookies == null)
            httpClient = buildHttpClient(use_https);
        else
            httpClient = buildHttpClient(cookies, use_https);
        // HttpUriRequest req = new HttpPost("http://localhost:" + port + path);
        URI uri = null;
        try {
            uri = new URIBuilder().setScheme((use_https ? "https" : "http"))
                .setHost("localhost")
                .setPort(port)
                .setPath(path)
                .setParameters(paramsNVP)
                .build();
        } catch (Exception e) {
            e.printStackTrace();
        }

        HttpUriRequest req = null;

        switch (requestMethod) {
            default:
            case "GET":
                req = new HttpGet(uri);
                break;
            case "POST":
                HttpPost postReq = new HttpPost(uri);

                if (body != null)
                    postReq.setEntity(new StringEntity(body));
                req = postReq;
                break;
        }

        HttpResponse res = httpClient.execute(req);

        // Fallback to the HttpResponse to get any and all possible return things
        response.rawResponse = res;
        // Note: We are trusting that the Utf8 Response Handler works
        response.body = new Utf8ResponseHandler().handleResponse(res);
        response.status = res.getStatusLine().getStatusCode();

        response.headers = new HashMap<String, List<String>>();
        for (Header h : res.getAllHeaders()) {
            response.headers.put(h.getName(), Arrays.asList(h.getValue().split(",")));
        }
    }

    private static String toString(InputStream input) throws IOException {
        StringWriter sw = new StringWriter();
        InputStreamReader in = new InputStreamReader(input);
        copyLarge(in, sw);
        return sw.toString();
    }

    public static long copyLarge(Reader input, Writer output) throws IOException {
        char[] buffer = new char[1024 * 4];
        long count = 0;
        int n = 0;
        while (-1 != (n = input.read(buffer))) {
            output.write(buffer, 0, n);
            count += n;
        }
        return count;
    }

    // Used by many tests. see testCreateDeleteAccount for the tests behind this
    // note that the dependancy may cause a failure in testCreateDeleteAccount to fail other tests without much warning
    private CookieStore createTestAccount() {
        // Perform OAuth with the mockgus

        Map<String,String> params = new HashMap<String,String>();
        // params.put("gus_username", un);
        // params.put("gus_password", pw);
        params.put("trello_token", tok);
        CookieStore cookies = new BasicCookieStore();
        UrlResponse r = doMethod("GET", 7757, "/first_token", null, null, cookies, false);
        assertTrue(db.getAllProjectConfigs().size() == 0);
        UrlResponse resp = doMethod("POST", 4567, "/new", null, params, cookies);
        assertThat("Creating a new account should be successful", resp.status, is(302));
        assertTrue(db.getAllProjectConfigs().size() == 1);
        return cookies;
    }

    private void deleteTestAccount(CookieStore cookies) {
        Map<String, String> params = new HashMap<String, String>();
        params.put("action", "delete_profile");
        String body = URLEncodedUtils.format(convertMapToNVP(params), "UTF-8");
        assertTrue("Should be 1 user, was actually " + db.getAllProjectConfigs().size(), db.getAllProjectConfigs().size() == 1);
        UrlResponse res = doMethod("POST", 4567, "/ajax_endpoint", body, null, cookies);;
        assertTrue("Should be 0 user, was actually " + db.getAllProjectConfigs().size(), db.getAllProjectConfigs().size() == 0);
        assertTrue(res != null);
        assertTrue(res.body != null);
        assertTrue(res.body.equals("{ \"result\":\"success\" }"));
        
    }

    public static List<NameValuePair> convertMapToNVP(Map<String, String> params) {
        List<NameValuePair> paramsNVP = new ArrayList<NameValuePair>();
        if (params != null) {
            for (Map.Entry<String, String> e : params.entrySet()) {
                paramsNVP.add(new BasicNameValuePair(e.getKey(), e.getValue()));
            }
        }
        return paramsNVP;
    }

    @Test
    public void testIndex() {
        UrlResponse res = doMethod("GET", 4567, "/", null, null);
        // System.out.println(res);
        assertTrue(res!=null);
        assertTrue(res.body != null);
        assertTrue("Return status should be 200, was "+res.status, res.status == 200);
        assertTrue("Response should include <title>Gus Trello Integrator</title>", res.body.contains("<title>Gus Trello Integrator</title>"));
    }

    @Test
    public void testForm() {
        UrlResponse res = doMethod("GET", 4567, "/form", null, null);
        assertTrue(res != null);
        assertTrue(res.body != null);
        assertTrue("Return status should be 200, was "+res.status, res.status == 200);
        assertTrue("Response should include <script src=\"/js/form.js\"></script>", res.body.contains("<script src=\"/js/form.js\"></script>"));
    }

    @Test
    public void testPortalRedirect() {
        UrlResponse res = doMethod("GET", 4567, "/portal", null, null);
        assertTrue(res!=null);
        assertTrue(res.body != null);
        assertTrue("Return status should be 200, was "+res.status, res.status == 200);
        assertTrue("Response should include <title>Gus Trello Integrator</title>", res.body.contains("<title>Gus Trello Integrator</title>"));
    }

    @Test
    public void testNewAccount() {
        UrlResponse res = doMethod("POST", 4567, "/new", null, null, null);
        assertTrue(res != null);
        assertTrue(res.status == 302);
        assertTrue(res.headers.containsKey("Location"));
        assertTrue(res.headers.get("Location").size() == 1);
        assertTrue(res.headers.get("Location").get(0).equals("https://localhost:4567/form"));
        res = doMethod("GET", 4567, "/form", null, null, null);
        assertTrue(res != null);
        assertTrue("Response should state that Gus Credentials are needed. Got: " + res.body, res.body.contains("Gus needs to be Authorized!"));
        assertTrue(res.body.contains("Trello Token is required"));
        Map<String, String> params = new HashMap<String, String>();
        res = doMethod("POST", 4567, "/new", null, params);
        assertTrue(res != null);
        assertTrue(res.status == 302);
        assertTrue(res.headers.containsKey("Location"));
        assertTrue(res.headers.get("Location").size() == 1);
        assertTrue(res.headers.get("Location").get(0).equals("https://localhost:4567/form"));
        res = doMethod("GET", 4567, "/form", null, null, null);
        assertTrue(res != null);
        assertTrue(res.body.contains("Trello Token is required"));
        assertTrue(!res.body.contains("Need Gus Credentials"));
        params.put("trello_token","test_accessToken");

        CookieStore cookies = new BasicCookieStore();
        doMethod("GET", 7757, "/first_token", null, null, cookies, false);
        res = doMethod("POST", 4567, "/new", null, params, cookies);
        assertTrue(res != null);
        assertTrue(res.status == 302);
        assertTrue(res.headers.containsKey("Location"));
        assertTrue(res.headers.get("Location").size() == 1);
        assertTrue(res.headers.get("Location").get(0).equals("https://localhost:4567/profile"));

        // params.clear();
        // params.put("action", "logout");
        // String body = URLEncodedUtils.format(convertMapToNVP(params), "UTF-8");
        // res = doMethod("POST", 4567, "/ajax_endpoint", body, null, cookies);;
        // assertTrue(res != null);
        // assertTrue(res.body != null);
        // assertTrue(res.body.equals("{ \"result\":\"success\" }"));

        // params.clear();
        // doMethod("GET", 7757, "/first_token", null, null, cookies, false);
        // params.put("trello_token","test_accessToken");
        // res = doMethod("POST", 4567, "/new", null, params, cookies);
        // res = doMethod("GET", 4567, "/form", null, null);
        // assertTrue(res != null);
        // assertTrue(res.body != null);
        // assertTrue(res.body.contains("This Gus user is already registered with this app!"));

        // params.clear();
        // params.put("submit", "Login");
        // params.put("uname", un);
        // params.put("pword", pw);
        // res = doMethod("POST", 4567, "/route", null, params, cookies);
        // System.out.println("--------------------------"+res);
        // System.out.println(doMethod("GET", 4567, "/", null, null, cookies));

        assertTrue(db.getAllProjectConfigs().size() == 1);

        params.clear();
        params.put("action", "delete_profile");
        String body = URLEncodedUtils.format(convertMapToNVP(params), "UTF-8");
        res = doMethod("POST", 4567, "/ajax_endpoint", body, null, cookies);;
        assertTrue(res != null);
        assertTrue(res.body != null);
        System.out.println(res);
        assertTrue(res.body.equals("{ \"result\":\"success\" }"));

        assertTrue(db.getAllProjectConfigs().size() == 0);
    }

    @Test
    public void testLogoutLogin() {
        CookieStore cookies = null;
        try {
            cookies = createTestAccount();

            UrlResponse res = doMethod("GET", 4567, "/", null, null, cookies);
            assertTrue(res != null);
            assertTrue(res.body != null);
            assertTrue(res.body.contains("Integration Portal"));

            // Login is using SOAP, but can't reproduce the SOAP response for the MockGus for the EnterpriseConnector

            // Map<String, String> params = new HashMap<String, String>();
            // params.put("action", "logout");
            // String body = URLEncodedUtils.format(convertMapToNVP(params), "UTF-8");
            // res = doMethod("POST", 4567, "/ajax_endpoint", body, null, cookies);;
            // assertTrue(res != null);
            // assertTrue(res.body != null);
            // assertTrue(res.body.equals("{ \"result\":\"success\" }"));

            // res = doMethod("GET", 4567, "/portal", null, null);
            // assertTrue(res!=null);
            // assertTrue(res.body != null);
            // assertTrue("Return status should be 200, was "+res.status, res.status == 200);
            // assertTrue("Response should include <title>Gus Trello Integrator</title>", res.body.contains("<title>Gus Trello Integrator</title>"));

            // params.clear();
            // params.put("submit", "Login");
            // params.put("uname", un);
            // params.put("pword", pw);
            // res = doMethod("POST", 4567, "/route", null, params, cookies);
            // assertTrue(res.status == 302);
            // assertTrue(res.headers.containsKey("Location"));
            // assertTrue(res.headers.get("Location").size() == 1);
            // assertTrue(res.headers.get("Location").get(0).equals("http://localhost:4567/portal"));
        } finally {
            deleteTestAccount(cookies);
        }

        Map<String, String> params = new HashMap<String, String>();
        params.put("submit", "Login");
        params.put("uname", un);
        params.put("pword", pw);
        UrlResponse res = doMethod("POST", 4567, "/route", null, params);
        assertTrue(res.status == 302);
        assertTrue(res.headers.containsKey("Location"));
        assertTrue(res.headers.get("Location").size() == 1);
        assertTrue(res.headers.get("Location").get(0).equals("https://localhost:4567/"));

        res = doMethod("GET", 4567, "/", null, null);
        assertTrue(res!=null);
        assertTrue(res.body != null);
        assertTrue("Return status should be 200, was "+res.status, res.status == 200);
        assertTrue("Response should include <li>Username or Password are incorrect</li>", res.body.contains("<li>Username or Password are incorrect</li>"));
    }

    @Test
    public void testUpdateSync() {
        CookieStore cookies = null;
        try {
            cookies = createTestAccount();

            UrlResponse res = doMethod("GET", 4567, "/profile", null, null, cookies);
            assertTrue(res != null);
            assertTrue(res.status == 200);
            assertTrue(res.body != null);
            assertTrue(res.body.contains("(<span id=\"srange_value\">600</span> <span id=\"srange_units\">seconds</span>)"));

            Map<String, String> params = new HashMap<String, String>();
            params.put("action", "update_sync");
            params.put("sync", "60");
            String body = URLEncodedUtils.format(convertMapToNVP(params), "UTF-8");
            res = doMethod("POST", 4567, "/ajax_endpoint", body, null, cookies);
            assertTrue(res != null);
            assertTrue(res.body != null);
            assertTrue(res.body.equals("{ \"result\":\"success\" }"));

            res = doMethod("GET", 4567, "/profile", null, null, cookies);
            assertTrue(res != null);
            assertTrue(res.status == 200);
            assertTrue(res.body != null);
            assertTrue(res.body.contains("(<span id=\"srange_value\">60</span> <span id=\"srange_units\">seconds</span>)"));
        } finally {
            deleteTestAccount(cookies);
        }
    }

    @Test
    public void testNewRelation() {
        CookieStore cookies = null;
        try {
            cookies = createTestAccount();

            UrlResponse res = doMethod("GET", 4567, "/ajax_endpoint", null, null, cookies);
            assertTrue(res != null);
            assertTrue(res.body != null);
            assertTrue(!res.body.contains("<div class='panel old_relation' style='height: 40px;overflow:hidden;' id='current_"));
            assertTrue(!res.body.contains("<div>Product Tag: test_productName</div>"));
            assertTrue(!res.body.contains("test_teamName - test_productName"));

            Map<String, String> params = new HashMap<String, String>();
            params.put("action", "new_relation");
            String body = URLEncodedUtils.format(convertMapToNVP(params), "UTF-8");
            res = doMethod("POST", 4567, "/ajax_endpoint", body, null, cookies);            
            assertTrue(res != null);
            assertTrue(res.body != null);
            assertTrue(res.body.equals("{\"result\":\"failure\",\"trello_done\":\"Not Found\",\"trello_progress\":\"Not Found\",\"trello_new\":\"Not Found\",\"product_tag\":\"Not Found\",\"gus_team\":\"Not Found\",\"action\":\"new_relation\",\"error_fields\":\"gus_team|trello_new|trello_progress|trello_done|trello_new|trello_done|trello_progress\",\"errors\":\"Gus Team can't be blank!|Trello New List can't be blank!|Trello In Progress List can't be blank!|Trello Done List can't be blank!|Trello Lists must come from the same Trello Board\"}"));

            params.put("gus_team", "test_teamId");
            body = URLEncodedUtils.format(convertMapToNVP(params), "UTF-8");
            res = doMethod("POST", 4567, "/ajax_endpoint", body, null, cookies);            
            assertTrue(res != null);
            assertTrue(res.body != null);
            // System.out.println(res);
            assertTrue(res.body.equals("{\"result\":\"failure\",\"trello_done\":\"Not Found\",\"trello_progress\":\"Not Found\",\"trello_new\":\"Not Found\",\"product_tag\":\"Not Found\",\"gus_team\":\"test_teamName\",\"action\":\"new_relation\",\"error_fields\":\"trello_new|trello_progress|trello_done|trello_new|trello_done|trello_progress\",\"errors\":\"Trello New List can't be blank!|Trello In Progress List can't be blank!|Trello Done List can't be blank!|Trello Lists must come from the same Trello Board\"}"));

            params.put("trello_new", "list1");
            body = URLEncodedUtils.format(convertMapToNVP(params), "UTF-8");
            res = doMethod("POST", 4567, "/ajax_endpoint", body, null, cookies);            
            assertTrue(res != null);
            assertTrue(res.body != null);
            assertTrue(res.body.equals("{\"result\":\"failure\",\"trello_done\":\"Not Found\",\"trello_progress\":\"Not Found\",\"trello_new\":\"List 1\",\"product_tag\":\"Not Found\",\"gus_team\":\"test_teamName\",\"action\":\"new_relation\",\"error_fields\":\"trello_progress|trello_done|trello_new|trello_done|trello_progress\",\"errors\":\"Trello In Progress List can't be blank!|Trello Done List can't be blank!|Trello Lists must come from the same Trello Board\"}"));

            params.put("trello_progress", "list2");
            body = URLEncodedUtils.format(convertMapToNVP(params), "UTF-8");
            res = doMethod("POST", 4567, "/ajax_endpoint", body, null, cookies);            
            assertTrue(res != null);
            assertTrue(res.body != null);
            assertTrue(res.body.equals("{\"result\":\"failure\",\"trello_done\":\"Not Found\",\"trello_progress\":\"List 2\",\"trello_new\":\"List 1\",\"product_tag\":\"Not Found\",\"gus_team\":\"test_teamName\",\"action\":\"new_relation\",\"error_fields\":\"trello_done|trello_new|trello_done|trello_progress\",\"errors\":\"Trello Done List can't be blank!|Trello Lists must come from the same Trello Board\"}"));

            params.put("trello_done", "list3");
            body = URLEncodedUtils.format(convertMapToNVP(params), "UTF-8");
            res = doMethod("POST", 4567, "/ajax_endpoint", body, null, cookies);            
            assertTrue(res != null);
            assertTrue(res.body != null);
            assertTrue(res.body.equals("{\"result\":\"failure\",\"trello_done\":\"List 3\",\"trello_progress\":\"List 2\",\"trello_new\":\"List 1\",\"product_tag\":\"Not Found\",\"gus_team\":\"test_teamName\",\"action\":\"new_relation\",\"error_fields\":\"trello_new|trello_done|trello_progress\",\"errors\":\"Trello Lists must come from the same Trello Board\"}"));

            params.put("trello_new_boardid", "test_board_id");
            body = URLEncodedUtils.format(convertMapToNVP(params), "UTF-8");
            res = doMethod("POST", 4567, "/ajax_endpoint", body, null, cookies);            
            assertTrue(res != null);
            assertTrue(res.body != null);
            assertTrue(res.body.equals("{\"result\":\"failure\",\"trello_done\":\"List 3\",\"trello_progress\":\"List 2\",\"trello_new\":\"List 1\",\"product_tag\":\"Not Found\",\"gus_team\":\"test_teamName\",\"action\":\"new_relation\",\"error_fields\":\"trello_new|trello_done|trello_progress\",\"trello_new_boardid\":\"test_board_id\",\"errors\":\"Trello Lists must come from the same Trello Board\"}"));

            params.put("product_tag", "test_productId");
            body = URLEncodedUtils.format(convertMapToNVP(params), "UTF-8");
            res = doMethod("POST", 4567, "/ajax_endpoint", body, null, cookies);            
            assertTrue(res != null);
            assertTrue(res.body != null);
            assertTrue(res.body.equals("{\"result\":\"failure\",\"trello_done\":\"List 3\",\"trello_progress\":\"List 2\",\"trello_new\":\"List 1\",\"product_tag\":\"test_productName\",\"gus_team\":\"test_teamName\",\"action\":\"new_relation\",\"error_fields\":\"trello_new|trello_done|trello_progress\",\"trello_new_boardid\":\"test_board_id\",\"errors\":\"Trello Lists must come from the same Trello Board\"}"));

            params.put("trello_progress_boardid", "test_board_id");
            params.put("gus_filter_in",".*");
            params.put("gus_filter_out",".*");
            params.put("trello_filter_in",".*");
            params.put("trello_filter_out",".*");
            body = URLEncodedUtils.format(convertMapToNVP(params), "UTF-8");
            res = doMethod("POST", 4567, "/ajax_endpoint", body, null, cookies);            
            assertTrue(res != null);
            assertTrue(res.body != null);
            assertTrue(res.body.equals("{\"trello_progress\":\"List 2\",\"trello_new\":\"List 1\",\"trello_new_boardid\":\"test_board_id\",\"gus_filter_in\":\".*\",\"trello_filter_out\":\".*\",\"result\":\"failure\",\"trello_done\":\"List 3\",\"trello_progress_boardid\":\"test_board_id\",\"product_tag\":\"test_productName\",\"gus_team\":\"test_teamName\",\"action\":\"new_relation\",\"error_fields\":\"trello_new|trello_done|trello_progress\",\"gus_filter_out\":\".*\",\"trello_filter_in\":\".*\",\"errors\":\"Trello Lists must come from the same Trello Board\"}"));

            params.put("trello_done_boardid", "test_board_id");
            body = URLEncodedUtils.format(convertMapToNVP(params), "UTF-8");
            res = doMethod("POST", 4567, "/ajax_endpoint", body, null, cookies);            
            assertTrue(res != null);
            assertTrue(res.body != null);
            assertTrue(res.body.contains("\"result\":\"success\""));

            res = doMethod("GET", 4567, "/portal", null, null, cookies);
            assertTrue(res != null);
            assertTrue(res.body != null);
            assertTrue(res.body.contains("<div class='panel old_relation' style='height: 40px;overflow:hidden;' id='current_"));
            assertTrue(res.body.contains("<div>Product Tag: test_productName</div>"));
            assertTrue(res.body.contains("test_teamName - test_productName"));

            String str = "<div class='panel old_relation' style='height: 40px;overflow:hidden;' id='current_";
            int idx = res.body.indexOf(str);
            int end = res.body.indexOf("'", idx + str.length());
            params.clear();
            params.put("action", "remove_relation");
            params.put("id", res.body.substring(idx + str.length(), end));
            body = URLEncodedUtils.format(convertMapToNVP(params), "UTF-8");
            res = doMethod("POST", 4567, "/ajax_endpoint", body, null, cookies);            
            assertTrue(res != null);
            assertTrue(res.body != null);
            assertTrue(res.body.equals("{ \"result\":\"success\" }"));

            res = doMethod("GET", 4567, "/portal", null, null, cookies);
            assertTrue(res != null);
            assertTrue(res.body != null);
            assertTrue(!res.body.contains("<div class='panel old_relation' style='height: 40px;overflow:hidden;' id='current_"));
            assertTrue(!res.body.contains("<div>Product Tag: test_productName</div>"));
            assertTrue(!res.body.contains("test_teamName - test_productName"));

        } finally {
            deleteTestAccount(cookies);
        }
    }

    @Test
    public void testAddNewItem() {
        CookieStore cookies = null;
        try {
            cookies = createTestAccount();

            Map<String, String> params = new HashMap<String, String>();
            params.put("action","add_item");
            String body = URLEncodedUtils.format(convertMapToNVP(params), "UTF-8");
            UrlResponse res = doMethod("POST", 4567, "/ajax_endpoint", body, null, cookies);
            assertTrue(res != null);
            assertTrue(res.body != null);
            assertTrue(res.body.equals("{\"result\":\"failure\",\"action\":\"add_item\"}"));

            params.put("type", "nothing");
            body = URLEncodedUtils.format(convertMapToNVP(params), "UTF-8");
            res = doMethod("POST", 4567, "/ajax_endpoint", body, null, cookies);
            assertTrue(res != null);
            assertTrue(res.body != null);
            assertTrue(res.body.equals("{\"result\":\"failure\",\"action\":\"add_item\",\"type\":\"nothing\"}"));

            params.put("value","nothing");
            body = URLEncodedUtils.format(convertMapToNVP(params), "UTF-8");
            res = doMethod("POST", 4567, "/ajax_endpoint", body, null, cookies);
            assertTrue(res != null);
            assertTrue(res.body != null);
            assertTrue(res.body.equals("{\"result\":\"failure\",\"action\":\"add_item\",\"type\":\"nothing\",\"value\":\"nothing\"}"));

            params.put("type","addTeam");
            body = URLEncodedUtils.format(convertMapToNVP(params), "UTF-8");
            res = doMethod("POST", 4567, "/ajax_endpoint", body, null, cookies);
            assertTrue(res != null);
            assertTrue(res.body != null);
            assertTrue(res.body.equals("{\"result\":\"success\",\"action\":\"add_item\",\"id\":\"test_teamId\",\"type\":\"addTeam\",\"value\":\"nothing\"}"));

            params.put("type", "addProduct");
            body = URLEncodedUtils.format(convertMapToNVP(params), "UTF-8");
            res = doMethod("POST", 4567, "/ajax_endpoint", body, null, cookies);
            assertTrue(res != null);
            assertTrue(res.body != null);
            assertTrue(res.body.equals("{\"result\":\"success\",\"action\":\"add_item\",\"id\":\"test_productId\",\"type\":\"addProduct\",\"value\":\"nothing\"}"));

            params.clear();
            params.put("action","remove_item");
            body = URLEncodedUtils.format(convertMapToNVP(params), "UTF-8");
            res = doMethod("POST", 4567, "/ajax_endpoint", body, null, cookies);
            assertTrue(res != null);
            assertTrue(res.body != null);
            assertTrue(res.body.equals("{\"result\":\"failure\",\"action\":\"remove_item\"}"));

            params.put("type","team");
            body = URLEncodedUtils.format(convertMapToNVP(params), "UTF-8");
            res = doMethod("POST", 4567, "/ajax_endpoint", body, null, cookies);
            assertTrue(res != null);
            assertTrue(res.body != null);
            assertTrue(res.body.equals("{\"result\":\"failure\",\"action\":\"remove_item\",\"type\":\"team\"}"));

            params.put("name","nothing");
            params.put("type","something");
            body = URLEncodedUtils.format(convertMapToNVP(params), "UTF-8");
            res = doMethod("POST", 4567, "/ajax_endpoint", body, null, cookies);
            assertTrue(res != null);
            assertTrue(res.body != null);
            // System.out.println("-------------------");
            // System.out.println(res);
            assertTrue(res.body.equals("{\"result\":\"failure\",\"name\":\"nothing\",\"action\":\"remove_item\",\"type\":\"something\"}"));

            params.put("type","team");
            body = URLEncodedUtils.format(convertMapToNVP(params), "UTF-8");
            res = doMethod("POST", 4567, "/ajax_endpoint", body, null, cookies);
            assertTrue(res != null);
            assertTrue(res.body != null);
            assertTrue(res.body.equals("{\"result\":\"success\",\"name\":\"nothing\",\"action\":\"remove_item\",\"type\":\"team\"}"));


        } finally {
            deleteTestAccount(cookies);
        }
    }
}
