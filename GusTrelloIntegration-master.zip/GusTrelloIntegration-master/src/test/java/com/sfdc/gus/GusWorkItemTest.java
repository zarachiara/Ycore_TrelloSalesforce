package com.sfdc.gus;

import static org.junit.Assert.*;
import org.junit.Test;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Map;

public class GusWorkItemTest {

    @Test
    public void testConstructors() {
        try {
            GusWorkItem gwi = new GusWorkItem(new JSONObject("{\"Id\":\"1\",\"Subject__c\":\"New Card\",\"Details__c\":\"New Description\\ntrello card: 222222222222222222222222\\nHash: 11111111111111111111111111111111\"}"));

            assertTrue(gwi != null);
            assertTrue(gwi.id.equals("1"));
            assertTrue(gwi.subject.equals("New Card"));
            assertTrue(gwi.details.contains("New Description"));
            assertTrue(gwi.oldHash.equals("11111111111111111111111111111111"));
            assertTrue(gwi.trelloCardId.equals("222222222222222222222222"));

            JSONObject json = new JSONObject("{\"name\":\"test card:5\",\"desc\":\"Description\\n"+GusContext.GUS_ENDPOINT+"/aoeu\",\"id\":\"1\"}");
            TrelloCard tc = new TrelloCard(json);
            gwi = new GusWorkItem(tc);
            assertTrue(gwi.trelloCardId.equals("1"));
            assertTrue(gwi.points.equals("5"));
            assertTrue(gwi.subject.equals("test card"));
            assertTrue(gwi.details.contains("Description"));
            assertTrue(gwi.details.contains("trello card: 1"));

            assertTrue(gwi.equals(tc));
            assertFalse(gwi.same(tc));
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false);
        }
    }

    @Test
    public void runGetters() {
        try {
            GusWorkItem gwi = new GusWorkItem(new JSONObject("{\"Id\":\"1\",\"Subject__c\":\"New Card\",\"Details__c\":\"New Description\"}"));

            gwi.getId();
            gwi.getSubject();
            gwi.getDetails();
            gwi.getPoints();
            gwi.getSprintId();
            gwi.getBuildId();
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false);
        }
    }

    @Test
    public void testSetters() {
        try {
            GusWorkItem gwi = new GusWorkItem(new JSONObject("{\"Id\":\"1\",\"Subject__c\":\"New Card\",\"Details__c\":\"New Description\"}"));

            assertTrue(gwi.subject.equals("New Card"));
            gwi.setSubject("other card");
            assertTrue(gwi.subject.equals("other card"));

            Map<String, String> changes = gwi.getChangedValuesMap();
            assertTrue(changes.containsKey(GusContext.SUBJECT_FIELD));
            assertTrue(changes.get(GusContext.SUBJECT_FIELD).equals("other card"));

            gwi.setDetails("details");
            assertTrue(changes.containsKey(GusContext.DETAILS_FIELD));
            assertTrue(changes.get(GusContext.DETAILS_FIELD).equals("details"));

            gwi.setStatus("Closed");
            assertTrue(changes.containsKey("Status__c"));
            assertTrue(changes.get("Status__c").equals("Closed"));

            gwi.setPoints("4");
            assertTrue(changes.containsKey(GusContext.STORY_POINTS_FIELD));
            assertTrue(changes.get(GusContext.STORY_POINTS_FIELD).equals("4"));

            gwi.setSprintId("aoeu");
            assertTrue(changes.containsKey(GusContext.SPRINT_FIELD));
            assertTrue(changes.get(GusContext.SPRINT_FIELD).equals("aoeu"));

        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false);
        }
    }

    @Test
    public void testUpdateDetails() {
        try {
            GusWorkItem gwi = new GusWorkItem(new JSONObject("{\"Id\":\"1\",\"Subject__c\":\"New Card\",\"Details__c\":\"New Description\"}"));

            assertTrue(gwi != null);
            assertTrue(gwi.oldHash == null);
            assertFalse(gwi.details.contains("Hash: "));
            gwi.updateDetails();
            assertTrue(gwi.details.contains("Hash: "));

            String oldHash = "";
            int idx = gwi.details.indexOf("Hash: ");
            if(idx > -1) {
                oldHash = gwi.details.substring(idx + 6, idx + 6 + 32);
            }

            assertTrue(oldHash.length() == 32);
            gwi.setDetails("other description");
            gwi.updateDetails();
            assertTrue(gwi.details.contains("Hash: "));

            String newHash = "";
            idx = gwi.details.indexOf("Hash: ");
            if(idx > -1) {
                newHash = gwi.details.substring(idx + 6, idx + 6 + 32);
            }

            assertTrue(newHash.length() == 32);
            assertFalse(newHash.equals(oldHash));
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false);
        }
    }

    @Test
    public void testIsChangedToString() {
        try {
            GusWorkItem gwi = new GusWorkItem(new JSONObject("{\"Id\":\"1\",\"Subject__c\":\"New Card\",\"Details__c\":\"New Description\"}"));

            gwi.updateDetails();
            int idx = gwi.details.indexOf("Hash: ");
            if(idx > -1) {
                gwi.oldHash = gwi.details.substring(idx + 6, idx + 6 + 32);
            }

            assertFalse(gwi.isChanged());
            gwi.setSubject("new name");
            assertTrue(gwi.isChanged());

            String str = gwi.toString();
            assertTrue(str.contains("{Work Item ID: 1"));
            assertTrue(str.contains(", Subject: new name"));
            assertTrue(str.contains(", Status: New"));
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false);
        }
    }
}