package com.sfdc.gus;

import static org.junit.Assert.*;

import java.util.Map;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;

import org.junit.Test;
import org.junit.BeforeClass;
import org.junit.AfterClass;
import org.hibernate.SessionFactory;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.json.JSONObject;

import com.sfdc.gus.testHelpers.MockGus;
import com.sfdc.gus.testHelpers.MockTrello;
import com.sfdc.gus.GusContext;
import com.sfdc.gus.TrelloContext;
import com.sfdc.gus.GusWorkItem;
import com.sfdc.gus.TrelloCard;
import com.sfdc.gus.config.DatabaseHelper;
import com.sfdc.gus.config.ProjectConfig;
import com.sfdc.gus.config.GusLogin;
import com.sfdc.gus.config.TrelloLogin;
import com.sfdc.gus.config.ProductListMapping;
import com.sfdc.gus.security.AESDualCrypt;

public class ProjectThreadTest {

    private static MockGus mg = null;
    private static MockTrello mt = null;
    private static DatabaseHelper db = null;
    private static ProjectConfig pc = null;
    private static GusContext gctx = null;
    private static TrelloContext tctx = null;
    private static AESDualCrypt crypter = null;

    @BeforeClass
    public static void setup() {
        mg = new MockGus();
        mg.run();
        mt = new MockTrello();
        mt.run();


        crypter = new AESDualCrypt("12345abcdefg");
        db = createDBHelper();
        // Make sure the DB is completely empty
        for(ProjectConfig pc : db.getAllProjectConfigs()) {
            db.deleteUser(pc);
        }
        db.setGlobalProperty("appkey", crypter.encrypt("test_APIKey"));
        db.setGlobalProperty("client_id",crypter.encrypt("TESTCLIENTID"));
        db.setGlobalProperty("client_secret",crypter.encrypt("TESTCLIENTSECRET"));
        GusContext.setup(db);

        GusLogin gl = new GusLogin("test_userId",crypter.encrypt("test_password"));
        gctx = new GusContext(gl, crypter);
        try {
            gctx.refresh();
        } catch (Exception e) {
            System.out.println("Exception encountered while trying to login");
            e.printStackTrace();
        }
        TrelloLogin tl = new TrelloLogin(crypter.encrypt("test_accessToken"));
        tctx = new TrelloContext(tl, crypter.encrypt("test_APIKey"), crypter);
        try {
            tctx.getMe();
        } catch (Exception e) {
            System.out.println("Exception encountered while trying to getMe");
            e.printStackTrace();
        }

        pc = db.createUser("test_user", crypter.encrypt("test_password"), crypter.encrypt("test_accessToken"), 10);
    }

    @AfterClass
    public static void teardown() {
        for(ProjectConfig pc : db.getAllProjectConfigs()) {
            db.deleteUser(pc);
        }
        mg.stop();
        mt.stop();
    }

    private static DatabaseHelper createDBHelper() {
        SessionFactory sessionFactory = null;
        try {
            Configuration hbcfg = new Configuration()
                        .configure(); // configures settings from hibernate.cfg.xml

            ServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder().applySettings(hbcfg.getProperties()).build();

            if (! hbcfg.getProperty("hibernate.connection.url").contains("test")) {
                // This is junit. We want to be in the testing environment. If test isn't in the database name, prevent any tests from changing the DB
                System.err.println("junit tests must be ran as the test profile. Please run 'lein with-profile test junit' instead");
                sessionFactory = null;
            } else {
                sessionFactory = hbcfg.buildSessionFactory(serviceRegistry);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        if(sessionFactory != null) {
            return new DatabaseHelper(sessionFactory);
        }
        return null;
    }

    private void stopThread(int time) {
        Thread thread = new Thread() {
            public void run() {
                try {
                    Thread.sleep(time);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                ProjectThread.globalkeepalive = false;
            }
        };
        thread.start();
    }

    @Test
    public void testDeleteUser() {
        try {
            db.deleteUser(pc);
            ProjectThread.globalkeepalive = true;
            ProjectThread pt = new ProjectThread(pc, db, crypter);
            long timeStart = System.nanoTime();
            stopThread(5000);
            pt.run();
            long diff = System.nanoTime() - timeStart;
            assertTrue("Run should have exited almost immediately, actually took " + diff/1000000 + " milliseconds", diff < 200000000);
            // Since we started a thread to set globalkeepalive to false after 5 seconds, need to wait that out
            Thread.sleep(5000);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            pc = db.createUser("test_user", crypter.encrypt("test_password"), crypter.encrypt("test_accessToken"), 10);
        }
    }

    @Test 
    public void testStartup() {
        // We want these threads to die without doing anything
        ProjectThread.globalkeepalive = false;
        List<ProjectThread> allThreads = new ArrayList<ProjectThread>();
        ProjectThread.startup(db, crypter, allThreads);
        assertTrue(allThreads.size() == 1);
    }

    @Test
    public void testConstructorsDontThrowErrors() {
        System.out.println("Starting contstructor test");
        ProjectThread pt = new ProjectThread(pc, db, crypter);
        System.out.println("Done with constructor test");
    }

    @Test
    public void testGlobalKeepAliveFalse() {
        ProjectThread.globalkeepalive = false;
        ProjectThread pt1 = new ProjectThread(pc, db, crypter);
        long timeStart = System.nanoTime();
        stopThread(5000);
        pt1.run();
        long diff = System.nanoTime() - timeStart;
        assertTrue("Run should have exited almost immediately, actually took " + diff/1000000 + " milliseconds", diff < 3000000);
        try {
            // Since we started a thread to set globalkeepalive to false after 5 seconds, need to wait that out
            Thread.sleep(5000);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Unsuccessful attempt at testing login faults from SF. 
    /*@Test
    public void testInvalid() {
        try {
            RestUtil.getObject("http://localhost:7757/start_rejecting", new HashMap<String, String>());
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false);
        }

        ProjectThread pt = new ProjectThread(pc, db, crypter);
        ProjectThread.globalkeepalive = true;
        assertFalse(pt.isInvalid());

        stopThread(5000);
        pt.run();

        assertTrue(pt.isInvalid());

        try {
            RestUtil.getObject("http://localhost:7757/stop_rejecting", new HashMap<String, String>());
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false);
        }

    }*/

    @Test
    public void testRunWithPLMs() {
        System.out.println("Starting run with PLMs test");
        ProjectThread.globalkeepalive = true;
        ProjectThread pt = new ProjectThread(pc, db, crypter);
        Map<String, String> rel = new HashMap<String, String>();
        rel.put("product_tag","test_productId");
        rel.put("gus_team","test_teamId");
        rel.put("trello_done","list1");
        rel.put("trello_done_boardid","test_board_id1");
        rel.put("trello_progress","list1");
        rel.put("trello_progress_boardid","test_board_id1");
        rel.put("trello_new","list1");
        rel.put("trello_new_boardid","test_board_id1");
        List<ProductListMapping> plms = db.addRelationForUser(pc, rel);
        assertTrue(plms.size() == 3);
        // Set the closed plm to not run
        plms.get(0).setSyncEnabled(false);
        db.saveUpdate(plms.get(0));

        System.out.println("--------------------------------------------------");


        try {
            Map<String, GusWorkItem> map = gctx.getWorkItems("test_sprintId");
            assertTrue("MockGus should only have 1 Work Item, but has " + map.size(), map.size() == 1);
            Map<String, TrelloCard> cards = tctx.getMyCards("list1");
            assertTrue("MockTrello should only have 1 card, but has " + cards.size(), cards.size() == 1);
        } catch (Exception e) {
            e.printStackTrace();
        }

        //System.out.println("-------------------testMockStuff " + ProjectThread.globalkeepalive);
        stopThread(5000);
        pt.run();

        try {
            Map<String, GusWorkItem> map = gctx.getWorkItems("test_sprintId");
            assertTrue("MockGus should now have 2 Work Items, but has " + map.size(), map.size() == 2);
            Map<String, TrelloCard> cards = tctx.getMyCards("list1");
            assertTrue("MockTrello should only have 2 card, but has " + cards.size(), cards.size() == 2);
            assertTrue("MockGus and MockTrello should have the same number of cards/work items for this user. Gus: " + map.size() + ", Trello: " + cards.size(), map.size() == cards.size());
        } catch (Exception e) {
            e.printStackTrace();
        }

        System.out.println("--------------------------------------------------");
        // Test trello cards being deleted (by creating a gus work item with a trello card id that doesn't exist in the MockTrello)
        ProjectThread.globalkeepalive = true;
        TrelloCard tc = null;
        GusWorkItem gwi = null;
        
        try {
            tc = new TrelloCard(new JSONObject("{\"name\":\"test_card\",\"desc\":\"Description\",\"id\":\"test_card\"}"));
            gctx.createGusWorkItem(tc, "test_productId", "New");

            Map<String, GusWorkItem> map = gctx.getWorkItems("test_sprintId");
            assertTrue("MockGus should have 3 Work Items, but has " + map.size(), map.size() == 3);
            Map<String, TrelloCard> cards = tctx.getMyCards("list1");
            assertTrue("MockTrello should have 2 card, but has " + cards.size(), cards.size() == 2);

            gwi = gctx.getGusWorkItem(tc.gusId);
            assertTrue(gwi != null);
            assertTrue(gwi.status.equals("New"));
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false);
        }

        plms.get(1).setSyncEnabled(false);
        db.saveUpdate(plms.get(1));
        stopThread(5000);
        pt.run();
        plms.get(1).setSyncEnabled(true);
        db.saveUpdate(plms.get(1));

        try {
            Map<String, GusWorkItem> map = gctx.getWorkItems("test_sprintId");
            assertTrue("MockGus should have 3 Work Items, but has " + map.size(), map.size() == 3);
            Map<String, TrelloCard> cards = tctx.getMyCards("list1");
            assertTrue("MockTrello should have 3 card, but has " + cards.size(), cards.size() == 3);

            gwi = gctx.getGusWorkItem(tc.gusId);
            assertTrue(gwi != null);
            assertTrue(gwi.status.equals("Closed"));

            tc.updateDesc();
            tctx.updateTrelloCard(tc);
            tc = tctx.getCard(gwi.trelloCardId);
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false);
        }

        // Test updating one card will update the other
        ProjectThread.globalkeepalive = true;
        tc.setDesc("New Description----------%0a" + GusContext.GUS_ENDPOINT + "/" + tc.gusId + "%0aHash: 11111111111111111111111111111111");

        try {
            tctx.updateTrelloCard(tc);
            tc = tctx.getCard(tc.id);

            gwi = gctx.getGusWorkItem(tc.gusId);
            assertTrue(gwi.details.contains("Description") && !gwi.details.contains("New"));
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false);
        }

        stopThread(5000);
        pt.run();

        try {
            gwi = gctx.getGusWorkItem(tc.gusId);
            assertTrue(gwi.details.contains("New Description"));
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false);
        }

        ProjectThread.globalkeepalive = true;
        gwi.setDetails("Old Whatever----------\ntrello card: " + gwi.trelloCardId + "\nHash: 11111111111111111111111111111111");

        try {
            gctx.updateGusWorkItem(gwi);
            gwi = gctx.getGusWorkItem(gwi.id);

            tc = tctx.getCard(gwi.trelloCardId);
            assertTrue(tc.desc.contains("New Description") && !tc.desc.contains("Old Whatever"));
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false);
        }

        stopThread(5000);
        pt.run();

        try {
            tc = tctx.getCard(gwi.trelloCardId);
            assertTrue(tc.desc.contains("Old Whatever"));
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false);
        }


        // Test filtering
        // remove plms from user
        ProjectThread.globalkeepalive = true;
        for (ProductListMapping plm : plms) {
            db.removeRelationForUser(pc.getProjectConfigId(), String.valueOf(plm.getProductListMappingId()));
        }
        db.refresh(pc, pc.getProjectConfigId());
        assertTrue(pc.getProductListMappings().size() == 0);
        rel.put("gus_filter_in","this_should_not_match_anything");
        rel.put("gus_filter_out",".*");
        rel.put("trello_filter_in","internapalooza");
        rel.put("trello_filter_out","palooza");
        plms = db.addRelationForUser(pc, rel);
        assertTrue(plms.size() == 3);
        // Set the closed plm to not run
        plms.get(0).setSyncEnabled(false);
        db.saveUpdate(plms.get(0));

        try {
            tc = new TrelloCard(new JSONObject("{\"name\":\"new test, new card\",\"desc\":\"Description\",\"id\":\"test_card\"}"));
            gctx.createGusWorkItem(tc, "test_productId", "New");

            Map<String, GusWorkItem> map = gctx.getWorkItems("test_sprintId");
            assertTrue("MockGus should have 4 Work Items, but has " + map.size(), map.size() == 4);
            Map<String, TrelloCard> cards = tctx.getMyCards("list1");
            assertTrue("MockTrello should have 3 card, but has " + cards.size(), cards.size() == 3);
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false);
        }

        stopThread(5000);
        pt.run();

        try {
            Map<String, GusWorkItem> map = gctx.getWorkItems("test_sprintId");
            assertTrue("MockGus should have 4 Work Items, but has " + map.size(), map.size() == 4);
            Map<String, TrelloCard> cards = tctx.getMyCards("list1");
            assertTrue("MockTrello should have 3 card, but has " + cards.size(), cards.size() == 3);
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false);
        }

        // more test filtering
        ProjectThread.globalkeepalive = true;
        try {
            Map<String, String> headers = new HashMap<String, String>();
            headers.put("Content-Type", "application/json; charset=utf-8");
            RestUtil.createObject(TrelloContext.TRELLO_SERVER + "/lists/list1/cards?" + 
            tctx.getTrelloAccessQuery() + 
            "&idList=list1&name=palooza&desc=Description",
            null, headers);
            // gwi = new GusWorkItem(new JSONObject("{\"Id\":\"1\",\"Subject__c\":\"palooza\",\"Details__c\":\"Description\"}"));
            // tctx.createTrelloCard(gwi,"list1");
            Map<String, GusWorkItem> map = gctx.getWorkItems("test_sprintId");
            assertTrue("MockGus should have 4 Work Items, but has " + map.size(), map.size() == 4);
            Map<String, TrelloCard> cards = tctx.getMyCards("list1");
            assertTrue("MockTrello should have 4 card, but has " + cards.size(), cards.size() == 4);
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false);
        }

        stopThread(5000);
        pt.run();

        try {
            Map<String, GusWorkItem> map = gctx.getWorkItems("test_sprintId");
            assertTrue("MockGus should have 4 Work Items, but has " + map.size(), map.size() == 4);
            Map<String, TrelloCard> cards = tctx.getMyCards("list1");
            assertTrue("MockTrello should have 4 card, but has " + cards.size(), cards.size() == 4);
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false);
        }

        // more test filtering
        ProjectThread.globalkeepalive = true;
        System.out.println("-------------------------");
        try {
            Map<String, String> headers = new HashMap<String, String>();
            headers.put("Content-Type", "application/json; charset=utf-8");
            RestUtil.createObject(TrelloContext.TRELLO_SERVER + "/lists/list1/cards?" + 
            tctx.getTrelloAccessQuery() + 
            "&idList=list1&name=internapalooza&desc=Description",
            null, headers);
            // gwi = new GusWorkItem(new JSONObject("{\"Id\":\"101\",\"Subject__c\":\"internapalooza\",\"Details__c\":\"Description\"}"));
            // tctx.createTrelloCard(gwi,"list1");
            Map<String, GusWorkItem> map = gctx.getWorkItems("test_sprintId");
            assertTrue("MockGus should have 4 Work Items, but has " + map.size(), map.size() == 4);
            Map<String, TrelloCard> cards = tctx.getMyCards("list1");
            assertTrue("MockTrello should have 5 card, but has " + cards.size(), cards.size() == 5);
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false);
        }

        stopThread(5000);
        pt.run();

        try {
            Map<String, GusWorkItem> map = gctx.getWorkItems("test_sprintId");
            assertTrue("MockGus should have 5 Work Items, but has " + map.size(), map.size() == 5);
            Map<String, TrelloCard> cards = tctx.getMyCards("list1");
            assertTrue("MockTrello should have 5 card, but has " + cards.size(), cards.size() == 5);
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false);
        }

        System.out.println("Done with run with PLMs test");
    }

    @Test
    public void testRun() {
        System.out.println("Starting run test");
        ProjectThread.globalkeepalive = true;
        ProjectThread pt = new ProjectThread(pc, db, crypter);
        stopThread(5000);
        pt.run();
        System.out.println("Done with run test");
    }
}