package com.sfdc.gus;
import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.BeforeClass;
import org.junit.AfterClass;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Map;
import java.util.List;

import java.net.ProtocolException;
import java.io.IOException;
import java.io.Reader;
import java.io.StringWriter;
import java.io.Writer;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.HttpURLConnection;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.hibernate.SessionFactory;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;

import com.sfdc.gus.testHelpers.MockGus;
import com.sfdc.gus.security.AESDualCrypt;
import com.sfdc.gus.config.GusLogin;
import com.sfdc.gus.config.DatabaseHelper;

public class GusContextTest {

    private static class UrlResponse {
        public Map<String, List<String>> headers;
        private String body;
        private int status;

        public String toString() {
            return "{status="+status+", headers="+headers+", body="+body+"}";
        }
    }

    private static MockGus mg;
    private static GusContext gctx;

    @BeforeClass
    public static void setup() {
        mg = new MockGus();
        mg.run();

        AESDualCrypt crypter = new AESDualCrypt("12345abcdefg");
        GusLogin gl = new GusLogin("test_userId",crypter.encrypt("test_password"));
        gctx = new GusContext(gl, crypter);

        DatabaseHelper db = createDBHelper();
        db.setGlobalProperty("client_id",crypter.encrypt("TESTCLIENTID"));
        db.setGlobalProperty("client_secret",crypter.encrypt("TESTCLIENTSECRET"));
        GusContext.setup(db);

        try {
            Thread.sleep(1000);
        } catch (Exception e) {
            
        }
    }

    @AfterClass
    public static void teardown() {
        mg.stop();
    }

    private static DatabaseHelper createDBHelper() {
        SessionFactory sessionFactory = null;
        try {
            Configuration hbcfg = new Configuration()
                        .configure(); // configures settings from hibernate.cfg.xml

            ServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder().applySettings(hbcfg.getProperties()).build();

            if (! hbcfg.getProperty("hibernate.connection.url").contains("test")) {
                // This is junit. We want to be in the testing environment. If test isn't in the database name, prevent any tests from changing the DB
                System.err.println("junit tests must be ran as the test profile. Please run 'lein with-profile test junit' instead");
                sessionFactory = null;
            } else {
                sessionFactory = hbcfg.buildSessionFactory(serviceRegistry);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        if(sessionFactory != null) {
            return new DatabaseHelper(sessionFactory);
        }
        return null;
    }

    private static UrlResponse doMethod(String requestMethod, String port, String path) {
        UrlResponse response = new UrlResponse();

        try {
            getResponse(requestMethod, port, path, response);
        } catch (IOException e) {
            e.printStackTrace();
        }

        return response;
    }

    private static void getResponse(String requestMethod, String port, String path, UrlResponse response)
            throws MalformedURLException, IOException, ProtocolException {
        System.out.println("Connection to: http://localhost:" + port + path);
        URL url = new URL("http://localhost:" + port + path);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod(requestMethod);
        connection.connect();
        String res = toString(connection.getInputStream());
        response.body = res;
        response.status = connection.getResponseCode();
        response.headers = connection.getHeaderFields();
    }

    private static String toString(InputStream input) throws IOException {
        StringWriter sw = new StringWriter();
        InputStreamReader in = new InputStreamReader(input);
        copyLarge(in, sw);
        return sw.toString();
    }

    public static long copyLarge(Reader input, Writer output) throws IOException {
        char[] buffer = new char[1024 * 4];
        long count = 0;
        int n = 0;
        while (-1 != (n = input.read(buffer))) {
            output.write(buffer, 0, n);
            count += n;
        }
        return count;
    }

    @Test
    public void testLogin() {
        try {
            gctx.refresh();
            assertTrue(gctx.getSessionId().equals("test_sessionId"));
            assertTrue(gctx.getUserId().equals("test_userId"));

            assertTrue(gctx.isLoggedIn());

            gctx.refresh();
            assertTrue(gctx.getSessionId().equals("test_sessionId"));
            assertTrue(gctx.getUserId().equals("test_userId"));

            gctx.logout();
            assertFalse(gctx.isLoggedIn());
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false);
        }
    }

    @Test
    public void testGetRestQuery() {
        String query = gctx.getRestQueryUrlString("test_type",null);
        assertTrue(query.equals(getGctxRest() + "query/?q=SELECT+Id+FROM+test_type"));

        query = gctx.getRestQueryUrlString("test_type","name=name");
        assertTrue(query.equals(getGctxRest() + "query/?q=SELECT+Id+FROM+test_type+WHERE+name=name"));

        query = gctx.getRestQueryUrlString("field1,field2","test_type","name=name");
        assertTrue(query.equals(getGctxRest() + "query/?q=SELECT+field1,field2+FROM+test_type+WHERE+name=name"));

        query = gctx.getRestSObjectAccessUrlString("test_type");
        assertTrue(query.equals(getGctxRest() + "sobjects/test_type/"));

        query = gctx.getRestSObjectAccessUrlString("test_type","test_id");
        assertTrue(query.equals(getGctxRest() + "sobjects/test_type/test_id"));

        query = gctx.getAccessUrlString("test_id");
        assertTrue(query.equals(GusContext.GUS_ENDPOINT + "/test_id"));
    }

    public String getGctxRest() {
        return GusContext.GUS_ENDPOINT + GusContext.GUS_REST_URI;
    }

    @Test
    public void testGetGusInfo() {
        try {
            gctx.refresh();
            List<Map> teams = gctx.getGusInfo();
            assertTrue(teams.size() == 1);
            Map info = teams.get(0);
            assertTrue(info.size() == 3);
            assertTrue(info.containsKey("Id"));
            assertTrue(((String)info.get("Id")).equals("test_teamId"));
            assertTrue(info.containsKey("Name"));
            assertTrue(((String)info.get("Name")).equals("test_teamName"));
            assertTrue(info.containsKey("product_tags"));
            List<Map> prods = (List<Map>)info.get("product_tags");
            assertTrue(prods.size() == 1);
            Map prod = prods.get(0);
            assertTrue(prod.size() == 2);
            assertTrue(prod.containsKey("Id"));
            assertTrue(((String)prod.get("Id")).equals("test_productId"));
            assertTrue(prod.containsKey("Name"));
            assertTrue(((String)prod.get("Name")).equals("test_productName"));

            gctx.refreshGusInfo();

            teams = gctx.getGusInfo();
            assertTrue(teams.size() == 1);
            info = teams.get(0);
            assertTrue(info.size() == 3);
            assertTrue(info.containsKey("Id"));
            assertTrue(((String)info.get("Id")).equals("test_teamId"));
            assertTrue(info.containsKey("Name"));
            assertTrue(((String)info.get("Name")).equals("test_teamName"));
            assertTrue(info.containsKey("product_tags"));
            prods = (List<Map>)info.get("product_tags");
            assertTrue(prods.size() == 1);
            prod = prods.get(0);
            assertTrue(prod.size() == 2);
            assertTrue(prod.containsKey("Id"));
            assertTrue(((String)prod.get("Id")).equals("test_productId"));
            assertTrue(prod.containsKey("Name"));
            assertTrue(((String)prod.get("Name")).equals("test_productName"));
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false);
        }
    }

    @Test
    public void testGetProductTags() {
        try {
            gctx.refresh();
            List<Map> productTags = gctx.getProductTags();
            assertTrue(productTags != null);
            assertTrue(productTags.size() == 1);
            Map tag = productTags.get(0);
            assertTrue(tag.size() == 2);
            assertTrue(tag.containsKey("Id"));
            assertTrue(((String)tag.get("Id")).equals("test_productId"));
            assertTrue(tag.containsKey("Name"));
            assertTrue(((String)tag.get("Name")).equals("test_productName"));
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false);
        }
    }

    @Test
    public void testGetTeamIfExists() {
        try {
            gctx.refresh();
            String teamId = gctx.getTeamIfExists("this_should_fail");
            assertTrue(teamId == null);

            teamId = gctx.getTeamIfExists("AnythingElse");
            assertTrue(teamId != null);
            assertTrue(teamId.equals("test_teamId"));
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false);
        }
    }

    @Test
    public void testGetProductIfExists() {
        try {
            gctx.refresh();
            String prod = gctx.getProductIfExists("this_should_fail");
            assertTrue(prod == null);

            prod = gctx.getProductIfExists("AnythingElse");
            assertTrue(prod != null);
            assertTrue(prod.equals("test_productId"));
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false);
        }
    }

    @Test
    public void testGetTeamSprint() {
        try {
            gctx.refresh();
            String sprint = gctx.getTeamSprint("this_should_fail");
            assertTrue(sprint == null);

            sprint = gctx.getTeamSprint("AnythingElse");
            assertTrue(sprint != null);
            assertTrue(sprint.equals("test_sprintId"));
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false);
        }
    }

    @Test
    public void testGetWorkItems() {
        try {
            Map<String, GusWorkItem> map = gctx.getWorkItems("test_sprintId");

            // Due to tests running in parallel, the number of work items could be 1 or 2 
            assertTrue("Was expecting 1-3, got " + map.size(),map.size() >= 1 && map.size() <= 3);
            assertTrue(map.containsKey("test_workItemId"));
            assertTrue(map.get("test_workItemId") != null);
            GusWorkItem gwi = map.get("test_workItemId");

            assertTrue(gwi.id.equals("test_workItemId"));
            assertTrue(gwi.subject.equals("Something to do"));
            assertTrue(gwi.details.equals("test_details"));
            assertTrue(gwi.status.equals("In Progress"));

            map = gctx.getMyWorkItems("test_sprintId");
            assertTrue(map.size() >= 1 && map.size() <= 3);
            assertTrue(map.containsKey("test_workItemId"));
            assertTrue(map.get("test_workItemId") != null);
            gwi = map.get("test_workItemId");

            assertTrue(gwi.id.equals("test_workItemId"));
            assertTrue(gwi.subject.equals("Something to do"));
            assertTrue(gwi.details.equals("test_details"));
            assertTrue(gwi.status.equals("In Progress"));

            map = gctx.getWorkItems("this_should_fail");
            assertTrue(map != null);
            assertTrue(map.size() == 0);

            map = gctx.getMyWorkItems(null);
            assertTrue(map != null);
            assertTrue(map.size() == 0);

            map = gctx.getAllWorkItems("test_sprintId");
            assertTrue(map.size() >= 1 && map.size() <= 3);
            assertTrue(map.containsKey("test_workItemId"));
            assertTrue(map.get("test_workItemId") != null);
            gwi = map.get("test_workItemId");

            assertTrue(gwi.id.equals("test_workItemId"));
            assertTrue(gwi.subject.equals("Something to do"));
            assertTrue(gwi.details.equals("test_details"));
            assertTrue(gwi.status.equals("In Progress"));

            map = gctx.getAllMyWorkItems("literally_anything_here");
            assertTrue(map.size() >= 1 && map.size() <= 3);
            assertTrue(map.containsKey("test_workItemId"));
            assertTrue(map.get("test_workItemId") != null);
            gwi = map.get("test_workItemId");

            assertTrue(gwi.id.equals("test_workItemId"));
            assertTrue(gwi.subject.equals("Something to do"));
            assertTrue(gwi.details.equals("test_details"));
            assertTrue(gwi.status.equals("In Progress"));      

            gwi = gctx.getGusWorkItem("test_workItemId");
            assertTrue(gwi != null);
            assertTrue(gwi.id.equals("test_workItemId"));      
            assertTrue(gwi.details.equals("test_details"));

        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false);
        }

        boolean exc = false;
        try {
            gctx.getGusWorkItem("nope");
        } catch (JSONException e) {
            exc = true;
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false);
        }
        assertTrue(exc);
    }

    @Test
    public void testCreateWorkItem() {
        try {
            JSONObject json = new JSONObject("{\"name\":\"test card\",\"desc\":\"Description\",\"id\":\"1\"}");
            TrelloCard tc = new TrelloCard(json);
            gctx.createGusWorkItem(tc, "test_productId", "New");

            GusWorkItem gwi = gctx.getGusWorkItem(tc.gusId);
            assertTrue(gwi != null);
            assertTrue("Was expecting 'test card', was " + gwi.subject,gwi.subject.equals("test card"));
            assertTrue(gwi.details.contains("Description"));
            assertTrue(gwi.details.contains("Hash: "));
            assertTrue(gwi.details.contains("trello card: "));
            assertTrue("Was expecting 1, got " + gwi.trelloCardId,gwi.trelloCardId.equals("1"));
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false);
        }
    }

    @Test
    public void testUdpateGusWorkItem() {
        try {
            JSONObject json = new JSONObject("{\"name\":\"card name 1\",\"desc\":\"Description\",\"id\":\"1\"}");
            TrelloCard tc = new TrelloCard(json);
            gctx.createGusWorkItem(tc, "test_productId", "New");

            GusWorkItem gwi = gctx.getGusWorkItem(tc.gusId);
            assertTrue(gwi != null);
            assertTrue("Was expecting 'card name 1', was " + gwi.subject,gwi.subject.equals("card name 1"));

            gwi.setSubject("card name 2");
            System.out.println("-----------------------");
            gctx.updateGusWorkItem(gwi);
            gwi = gctx.getGusWorkItem(tc.gusId);
            assertTrue(gwi != null);
            assertTrue(gwi.subject.equals("card name 2"));
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false);
        }
    }
}