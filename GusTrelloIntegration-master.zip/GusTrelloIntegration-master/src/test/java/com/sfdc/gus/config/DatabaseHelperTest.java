package com.sfdc.gus.config;

import org.junit.Test;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import static org.junit.Assert.*;
import static org.hamcrest.Matchers.*;

import static java.lang.Math.random;
import java.util.HashMap;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Random;
import java.util.function.Consumer;

import org.apache.log4j.Logger;

import org.hibernate.cfg.Configuration;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.service.ServiceRegistry;


public class DatabaseHelperTest {

    private static DatabaseHelper dbh;

    @BeforeClass
    public static void setupDatabase() {
        dbh = createDBHelper();
    }

    public static DatabaseHelper createDBHelper() {
        long startTime = System.nanoTime();
        SessionFactory sessionFactory = null;
        try {
            Configuration hbcfg = new Configuration()
                        .configure(); // configures settings from hibernate.cfg.xml

            long startServRegTime = System.nanoTime();
            ServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder().applySettings(hbcfg.getProperties()).build();
            long endServRegTime = System.nanoTime();
            System.out.println("Create service registry time: " + (endServRegTime - startServRegTime)/1000 + " ms");

            if (! hbcfg.getProperty("hibernate.connection.url").contains("test")) {
                // This is junit. We want to be in the testing environment. If test isn't in the database name, prevent any tests from changing the DB
                System.err.println("junit tests must be ran as the test profile. Please run 'lein with-profile test junit' instead");
                sessionFactory = null;
            } else {

                long startSessFacTime = System.nanoTime();
                sessionFactory = hbcfg.buildSessionFactory(serviceRegistry);
                long endSessFacTime = System.nanoTime();
                System.out.println("Create session factory time: " + (endSessFacTime - startSessFacTime)/1000 + " ms");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        long endTime = System.nanoTime();
        System.out.println("Time to create session factory: " + (endTime-startTime)/1000 + " ms");
        if (sessionFactory != null) {
            return new DatabaseHelper(sessionFactory);
        } else {
            return null;
        }
    }

    private static List<String> usernames = new ArrayList<String>();
    public ProjectConfig createTestUser() {
        // Creates a unique project for the calling function
        String un = "testusername_" + Thread.currentThread().getStackTrace()[2].getMethodName();
        usernames.add(un);
        ProjectConfig pc = dbh.createUser(un, "testpassword", "testtoken", 10);
        return pc;
    }

    @AfterClass
    public static void closeDatabase() {
        dbh.close();
    }

    @Test
    public void refreshTest() {
        ProjectConfig testProjectConfig = createTestUser();
        try {
            ProjectConfig otherCopy = dbh.getProjectForUserId(testProjectConfig.getGusLogin().getUserId());
            otherCopy.setSyncFrequency(5);
            dbh.saveUpdate(otherCopy);

            assertNotEquals("Before updating, these two objects should be out of sync", otherCopy, testProjectConfig);

            // Check that refresh can be called on an object
            dbh.refresh(testProjectConfig, testProjectConfig.getProjectConfigId());

            assertEquals("After updating, these two objects should be completely in sync", otherCopy, testProjectConfig);
        } catch (Exception e) { throw e; }
          finally { dbh.deleteUser(testProjectConfig); }
    }

    @Test
    public void saveUpdateTest() {
        ProjectConfig testProjectConfig = createTestUser();
        try {
            testProjectConfig.setSyncFrequency(5);
            dbh.saveUpdate(testProjectConfig);

            ProjectConfig otherCopy = dbh.getProjectForUserId(testProjectConfig.getGusLogin().getUserId());
            assertEquals("After updating, these two objects should be completely in sync", otherCopy, testProjectConfig);
        } catch (Exception e) { throw e; }
        finally { dbh.deleteUser(testProjectConfig); }
    }

    @Test
    public void createDeleteProject() {
        ProjectConfig testProjectConfig = createTestUser();
        ProjectConfig newproject = dbh.createUser("testuserid", "testpassword", "testtoken", 10);
        try {
            ProjectConfig lookupuser = dbh.getProjectConfig(newproject.getProjectConfigId());

            assertThat("Project ID should exist after creation", dbh.userExists(newproject.getProjectConfigId()), is(true));
            assertThat("Username should exist after creation", dbh.userIdExists("testuserid"), is(true));
            assertThat("Trello Login is available", lookupuser.getTrelloLogin(), notNullValue());
            assertThat("Trello Login token is the one passed in", lookupuser.getTrelloLogin().getAccessToken(), is("testtoken"));
            assertEquals("Should be able to lookup a project id immediately after its creation", lookupuser, newproject);

            // We should also be able to delete all the associated ProductListMappings and Extra associations
            Map<String, String> newrel = new HashMap<String, String>();
            newrel.put("product_tag", "testproduct");
            newrel.put("gus_team", "testteam");
            newrel.put("trello_done", "testdonelist");
            newrel.put("trello_progress", "testprogresslist");
            newrel.put("trello_new", "testnewlist");
            dbh.addRelationForUser(newproject.getProjectConfigId(), newrel);

            dbh.createExtraTeamAssociation(newproject, "testteam");
            // dbh.refresh(newproject, newproject.getId());
            for (ExtraTeamAssociation ea : newproject.getExtraTeamAssociations()) {
                System.out.println("Extra team assoc: " + ea.toString());
            }
            // TODO: the number of associations is 3, but only 1 was added. The DB does not contain 3, and those 3 are all the EXACT same object(same memory address) @.@
            // assertThat("Project now has a new association", newproject.getExtraTeamAssociations(), hasSize(1));
            assertThat("Project's association is correctly the one passed in", newproject.getExtraTeamAssociations().get(0).getGusTeam().getTeamName(), is("testteam"));

            dbh.deleteUser(newproject);

            // Expectedly fail to lookup that user
            ProjectConfig failedlookupuser = dbh.getProjectConfig(newproject.getProjectConfigId());
            assertNull("After deleting, the project should not be able to be looked up", failedlookupuser);
            assertFalse("After deleting, the project should not exist", dbh.userExists(newproject.getProjectConfigId()));
            assertFalse("After deleting, the project should not exist", dbh.userIdExists("testuserid"));
        } catch (Exception e) {
            throw e;
        } finally {
            dbh.deleteUser(testProjectConfig);
            // If the testing goes as expected, newproject will have already been deleted
            // this deletion must remain, however, just in case one of the earlier assertions fails
            if (dbh.userExists(newproject.getProjectConfigId())) {
                dbh.deleteUser(newproject);
            }
        }
    }

    @Test
    public void relationCreateDeleteTest() {
        ProjectConfig testProjectConfig = createTestUser();
        try {
            Map<String, String> newrel = new HashMap<String, String>();

            newrel.put("product_tag", "testproduct");
            newrel.put("gus_team", "testteam");
            newrel.put("trello_done", "testdonelist");
            newrel.put("trello_progress", "testprogresslist");
            newrel.put("trello_new", "testnewlist");
            // Note: this part uses the function by Id
            dbh.addRelationForUser(testProjectConfig.getProjectConfigId(), newrel);

            // We expect 3 mappings to have been made, one per status: DONE, IN_PROGRESS, and COMPLETED
            ProductListMapping[] mappingfound = new ProductListMapping[3];
            // Verify that the mapping exists
            dbh.refresh(testProjectConfig, testProjectConfig.getProjectConfigId());
            List<ProductListMapping> mappings = testProjectConfig.getProductListMappings();
            for (ProductListMapping plm : mappings) {
                if (plm.getGusProduct().getProductName().equals("testproduct")
                        && plm.getGusProduct().getGusTeam().getTeamName().equals("testteam")) {

                    switch (plm.getGusStatus()) {
                        case NEW:
                            if (plm.getTrelloList().getListName().equals("testnewlist")) {
                                mappingfound[0] = plm;
                            }
                            break;
                        case IN_PROGRESS:
                            if (plm.getTrelloList().getListName().equals("testprogresslist")) {
                                mappingfound[1] = plm;
                            }
                            break;
                        case COMPLETED:
                            if (plm.getTrelloList().getListName().equals("testdonelist")) {
                                mappingfound[2] = plm;
                            }
                            break;
                    }
                }
            }

            assertThat("All the mappings must be found", mappingfound, array(notNullValue(), notNullValue(), notNullValue()));
            assertThat("Newly created ProductListMappings should default to being enabled", mappingfound[0].isSyncEnabled(), is(true));
            assertThat("Newly created ProductListMappings should default to being enabled", mappingfound[1].isSyncEnabled(), is(true));
            assertThat("Newly created ProductListMappings should default to being enabled", mappingfound[2].isSyncEnabled(), is(true));

            // Status verifications
            assertThat("New Status's string name is correct", mappingfound[0].getGusStatus().getName(), is ("New"));
            assertThat("In Progress Status's string name is correct", mappingfound[1].getGusStatus().getName(), is ("In Progress"));
            assertThat("Closed Status's string name is correct", mappingfound[2].getGusStatus().getName(), is ("Closed"));

            // Mutual reference with product & list
            assertThat("The ProductListMapping is referencable by the Product", mappingfound[0].getGusProduct().getProductListMappings(), hasItems(mappingfound[0], mappingfound[1], mappingfound[2]));

            // Delete the mappings
            for (ProductListMapping plm : mappingfound) {
                dbh.removeRelationForUser(testProjectConfig.getProjectConfigId(), plm.getProductListMappingId()+"");
            }

            // Verify they were appropriately deleted
            // We expect NOT to find those mappings
            dbh.refresh(testProjectConfig, testProjectConfig.getProjectConfigId());
            mappings = testProjectConfig.getProductListMappings();

            for (ProductListMapping previouslyFound : new ArrayList<ProductListMapping>(Arrays.asList(mappingfound))) {
                assertThat("The previously found mappings must not be found", mappings, not(contains(previouslyFound)));
            }

        } catch (Exception e) { throw e; }
        finally { dbh.deleteUser(testProjectConfig); }
    }

    // Note: this winds up testing the success of getTrelloAPIKey, getGlobalProperty, and setGlobalProperty,
    // all using the key "appkey" (trello API key identifier)
    @Test
    public void getSetTrelloAPIKey() {
        // Save the current one, just in case we accidently get the real one
        String startingAppkey = dbh.getTrelloAPIKey();

        // Set the API key
        dbh.setGlobalProperty("appkey", "TESTAPPKEY");

        assertThat("Appkey must be changed", dbh.getTrelloAPIKey(), is("TESTAPPKEY"));

        // Put the old key back. Since we now know that setting works, this will be successful
        dbh.setGlobalProperty("appkey", startingAppkey);
    }

    @Test
    public void getSetGlobalConfig() {
        // Should guarantee uniqueness for the test
        String testkey = "testkey" + random();

        dbh.setGlobalProperty(testkey, "TESTVALUE");
        assertThat("A set value should equal what it was set to", dbh.getGlobalProperty(testkey), is("TESTVALUE"));

        dbh.setGlobalProperty(testkey, null);
        assertThat("A set value should equal what it was set to", dbh.getGlobalProperty(testkey), nullValue());

        dbh.setGlobalProperty(testkey, "TESTVALUE");
        dbh.unsetGlobalProperty(testkey);
        assertThat("An unset value should be looked up as null", dbh.getGlobalProperty(testkey), nullValue());

    }

    @Test
    public void lookupProductTest() {
        ProjectConfig testProjectConfig = createTestUser();
        try {
            // When a new product/team is made, it is saved in the DB.
            // When another mapping comes along with the same product ande team

            Map<String, String> newrel = new HashMap<String, String>();
            newrel.put("product_tag", "testproduct1");
            newrel.put("gus_team", "testteam1");
            newrel.put("trello_done", "testdonelist1");
            newrel.put("trello_progress", "testprogresslist1");
            newrel.put("trello_new", "testnewlist1");

            // Create one mapping, which should create the product and team
            List<ProductListMapping> newmaps1 = dbh.addRelationForUser(testProjectConfig, newrel);

            // Create a second, but with the same team name, and everything else different
            newrel.put("product_tag", "testproduct2");
            newrel.put("gus_team", "testteam1");
            newrel.put("trello_done", "testdonelist2");
            newrel.put("trello_progress", "testprogresslist2");
            newrel.put("trello_new", "testnewlist2");
            List<ProductListMapping> newmaps2 = dbh.addRelationForUser(testProjectConfig, newrel);

            // Check that the database IDs for the teams are the same
            long teamid = newmaps1.get(0).getGusProduct().getGusTeam().getGusTeamId();
            long productid = newmaps1.get(0).getGusProduct().getGusProductId();
            assertThat("A new relation with the same team name will use the exact same team as one previously created"
                    , newmaps2.get(0).getGusProduct().getGusTeam().getGusTeamId()
                    , equalTo(newmaps1.get(0).getGusProduct().getGusTeam().getGusTeamId()));

            // Repeat, but with the product being the same (and the team, since the product is a child of the team)
            newrel.put("product_tag", "testproduct1");
            newrel.put("gus_team", "testteam1");
            newrel.put("trello_done", "testdonelist3");
            newrel.put("trello_progress", "testprogresslist3");
            newrel.put("trello_new", "testnewlist3");
            List<ProductListMapping> newmaps3 = dbh.addRelationForUser(testProjectConfig, newrel);

            // Check that the database IDs for the products are the same
            assertThat("A new relation with the same product name and team name will use the exact same product as one previously created"
                    , newmaps3.get(0).getGusProduct().getGusProductId()
                    , equalTo(newmaps1.get(0).getGusProduct().getGusProductId()));

            // Delete all the mappings
            Consumer<ProductListMapping> deleter = (plm)->{ dbh.removeRelationForUser(testProjectConfig.getProjectConfigId(), plm.getProductListMappingId()+""); };
            newmaps1.stream().forEach(deleter);
            newmaps2.stream().forEach(deleter);
            newmaps3.stream().forEach(deleter);

            // It's still expected that a newly created mapping will use the same team/product as the one used by a deleted ProductListMapping
            // Note: this implies that removeRelationForUser does not delete teams/products
            newrel.put("product_tag", "testproduct1");
            newrel.put("gus_team", "testteam1");
            newrel.put("trello_done", "testdonelist4");
            newrel.put("trello_progress", "testprogresslist4");
            newrel.put("trello_new", "testnewlist4");
            List<ProductListMapping> newmaps4 = dbh.addRelationForUser(testProjectConfig, newrel);

            assertThat("A new relation uses the same team as a mapping that was deleted"
                    , newmaps4.get(0).getGusProduct().getGusTeam().getGusTeamId()
                    , is(teamid));
            assertThat("A new relation uses the same product as a mapping that was deleted"
                    , newmaps4.get(0).getGusProduct().getGusProductId()
                    , is(productid));

            // When using a definitely unique team/product, make sure that they get inserted/used appropriately
            String randTeam = "testteam" + random();
            String randProduct = "testproduct" + random();

            // Will create team and product
            GusTeam gt = dbh.lookupOrCreateTeam(randTeam);
            GusProduct gp = dbh.lookupOrCreateProduct(randProduct, randTeam);
            assertThat("Looking up a product under a team that has been created will reference the same team", gp.getGusTeam(), is(gt));
            assertThat("Product's team is not null", gp.getGusTeam(), notNullValue());

            // A re-lookup should yield the same object
            assertThat("A new lookup will be the same object", dbh.lookupOrCreateProduct(randProduct, randTeam), is(gp));

            // Deleting the product doesn't affect the team
            dbh.deleteProduct(gp);
            assertThat("A new list uses the same board as a list that was deleted", dbh.lookupOrCreateProduct(randProduct, randTeam).getGusTeam(), is(gt));

            // Cleanup, also testing recursive team-product deletion
            dbh.deleteTeam(gp.getGusTeam());

            // A lookup again should yield a NEW object
            GusProduct newGp = dbh.lookupOrCreateProduct(randProduct, randTeam);
            assertThat("Product's team is not null", gp.getGusTeam(), notNullValue());
            assertThat("A lookup after deletion should reference a new object", newGp, not(is(gp)));

            dbh.deleteTeam(newGp.getGusTeam());

            // Delete this newly created mapping too
            newmaps4.stream().forEach(deleter);
        } catch (Exception e) { throw e; }
        finally { dbh.deleteUser(testProjectConfig); }
    }

    @Test
    public void lookupListTest() {
        ProjectConfig testProjectConfig = createTestUser();
        try {

            Map<String, String> newrel = new HashMap<String, String>();
            newrel.put("product_tag", "testproduct1");
            newrel.put("gus_team", "testteam1");
            newrel.put("trello_done", "testdonelist1");
            newrel.put("trello_progress", "testprogresslist1");
            newrel.put("trello_new", "testnewlist1");

            // Create one mapping, which should create the list
            List<ProductListMapping> newmaps1 = dbh.addRelationForUser(testProjectConfig, newrel);

            // Create a second, but with the same list (trello_new), and everything else different
            newrel.put("product_tag", "testproduct2");
            newrel.put("gus_team", "testteam2");
            newrel.put("trello_done", "testdonelist2");
            newrel.put("trello_progress", "testprogresslist2");
            newrel.put("trello_new", "testnewlist1");
            List<ProductListMapping> newmaps2 = dbh.addRelationForUser(testProjectConfig, newrel);

            // Check that the database IDs for the lists are the same
            long listid = newmaps1.get(2).getTrelloList().getTrelloListId();;
            assertThat("A new relation with the same list name will use the exact same list as one previously created"
                    , newmaps2.get(2).getTrelloList().getTrelloListId()
                    , equalTo(newmaps1.get(2).getTrelloList().getTrelloListId()));

            // Delete all the mappings
            Consumer<ProductListMapping> deleter = (plm)->{ dbh.removeRelationForUser(testProjectConfig.getProjectConfigId(), plm.getProductListMappingId()+""); };
            newmaps1.stream().forEach(deleter);
            newmaps2.stream().forEach(deleter);

            // It's still expected that a newly created mapping will use the same team/product as the one used by a deleted ProductListMapping
            // Note: this implies that removeRelationForUser does not delete teams/products
            newrel.put("product_tag", "testproduct4");
            newrel.put("gus_team", "testteam4");
            newrel.put("trello_done", "testdonelist4");
            newrel.put("trello_progress", "testprogresslist4");
            newrel.put("trello_new", "testnewlist1");
            List<ProductListMapping> newmaps4 = dbh.addRelationForUser(testProjectConfig, newrel);

            assertThat("A new relation uses the same list as a mapping that was deleted"
                    , newmaps4.get(2).getTrelloList().getTrelloListId()
                    , is(listid));

            // Delete this newly created mapping too
            newmaps4.stream().forEach(deleter);

            // When using a definitely unique team/product, make sure that they get inserted/used appropriately
            String randBoard = "testteam" + random();
            String randList = "testproduct" + random();

            // Will create team and product
            TrelloBoard tb = dbh.lookupOrCreateBoard(randBoard);
            TrelloList tl = dbh.lookupOrCreateList(randList, randBoard);
            assertThat("List's team is not null", tl.getTrelloBoard(), notNullValue());

            // A re-lookup should yield the same object
            assertThat("Looking up a list under a board that has been created will reference the same board", tl.getTrelloBoard(), is(tb));
            assertThat("A new lookup will be the same object", dbh.lookupOrCreateList(randList, randBoard), is(tl));

            // Deleting the list doesn't affect the board
            dbh.deleteList(tl);
            assertThat("A new list uses the same board as a list that was deleted", dbh.lookupOrCreateList(randList, randBoard).getTrelloBoard(), is(tb));

            // Cleanup, also testing recursive team-product deletion
            dbh.deleteBoard(tl.getTrelloBoard());

            // A lookup again should yield a NEW object
            TrelloList newTl = dbh.lookupOrCreateList(randList, randBoard);
            assertThat("List's team is not null", tl.getTrelloBoard(), notNullValue());
            assertThat("A lookup after deletion should reference a new object", newTl, not(is(tl)));

            dbh.deleteBoard(newTl.getTrelloBoard());

        } catch (Exception e) { throw e; }
        finally { dbh.deleteUser(testProjectConfig); }
    }

    @Test
    public void createExtraAssociationTest() {
        ProjectConfig testProjectConfig = createTestUser();
        try {
            dbh.createExtraTeamAssociation(testProjectConfig, "testteam");

            assertThat("After adding an association, one was added", testProjectConfig.getExtraTeamAssociations(), hasSize(1));
            ExtraTeamAssociation ea = testProjectConfig.getExtraTeamAssociations().get(0);
            assertThat("After adding an association, the one that was added can be looked up", ea.getGusTeam().getTeamName(), is("testteam"));
            assertThat("ProjectConfig pointer in extra association is created correctly", ea.getProjectConfig(), is(testProjectConfig));
            assertThat("ExtraAssociation has an assigned ID", ea.getExtraTeamAssociationId(), notNullValue());

            dbh.deleteExtraTeamAssociation(testProjectConfig.getExtraTeamAssociations().get(0));

            dbh.refresh(testProjectConfig, testProjectConfig.getProjectConfigId());
            assertThat("After deleting an association, it must not show up", testProjectConfig.getExtraTeamAssociations(), empty());
        } finally {
            dbh.deleteUser(testProjectConfig);
        }
    }

    @Test
    public void gusStatusStringTest() {
        assertThat("GusStatus lookup by name works correctly", GusStatus.valueOf("NEW"), is(GusStatus.NEW));
        assertThat("GusStatus lookup by name works correctly", GusStatus.valueOf("IN_PROGRESS"), is(GusStatus.IN_PROGRESS));
        assertThat("GusStatus lookup by name works correctly", GusStatus.valueOf("COMPLETED"), is(GusStatus.COMPLETED));
    }

    @Test
    public void toStringTest() {
        // Verify that all the toString functions work (work == generates a non-null string)
        GlobalKVConfig gkvs = new GlobalKVConfig();
        assertThat("GlobalKVConfig can be represented as a String", gkvs.toString(), notNullValue());

        GusLogin gl = new GusLogin("testun", "testpw");
        assertThat("GusLogin can be represented as a String", gl.toString(), notNullValue());
        TrelloLogin tlogin = new TrelloLogin("testkey");
        assertThat("TrelloLogin can be represented as a String", tlogin.toString(), notNullValue());
        ProjectConfig pc = new ProjectConfig(10, gl, tlogin);
        assertThat("ProjectConfig can be represented as a String", pc.toString(), notNullValue());

        GusTeam gt = new GusTeam("testteam");
        assertThat("GusTeam can be represented as a String", gt.toString(), notNullValue());
        GusProduct gp = new GusProduct("testproduct", gt);
        assertThat("GusProduct can be represented as a String", gp.toString(), notNullValue());

        ExtraTeamAssociation eta = new ExtraTeamAssociation(pc, gt);
        assertThat("ExtraTeamAssociation can be represented as a String", eta.toString(), notNullValue());

        TrelloBoard tb = new TrelloBoard("testboard");
        assertThat("TrelloBoard can be represented as a String", tb.toString(), notNullValue());
        TrelloList tl = new TrelloList("testlist", tb);
        assertThat("TrelloList can be represented as a String", tl.toString(), notNullValue());

        ProductListMapping plm = new ProductListMapping(tl, gp, GusStatus.valueOf("NEW"), true, pc);
        assertThat("ProductListMapping can be represented as a String", plm.toString(), notNullValue());

        // valueOf(String) is used solely to increase coverage of the enum
        FilterSet fs = new FilterSet(FilterRuleType.valueOf("IMPORT"), FilterSource.valueOf("GUS"), plm);
        assertThat("FilterSet can be represented as a String", fs.toString(), notNullValue());
        FilterItem fi = new FilterItem("testkeyword", fs);
        assertThat("FilterItem can be represented as a String", fi.toString(), notNullValue());


    }

    @Test
    public void hashCodeTest() {
        // Verify that all the hashCode functions work (work == generates a non-null string)
        GlobalKVConfig gkvs = new GlobalKVConfig();
        assertThat("GlobalKVConfig can be represented as a String", gkvs.hashCode(), notNullValue());

        GusLogin gl = new GusLogin("testun", "testpw");
        assertThat("GusLogin can be represented as a String", gl.hashCode(), notNullValue());
        TrelloLogin tlogin = new TrelloLogin("testkey");
        assertThat("TrelloLogin can be represented as a String", tlogin.hashCode(), notNullValue());
        ProjectConfig pc = new ProjectConfig(10, gl, tlogin);
        assertThat("ProjectConfig can be represented as a String", pc.hashCode(), notNullValue());

        GusTeam gt = new GusTeam("testteam");
        assertThat("GusTeam can be represented as a String", gt.hashCode(), notNullValue());
        GusProduct gp = new GusProduct("testproduct", gt);
        assertThat("GusProduct can be represented as a String", gp.hashCode(), notNullValue());

        ExtraTeamAssociation eta = new ExtraTeamAssociation(pc, gt);
        assertThat("ExtraTeamAssociation can be represented as a String", eta.hashCode(), notNullValue());

        TrelloBoard tb = new TrelloBoard("testboard");
        assertThat("TrelloBoard can be represented as a String", tb.hashCode(), notNullValue());
        TrelloList tl = new TrelloList("testlist", tb);
        assertThat("TrelloList can be represented as a String", tl.hashCode(), notNullValue());

        ProductListMapping plm = new ProductListMapping(tl, gp, GusStatus.valueOf("NEW"), true, pc);
        assertThat("ProductListMapping can be represented as a String", plm.hashCode(), notNullValue());
        
        // valueOf(String) is used solely to increase coverage of the enum
        FilterSet fs = new FilterSet(FilterRuleType.valueOf("IMPORT"), FilterSource.valueOf("GUS"), plm);
        assertThat("FilterSet can be represented as a String", fs.hashCode(), notNullValue());
        FilterItem fi = new FilterItem("testkeyword", fs);
        assertThat("FilterItem can be represented as a String", fi.hashCode(), notNullValue());


    }
}
