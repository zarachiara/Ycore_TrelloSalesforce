package com.sfdc.gus;

import static org.junit.Assert.*;
import static org.hamcrest.Matchers.*;
import org.junit.Test;

import java.net.URL;
import java.nio.file.Files;
import java.nio.file.FileSystems;

import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.boot.registry.classloading.spi.ClassLoaderService;

public class EndpointPropertiesTest {

    @Test
    public void loadedProperly() {
        /*
        // ls the root of the execution path
        boolean byURL = false;
        try {
            new URL("endpoint.properties").openStream().close();
        } catch (Exception e) { System.out.println("Cannot find endpoint.properties as a URL"); }

        boolean byLoader = false;
        try {
            new StandardServiceRegistryBuilder().getBootstrapServiceRegistry().getService(ClassLoaderService.class).locateResourceStream("endpoint.properties").close();
        } catch (Exception e) { System.out.println("Cannot find endpoint.properties using Hibernate ClassLoader"); }

        assertThat("Either the URL or Loader method has resulted in successfully loading the endpoint.properties", byURL || byLoader, is(true));
        */
        
        assertThat("Chosen endpoint is non-default.", GusContext.GUS_ENDPOINT, not(is("https://gus.my.salesforce.com")));
        assertThat("Chosen endpoint is non-default.", TrelloContext.TRELLO_SERVER, not(is("https://gus.my.salesforce.com")));
    }
}
