package com.sfdc.gus.security;

import org.junit.Test;
import static org.junit.Assert.*;

public class AESDualCryptTest {

	@Test
	public void testEncryptionAndDecryption() throws Exception {
		String original = "HomerIsMyHero";
        String fakepassphrase = "passphrase";

        AESDualCrypt crypter = new AESDualCrypt(fakepassphrase);

        String enc = crypter.encrypt(original);
        String dec = crypter.decrypt(enc);

        assertEquals("Decrypted string must be the same as the original. "
                    + "Decrypted: " + dec + " original: " + original
                , dec
                , original);
	}

    @Test
    public void testRandomIV() throws Exception {
        // It's expected in AES encryption that a single string is not encrypted
        // the same way twice.

		String original = "HomerIsMyHero";
        String fakepassphrase = "passphrase";

        AESDualCrypt crypter = new AESDualCrypt(fakepassphrase);

        String enc1 = crypter.encrypt(original);
        String enc2 = crypter.encrypt(original);

        assertNotEquals("Encrypting the same thing twice should yield different "
                    + "encrypted strings. First: " + enc1 + " Second: " + enc2
                , enc1
                , enc2);

        String dec1 = crypter.decrypt(enc1);
        String dec2 = crypter.decrypt(enc2);

        // We'd also expect that their decryptions are both equal, and equal to the original
        assertEquals("Encrypted strings, though different, must decrypt to the same string"
                , dec1
                , dec2);

        assertEquals("Decrypted string must be the same as the original. "
                    + "Decrypted: " + dec1 + " original: " + original
                , dec1
                , original);
    }
}
