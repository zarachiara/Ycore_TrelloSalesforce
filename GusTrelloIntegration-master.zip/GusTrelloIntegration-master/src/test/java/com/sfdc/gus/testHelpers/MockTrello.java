package com.sfdc.gus.testHelpers;

import java.util.ArrayList;
import java.util.List;
import java.util.HashMap;
import java.util.Map;

import spark.Spark;

public class MockTrello {
    Spark spark;

    public void stop() {
        spark.stop();
    }

    Map<String, String> cards;
    String card1 = "{\"name\":\"card 1\",\"desc\":\"Description\",\"id\":\"card1\",\"actions\":[{\"idMemberCreator\":\"test_trello_user_id\"}]}";
    String card2 = "{\"name\":\"card 2\",\"desc\":\"Description\",\"id\":\"card2\",\"actions\":[{\"idMemberCreator\":\"not_test_trello_user_id\"}]}";

    public void run() {
        cards = new HashMap<String, String>();
        cards.put("card1",card1);
        cards.put("card2",card2);

        spark = new Spark();
        spark.port(8888);

        spark.get("/", (request, response) -> {
            return "{\"response\":\"success\"}";
        });

        spark.get("/members/me", (request, response) -> {
            if(request.queryParams("key").equals("test_APIKey") && request.queryParams("token").equals("test_accessToken"))
                return "{\"id\":\"test_trello_user_id\"}";
            return "{}";
        });

        spark.get("/members/my/boards", (request, response) -> {
            if(request.queryParams("key").equals("test_APIKey") && request.queryParams("token").equals("test_accessToken"))
                return "[{\"id\":\"test_board_id\",\"name\":\"Test Board\",\"closed\":\"false\"},{\"id\":\"test_board_id1\",\"name\":\"Test Board 2\",\"closed\":\"true\"}]";
            return "[aoeuaeou";
        });

        spark.get("/boards/:board/lists", (request, response) -> {
            if(request.queryParams("key").equals("test_APIKey") && request.queryParams("token").equals("test_accessToken")) {
                String boardId = request.params("board");
                switch (boardId) {
                    case "test_board_id":
                        return "[{\"id\":\"list1\",\"name\":\"List 1\"},{\"id\":\"list2\",\"name\":\"List 2\"},{\"id\":\"list3\",\"name\":\"List 3\"}]";
                    default: 
                        return "[{\"id\":\"id\",\"name\":\"name\"}]";
                }
            }
            return "[]";           
        });

        spark.get("/lists/:listId/cards", (request, response) -> {
            if(request.queryParams("key").equals("test_APIKey") && request.queryParams("token").equals("test_accessToken")) {
                String listId = request.params("listId");
                switch (listId) {
                    case "list1":
                        String cardsStr = "[";
                        for (String cardId : cards.keySet()) {
                            cardsStr += cards.get(cardId);
                        }
                        cardsStr += "]";
                        cardsStr = cardsStr.replace("}{","},{").replace("\n","\\n");
                        return cardsStr;
                }
            }
            return "[]";
        });

        spark.get("/cards/:cardId", (request, response) -> {
            if(request.queryParams("key").equals("test_APIKey") && request.queryParams("token").equals("test_accessToken")) {
                String cardId = request.params("cardId");
                String card = cards.get(cardId).replace("\n","\\n");
                System.out.println("----------------Returning: " + card);
                if(card != null) return card;
            }
            return "{}";
        });

        spark.post("/lists/:listId/cards", (request, response) -> {
            if(request.queryParams("key").equals("test_APIKey") && request.queryParams("token").equals("test_accessToken") &&request.params("listId").equals("list1")) {
                String newCard = "{\"id\":\""+request.queryParams("name")+"\",\"name\":\""+request.queryParams("name")+"\",\"desc\":\""+request.queryParams("desc").replace("\n","\\n")+"\",\"actions\":[{\"idMemberCreator\":\"test_trello_user_id\"}]}";
                System.out.println("New Card: " + newCard);
                cards.put(request.queryParams("name"),newCard);
                return newCard;
            }
            return "{}";
        });

        spark.put("/cards/:cardId/:field", (request, response) -> {
            if(request.queryParams("key").equals("test_APIKey") && request.queryParams("token").equals("test_accessToken")) {
                String cardId = request.params("cardId");
                String field = request.params("field");
                String card = cards.get(cardId);
                int idx = 0;
                if(card != null && (idx = card.indexOf(field)) > -1) {
                    int end = card.indexOf('"',idx+field.length()+3);
                    String newCard = card.substring(0,idx+field.length()+3) + request.queryParams("value") + card.substring(end);
                    cards.put(cardId,newCard);
                }
            }
            return "";
        });
    }
}