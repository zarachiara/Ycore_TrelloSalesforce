package com.sfdc.gus.testHelpers;

import java.util.ArrayList;
import java.util.List;
import java.util.HashMap;
import java.util.Map;
import java.util.Iterator;
import java.util.Random;

import org.apache.commons.lang3.tuple.Pair;
import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.json.JSONException;

import spark.Spark;
import spark.Request;

import org.apache.commons.codec.binary.Base64;

import org.apache.http.entity.StringEntity;
import org.apache.http.client.entity.GzipDecompressingEntity;

import com.sfdc.gus.GusContext;

public class MockGus {

    Spark spark;

    Logger logger = Logger.getLogger(MockGus.class);

    Map<String, String> workItems;

    boolean rejectEverything = false;

    public MockGus() {
        
    }

    public void stop() {
        spark.stop();
    }

    public void run() {
        workItems = new HashMap<String, String>();

        spark = new Spark();
        // spark.secure("keystore.jks", "L1nuxRocks!", null, null);
        spark.port(7757);

        spark.get("/", (request, response) -> {
           return "{\"response\":\"success\"}";
        });

        spark.before("/services/*", (request, response) -> {
            if(rejectEverything) {
                System.out.println("REDIRECTING FROM " + request.url());
                response.redirect("/reject");
            }
        });

        spark.get("/first_token", (request, response) -> {
            System.out.println("Got first token thingy");
            response.redirect("https://localhost:4567/sfcallback?code=test_code&");
            return "";
        });

        spark.post("/services/oauth2/token", (request, response) -> {
            System.out.println("-------------------OAUTH ACHIEVED... SORTA");
            return "{\"id\":\"0000000000000000test_userId\",\"access_token\":\"test_sessionId\",\"refresh_token\":\"test_refreshToken\"}";
        });

        spark.get("/reject", (request, response) -> {
            System.out.println("REJECTING ");
            return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:sf=\"urn:fault.partner.soap.sforce.com\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"><soapenv:Body><soapenv:Fault><faultcode>INVALID_LOGIN</faultcode><faultstring>INVALID_LOGIN: Invalid username, password, security token; or user locked out.</faultstring><detail><sf:LoginFault xsi:type=\"sf:LoginFault\"><sf:exceptionCode>INVALID_LOGIN</sf:exceptionCode><sf:exceptionMessage>Invalid username, password, security token; or user locked out.</sf:exceptionMessage></sf:LoginFault></detail></soapenv:Fault></soapenv:Body></soapenv:Envelope>";
        });

        spark.get("/start_rejecting", (request, response) -> {
            System.out.println("--------------------REJECTING EVERYTHING");
            rejectEverything = true;
            return "{}";
        });

        spark.get("/stop_rejecting", (request, response) -> {
            System.out.println("--------------------STOPPING REJECTING EVERYTHING");
            rejectEverything = false;
            return "{}";
        });

        spark.post("/services/oauth2/token", (request, response) -> {
            return "{\"access_token\":\"test_sessionId\"}";
        });

        spark.post(GusContext.GUS_SOAP_URI, (request, response) -> {
            return "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" +
                "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">" +
                    "<soapenv:Body>" +
                        "<loginResponse xmlns=\"urn:enterprise.soap.sforce.com\">" +
                            "<result>" +
                                "<passwordExpired>false</passwordExpired>" +
                                "<serverUrl>http://localhost:7757"+GusContext.GUS_SOAP_URI+"/logout</serverUrl>" +
                                "<sessionId>test_sessionId</sessionId>" +
                                "<userId>test_userId</userId>" +
                            "</result>" +
                        "</loginResponse>" +
                    "</soapenv:Body>" +
                "</soapenv:Envelope>";
        });

        spark.post(GusContext.GUS_SOAP_URI + "/logout", (request, response) -> {
            return "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" +
                "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">" +
                    "<soapenv:Body>" +
                        "<logoutResponse xmlns=\"urn:enterprise.soap.sforce.com\">" +
                        "</logoutResponse>" +
                    "</soapenv:Body>" +
                "</soapenv:Envelope>";
        });

        spark.get("/services/data/*/query/", (request, response) -> {
            if(request.headers("Authorization") == null || !request.headers("Authorization").equals("Bearer test_sessionId")) return "";
            String[] tokens = request.queryParams("q").split(" ");
            List<String> fields = new ArrayList<String>();
            for(String str : tokens) {
                if(str.equals("SELECT")) continue;
                if(str.equals("FROM")) continue;
                fields.add(str);
            }

            String from = null;
            Boolean from_flag = false;
            for(String str : tokens) {
                if(from_flag) {
                    from = str;
                    break;
                }
                if(str.equals("FROM")) from_flag = true;
            }
            System.out.println("Performing a query with the FROM as " + from);

            List<String> where = new ArrayList<String>();
            Boolean where_flag = false;
            for(String str : tokens) {
                if(where_flag) where.add(str);
                if(str.equals("WHERE")) where_flag = true;
            }

            return processQuery(fields, from, where).replace("\n","\\n");

            //return "{\"totalSize\":1,\"done\":true,\"records\":[{\"attributes\":{\"type\":\"User\",\"url\":\"/services/data/v29.0/sobjects/User/005B00000015i6hIAA\"},\"Id\":\"005B00000015i6hIAA\"}],\"aoeu\":"+q+"}";
        });

        spark.post(GusContext.GUS_REST_URI+"/sobjects/ADM_Work__c/", (request, response) -> {
            String gwi = createNewCard(request.body()).replace("\n","\\n");
            System.out.println("Returning: " + gwi);
            return gwi;

        });

        spark.get(GusContext.GUS_REST_URI+"/sobjects/ADM_Work__c/:id", (request, response) -> {
            System.out.println(request.params("id")+"|"+workItems);
            if(request.params("id").equals("test_workItemId")) {
                return "{\"Id\":\"test_workItemId\"" +
                        ",\"Name\":\"test_workItemName\"" +
                        ",\"Details__c\":\"test_details\"" +
                        ",\"Status__c\":\"In Progress\"" +
                        ",\"Subject__c\":\"Something to do\"" +
                        ",\"Story_Points__c\":null}";
            } else if(workItems.containsKey(request.params("id"))) {
                return workItems.get(request.params("id")).replace("\n","\\n");
            } else {
                return "[{\"errorCode\":\"NOT_FOUND\",\"message\":\"Provided external ID field does not exist or is not accessible: not_valid_id\"}]";
            } 
        });

        spark.get("/*", (request, response) -> {
            System.out.println("Received: " + request.url());
            return "";
        });

        spark.patch(GusContext.GUS_REST_URI+"/sobjects/ADM_Work__c/:id", (request, response) -> {
            Map<String, String> map = null;
            try {
                map = toMap(new JSONObject(request.body()));
                System.out.println(map);
            } catch (Exception e) {
                e.printStackTrace();
            }
            if (map != null) {
                String id = request.params("id");
                for (String field : map.keySet()) {
                    String wi = workItems.get(id);
                    int idx = 0;
                    if(wi != null && (idx = wi.indexOf(field)) > -1) {
                        int end = wi.indexOf('"',idx+field.length()+3);
                        String nwi = wi.substring(0,idx+field.length()+3) + map.get(field) + wi.substring(end);
                        System.out.println("Old: " + wi + ", New: " + nwi);
                        workItems.put(id,nwi);
                    }
                }
                
            }
            return "";
        });
    }

    /*
     * So... SOAP Login for the MockGUS is weird. All we ask for (RestUtil.soapLogin) is
     * a session id. Well, that always happens. We always start a new session. Once we
     * have a session id, we start querying for User info in order to verify login. If
     * that fails, we know our session is not properly authenticated.
     *
    public String soapLogin(Request req) {
        logger.debug("Login request with params:");
        for (Map.Entry param : req.params().entrySet()) {
            logger.debug(param.getKey() + " -> " + param.getValue());
        }
        logger.debug("Login headers:");
        for (String h : req.headers()) {
            logger.debug(h + ": " + req.headers(h));
        }
        logger.debug("Login attributes:");
        for (String a : req.attributes()) {
            logger.debug(a + ": " + req.attribute(a));
        }
        logger.debug("Login query params");
        for (String q : req.queryParams()) {
            logger.debug(q + ": " + req.queryParams(q));
        }
        // logger.debug("Login body:");
        // logger.debug(req.body());

        // Is the body Base64?
        String unencoded = new String(Base64.decodeBase64(req.body()));
        logger.debug("Unencoded: " + unencoded);

        // decompress the GZIP body
        try {
            logger.debug("Un-GZIPing the body");
            byte[] decompBytes = new byte[1024];
            int numBytes = new GzipDecompressingEntity(new StringEntity(req.body())).getContent().read(decompBytes);
            String uncompressed = new String(decompBytes);
            logger.debug("gunzipped: " + uncompressed);
        } catch (Exception e) {
            e.printStackTrace();
        }
        logger.debug("Login processing done");

        return "{\"response\":\"success\"}";
    }
    */

    private String processQuery(List<String> fields, String from, List<String> condition) {
        if(condition.size() > 2 && condition.get(2).contains("this_should_fail")) {
            return "{\"totalSize\":0,\"done\":true,\"records\":[]}";
        }
        switch(from) {
            case "User":
                return getUser(condition);
            case "ADM_Sprint__c":
                return "{\"totalSize\":1,\"done\":true,\"records\":[{\"Id\":\"test_sprintId\",\"Name\":\"test_sprintName\"}]}";
            case "ADM_Scrum_Team__c":
                return "{\"totalSize\":1,\"done\":true,\"records\":[{\"Id\":\"test_teamId\"}]}";
            case "ADM_Scrum_Team_Member__c":
                return "{\"totalSize\":1,\"done\":true,\"records\":[{\"Scrum_Team__r\":{\"Name\":\"test_teamName\",\"Id\":\"test_teamId\"}}]}";
            case "ADM_Product_Tag__c":
                return "{\"totalSize\":1,\"done\":true,\"records\":[{\"Id\":\"test_productId\",\"Name\":\"test_productName\"}]}";
            case "ADM_Work__c":
                String wi = "{\"totalSize\":"+(workItems.size()+1)+",\"done\":true,\"records\":["+
                        "{\"Id\":\"test_workItemId\"" +
                        ",\"Name\":\"test_workItemName\"" +
                        ",\"Details__c\":\"test_details\"" +
                        ",\"Status__c\":\"In Progress\"" +
                        ",\"Subject__c\":\"Something to do\"" +
                        ",\"Story_Points__c\":null}";
                for(String work : workItems.values()) {
                    wi += ","+work;
                }
                return wi + "]}";
            default:
                // Return query with 0 returned records
                return "{\"totalSize\":0,\"done\":true,\"records\":[]}";
        }
    }


    // private String lookupUserId(String username) { 
    //     System.out.println("Looking up user " + username);
    //     return lookupId(username, users); 
    // }

    // private String lookupId(String key, Map<String, String> map) {
    //     System.out.println("Looking up " + key + " from " + map);
    //     if (map.containsKey(key)) {
    //         return map.get(key);
    //     } else {
    //         // Generate a new unique id, save it, and return that
    //         // Starting id is 0
    //         String nextId = "000000000000000000";
    //         int nextIdInt = 0;
    //         for (String userid : map.values()) {
    //             int useridint = Integer.parseInt(userid);
    //             if (useridint >= nextIdInt) {
    //                 nextIdInt = useridint + 1;
    //                 nextId = String.format("%018d", nextIdInt);
    //             }
    //         }
    //         System.out.println("Adding user " + key + " with id " + nextId + " to " + map);
    //         map.put(key, nextId);
    //         return nextId;
    //     }
    // }

    private String getUser(List<String> condition) {
        // NOTE: All users exist except for ONE: testnonexistantuser. This allows the MockGus to be very flexible, and basically go along with whatever
        if (condition.get(0) != null && condition.get(0).equals("Username") && condition.get(1) != null && condition.get(1).equals("=") && condition.get(2) != null && !condition.get(2).equals("testnonexistantuser")) {
            return "{\"totalSize\":1,\"done\":true,\"records\":[{\"Id\":\"test_userId\"}]}";
        } else if(condition.get(0) != null && condition.get(0).equals("Id") && condition.get(1) != null && condition.get(1).equals("=") && condition.get(2) != null && !condition.get(2).equals("test_userId")) {
            return "{\"totalSize\":1,\"done\":true,\"records\":[{\"Name\":\"testnonexistantuser\"}]}";
        } else {
            return "{\"totalSize\":0,\"done\":true,\"records\":[]}";
        }
    }

    private String createNewCard(String body) {
        Map<String, String> map = null;
        try {
            map = toMap(new JSONObject(body));
            System.out.println(map);
        } catch (Exception e) {
            e.printStackTrace();
        }
        if(map != null) {
            Random rand = new Random();
            String id = String.valueOf(rand.nextInt());
            String str = "{" +
            "\"id\":\""+id+"\"" +
            ",\"Name\":\"W-123445\"" +
            ",\"Details__c\":\""+map.get("Details__c").replace("\n","\\n")+"\"" +
            ",\"Status__c\":\""+map.get("Status__c")+"\"" +
            ",\"Subject__c\":\""+map.get("Subject__c")+"\"" +
            ",\"Story_Points__c\":null}";
            workItems.put(id,str.replace("id","Id"));
            return str;
        } else {
            return "{}";
        }
    }

    public static Map<String, String> toMap(JSONObject json) throws JSONException {
        Map<String, String> map = new HashMap();
        Iterator keys = json.keys();
        while (keys.hasNext()) {
            String key = (String) keys.next();
            map.put(key, json.getString(key));
        }
        return map;
    }
}
