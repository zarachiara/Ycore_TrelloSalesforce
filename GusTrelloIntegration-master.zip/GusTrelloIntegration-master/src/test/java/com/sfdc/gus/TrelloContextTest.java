package com.sfdc.gus;

import static org.junit.Assert.*;
import org.junit.Test;
import org.junit.BeforeClass;
import org.junit.AfterClass;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Map;
import java.util.List;

import java.net.ProtocolException;
import java.io.IOException;
import java.io.Reader;
import java.io.StringWriter;
import java.io.Writer;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.HttpURLConnection;
import java.io.InputStream;
import java.io.InputStreamReader;

import com.sfdc.gus.testHelpers.MockTrello;
import com.sfdc.gus.security.AESDualCrypt;
import com.sfdc.gus.config.TrelloLogin;

public class TrelloContextTest {

    private static class UrlResponse {
        public Map<String, List<String>> headers;
        private String body;
        private int status;

        public String toString() {
            return "{status="+status+", headers="+headers+", body="+body+"}";
        }
    }

    private static MockTrello mockTrello;
    private static TrelloContext tctx;

    @BeforeClass
    public static void setup() {
        mockTrello = new MockTrello();
        mockTrello.run();

        AESDualCrypt crypter = new AESDualCrypt("12345abcdefg");
        TrelloLogin tl = new TrelloLogin(crypter.encrypt("test_accessToken"));
        tctx = new TrelloContext(tl, crypter.encrypt("test_APIKey"), crypter);
        try {
            tctx.getMe();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @AfterClass
    public static void takedown() {
        mockTrello.stop();
    }

    private static UrlResponse doMethod(String requestMethod, String port, String path) {
        UrlResponse response = new UrlResponse();

        try {
            getResponse(requestMethod, port, path, response);
        } catch (IOException e) {
            e.printStackTrace();
        }

        return response;
    }

    private static void getResponse(String requestMethod, String port, String path, UrlResponse response)
            throws MalformedURLException, IOException, ProtocolException {
        System.out.println("Connection to: http://localhost:" + port + path);
        URL url = new URL("http://localhost:" + port + path);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod(requestMethod);
        connection.connect();
        String res = toString(connection.getInputStream());
        response.body = res;
        response.status = connection.getResponseCode();
        response.headers = connection.getHeaderFields();
    }

    private static String toString(InputStream input) throws IOException {
        StringWriter sw = new StringWriter();
        InputStreamReader in = new InputStreamReader(input);
        copyLarge(in, sw);
        return sw.toString();
    }

    public static long copyLarge(Reader input, Writer output) throws IOException {
        char[] buffer = new char[1024 * 4];
        long count = 0;
        int n = 0;
        while (-1 != (n = input.read(buffer))) {
            output.write(buffer, 0, n);
            count += n;
        }
        return count;
    }

    @Test
    public void testIndex() {
        UrlResponse res = doMethod("GET", "8888", "/");
        assertTrue(res != null);
        assertTrue(res.body != null);
        assertTrue(res.body.equals("{\"response\":\"success\"}"));
    }

    // Test the getMe function of the trello context
    @Test
    public void testGetMe() {
        try {
            tctx.getMe();
        } catch (Exception e) {
            // This exception should not occur
            e.printStackTrace();
            assertTrue(false);
        }
        assertTrue(tctx.getUserId().equals("test_trello_user_id"));
    }

    @Test
    public void testGetMyBoards() {
        try {
            JSONArray boards = tctx.getMyBoards();
            assertTrue(boards.length() == 2);
            assertTrue(boards.getJSONObject(0).getString("id").equals("test_board_id"));
            assertTrue(boards.getJSONObject(0).getString("name").equals("Test Board"));
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false);
        }
    }

    @Test
    public void testGetListsWithId() {
        try {
            JSONArray boards = tctx.getMyBoards();
            for (int i = 0; i < boards.length(); ++i) {
                JSONArray list = tctx.getLists(boards.getJSONObject(i).getString("id"));
                assertTrue(list.length() > 0);
                for (int j = 0; j < list.length(); ++j) {
                    assertTrue(list.getJSONObject(j).getString("id").length() > 0);
                    assertTrue(list.getJSONObject(j).getString("name").length() > 0);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false);
        }
    }

    @Test
    public void testGetCards() {
        try {
            Map<String, TrelloCard> cards = tctx.getCards("list1");
            assertTrue(cards.size() == 2);
            for (String str : cards.keySet()) {
                TrelloCard tc = cards.get(str);
                assertTrue(str.equals(tc.id));
                assertTrue(tc.name != null && tc.name.length() > 0);
                assertTrue(tc.desc != null && tc.desc.length() > 0);
            }
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false);
        }
    }

    @Test
    public void testGetMyCards() {
        try {
            Map<String, TrelloCard> cards = tctx.getMyCards("list1");
            assertTrue(cards.size() >= 1 && cards.size() <= 2);
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false);
        }
    }

    @Test
    public void testGetCard() {
        try {
            TrelloCard tc = tctx.getCard("card1");
            assertTrue(tc.id.equals("card1"));
            assertTrue(tc.name.equals("card 1"));
            assertTrue(tc.desc.equals("Description"));

            tc = tctx.getCard("card2");
            assertTrue(tc.id.equals("card2"));
            assertTrue(tc.name.equals("card 2"));
            assertTrue(tc.desc.equals("Description"));
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false);
        }
    }

    @Test
    public void testGetOpenBoards() {
        try {
            List<String> boards = tctx.getOpenBoards();
            assertTrue(boards.size() == 1);
            assertTrue(boards.get(0).equals("Test Board"));
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false);
        }
    }

    @Test
    public void testGetTrelloInfo() {
        try {
            List<Map> trelloInfo = tctx.getTrelloInfo();
            assertTrue(trelloInfo.size() == 1);
            Map board = trelloInfo.get(0);
            assertTrue(board.size() == 3);
            assertTrue(((String)board.get("Id")).equals("test_board_id"));
            assertTrue(((String)board.get("Name")).equals("Test Board"));
            assertNotNull(board.get("lists"));
            List<Map> lists = (List<Map>)board.get("lists");
            assertTrue(lists.size() == 3);
            assertTrue(((String)lists.get(0).get("Id")).equals("list1"));
            assertTrue(((String)lists.get(0).get("Name")).equals("List 1"));
            tctx.refreshTrelloInfo();
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false);
        }
    }

    @Test
    public void testGetLists() {
        try {
            List<Map> lists = tctx.getLists();
            assert(lists.size() == 3);
            assertTrue(((String)lists.get(0).get("Id")).equals("list1"));
            assertTrue(((String)lists.get(0).get("Name")).equals("List 1"));
            assertTrue(((String)lists.get(1).get("Id")).equals("list2"));
            assertTrue(((String)lists.get(1).get("Name")).equals("List 2"));
            assertTrue(((String)lists.get(2).get("Id")).equals("list3"));
            assertTrue(((String)lists.get(2).get("Name")).equals("List 3"));
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false);
        }
    }

    @Test
    public void testGetTrelloAccessQuery() {
        assertTrue(tctx.getTrelloAccessQuery().equals("key=test_APIKey&token=test_accessToken"));
    }

    @Test
    public void testCreateTrelloCard() {
        try {
            GusWorkItem gwi = new GusWorkItem(new JSONObject("{\"Id\":\"1\",\"Subject__c\":\"New Card\",\"Details__c\":\"New Description\"}"));
            JSONObject tc = tctx.createTrelloCard(gwi, "list1");
            assertTrue(tc != null);
            assertTrue(tc.getString("name").equals("New Card"));
            assertTrue(tc.getString("id").equals(tc.getString("name")));
            assertTrue(tc.getString("desc").contains("New Description"));
            assertTrue(tc.getString("desc").contains("Hash: "));
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false);
        }
    }

    @Test
    public void testUpdateTrelloCard() {
        try {
            TrelloCard tc1 = tctx.getCard("card1");
            TrelloCard tc2 = tctx.getCard("card1");
            tc2.setName("New Name");
            tctx.updateTrelloCard(tc2);
            tc2 = tctx.getCard("card1");
            assertTrue(!tc1.name.equals(tc2.name));

            tc2.setDesc("New Description");
            tctx.updateTrelloCard(tc2);
            tc2 = tctx.getCard("card1");
            assertTrue(!tc1.desc.equals(tc2.desc));

        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false);
        }
    }
}