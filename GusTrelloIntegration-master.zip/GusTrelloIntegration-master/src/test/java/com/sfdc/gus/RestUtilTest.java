package com.sfdc.gus;

import static org.junit.Assert.*;
import org.junit.Test;
import org.junit.BeforeClass;
import org.junit.AfterClass;
import org.json.JSONObject;
import org.json.JSONArray;

import java.util.Set;
import java.util.Map;
import java.util.HashMap;

import spark.Spark;

public class RestUtilTest {

    private static Spark spark;
    private static final int PORT = 5432;
    private static final String HOST = "http://localhost:" + PORT;

    @BeforeClass
    public static void setup() {
        spark = new Spark();
        spark.port(PORT);

        spark.get("/get_success", (request, response) -> {
            String ret = "{\"response\":\"success\"";
            Set<String> headers = request.headers();
            for(String header : headers) {
                ret += ",\""+header+"\":\""+request.headers(header)+"\"";
            }
            ret += "}";
            return ret;
        });

        spark.post("/update", (request, response) -> {
            if (request.headers("foo") == null) spark.halt(400);
            if (!request.body().contains("baz")) spark.halt(401); 
            return "";
        });

        spark.put("/update", (request, response) -> {
            if (request.headers("foo") == null) spark.halt(400);
            if (!request.body().contains("baz")) spark.halt(401); 
            return "";
        });

        spark.patch("/update", (request, response) -> {
            if (request.headers("foo") == null) spark.halt(400);
            if (!request.body().contains("baz")) spark.halt(401); 
            return "";
        });

        spark.get("/get_list", (request, response) -> {
            String ret = "[{\"response\":\"success\"";
            Set<String> headers = request.headers();
            for(String header : headers) {
                ret += ",\""+header+"\":\""+request.headers(header)+"\"";
            }
            ret += "}]";
            return ret;
        });

        spark.post("/create", (request, response) -> {
            String ret = "{\"response\":\"success\"";
            Set<String> headers = request.headers();
            for(String header : headers) {
                ret += ",\""+header+"\":\""+request.headers(header)+"\"";
            }
            ret += ",\"body\":\""+request.body().replace("\"","\\\"") + "\"";
            ret += "}";
            return ret;
        });

        spark.post("/user_info", (request, response) -> {
            return "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" +
                "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">" +
                    "<soapenv:Body>" +
                        "<getUserInfoResponse xmlns=\"urn:enterprise.soap.sforce.com\">" +
                            "<userId>test_userId</userId>" +
                        "</getUserInfoResponse>" +
                    "</soapenv:Body>" +
                "</soapenv:Envelope>";
        });

        spark.post("/services/Soap/c/*", (request, response) -> {
            System.out.println("Received: " + request.url());
            return "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" +
                "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">" +
                    "<soapenv:Body>" +
                        "<loginResponse xmlns=\"urn:enterprise.soap.sforce.com\">" +
                            "<result>" +
                                "<passwordExpired>false</passwordExpired>" +
                                "<serverUrl>"+HOST+"/user_info</serverUrl>" +
                                "<sessionId>sessionId</sessionId>" +
                                "<userId>myId</userId>" +
                            "</result>" +
                        "</loginResponse>" +
                    "</soapenv:Body>" +
                "</soapenv:Envelope>";
        });
    }

    @AfterClass
    public static void teardown() {
        spark.stop();
    }

    @Test
    public void testGetObject() {
        try {
            JSONObject json = RestUtil.getObject(HOST + "/get_success", null);
            assertTrue(json != null);
            assertTrue(json.has("response"));
            assertTrue(json.getString("response").equals("success"));
            assertFalse(json.has("foo"));

            // Test with headers
            Map<String, String> headers = new HashMap<String, String>();
            headers.put("foo","bar");
            json = RestUtil.getObject(HOST + "/get_success", headers);
            assertTrue(json != null);
            assertTrue(json.has("foo"));
            assertTrue(json.getString("foo").equals("bar"));
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false);
        }
    }

    @Test
    public void testUpdateObject() {
        try {
            boolean success = RestUtil.updateObject(HOST + "/update", null, null, RestUtil.HttpUpdateMethod.HTTP_POST);
            assertFalse(success);

            Map<String, String> headers = new HashMap<String, String>();
            headers.put("foo","bar");
            Map<String, String> body = new HashMap<String, String>();
            body.put("baz","1");
            success = RestUtil.updateObject(HOST + "/update", headers, null, RestUtil.HttpUpdateMethod.HTTP_POST);
            assertFalse(success);
            success = RestUtil.updateObject(HOST + "/update", headers, body, RestUtil.HttpUpdateMethod.HTTP_POST);
            assertTrue(success);

            success = RestUtil.updateObject(HOST + "/update", null, null, RestUtil.HttpUpdateMethod.HTTP_PUT);
            assertFalse(success);
            success = RestUtil.updateObject(HOST + "/update", headers, null, RestUtil.HttpUpdateMethod.HTTP_PUT);
            assertFalse(success);
            success = RestUtil.updateObject(HOST + "/update", headers, body, RestUtil.HttpUpdateMethod.HTTP_PUT);
            assertTrue(success);

            success = RestUtil.updateObject(HOST + "/update", null, null, RestUtil.HttpUpdateMethod.HTTP_PATCH);
            assertFalse(success);
            success = RestUtil.updateObject(HOST + "/update", headers, null, RestUtil.HttpUpdateMethod.HTTP_PATCH);
            assertFalse(success);
            success = RestUtil.updateObject(HOST + "/update", headers, body, RestUtil.HttpUpdateMethod.HTTP_PATCH);
            assertTrue(success);
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false);
        }
    }

    @Test
    public void testGetList() {
        try {
            JSONArray json = RestUtil.getList(HOST + "/get_list", null);
            assertTrue(json.length() == 1);
            assertTrue(json.getJSONObject(0).has("response"));
            assertTrue(json.getJSONObject(0).getString("response").equals("success"));
            assertFalse(json.getJSONObject(0).has("foo"));

            // Test with headers
            Map<String, String> headers = new HashMap<String, String>();
            headers.put("foo","bar");
            json = RestUtil.getList(HOST + "/get_list", headers);
            assertTrue(json.length() == 1);
            assertTrue(json.getJSONObject(0).has("foo"));
            assertTrue(json.getJSONObject(0).getString("foo").equals("bar"));
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false);
        }
    }

    @Test
    public void testQueryObjects() {
        try {
            JSONObject json = RestUtil.queryObjects(HOST + "/get_success", null);
            assertTrue(json != null);
            assertTrue(json.has("response"));
            assertTrue(json.getString("response").equals("success"));
            assertFalse(json.has("foo"));

            // Test with headers
            Map<String, String> headers = new HashMap<String, String>();
            headers.put("foo","bar");
            json = RestUtil.queryObjects(HOST + "/get_success", headers);
            assertTrue(json != null);
            assertTrue(json.has("foo"));
            assertTrue(json.getString("foo").equals("bar"));

        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false);
        }

        boolean exc_thrown = false;
        try {
            RestUtil.queryObjects(HOST + "/404", null);
        } catch (Exception e) {
            exc_thrown = true;
        }
        assertTrue(exc_thrown);
    }

    @Test
    public void testCreateObject() {
        try {
            JSONObject json = RestUtil.createObject(HOST + "/create", null, new HashMap<String, String>());
            assertTrue(json != null);
            assertTrue(json.has("response"));
            assertTrue(json.getString("response").equals("success"));
            assertTrue(json.has("body"));
            assertTrue(json.getString("body").equals("{}"));

            Map<String, String> body = new HashMap<String, String>();
            body.put("foo","bar");
            json = RestUtil.createObject(HOST + "/create", null, body);
            assertTrue(json != null);
            assertTrue(json.has("response"));
            assertTrue(json.getString("response").equals("success"));
            assertTrue(json.has("body"));
            assertTrue(json.getString("body").equals("{\"foo\":\"bar\"}"));

            Map<String, String> headers = new HashMap<String, String>();
            headers.put("me","you");
            json = RestUtil.createObject(HOST + "/create", headers, new HashMap<String, String>());
            assertTrue(json != null);
            assertTrue(json.has("response"));
            assertTrue(json.getString("response").equals("success"));
            assertTrue(json.has("me"));
            assertTrue(json.getString("me").equals("you"));
        } catch (Exception e) {
            e.printStackTrace();
            assertTrue(false);
        }
    }

    // Test now fails because the RestUtil.soapLogin function is trying to get userInfo.
    // Can't get the response in the correct format and ConnectionException is always thrown
    // @Test
    // public void testSoapLogin() {
    //     String[] params = new String[2];
    //     try {
    //         RestUtil.soapLogin(HOST + "/services/Soap/c/v30.0", "1","2",params);

    //         assertTrue(params[0].equals("sessionId"));
    //     } catch (Exception e) {
    //         System.out.println(e.getMessage());
    //         e.printStackTrace();
    //         assertTrue(false);
    //     }
    // }

    @Test
    public void testRestEncode() {
        String test = "this is\na\r\ntest";
        assertTrue(RestUtil.RestEncode(test).equals("this%20is%0aa%0atest"));
    }
}