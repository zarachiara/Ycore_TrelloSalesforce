$(document).ready(function() {
    $("#portal").click(function() {
        window.location.href = "/portal";
    });

    var notch = getNotch($('#srange_value').text());
    setNotch(notch);
    $('#srange').val(notch);
    $('#srange').change(function() {
        setNotch($('#srange').val());
    });

    $('.profile_lists .click_fold:first-child').click(function () {
        makeSlidable($(this).parent(), '40px');
    });

    $('#instructions div:first-child').click(function () {
        makeSlidable($(this).parent(), '31px');
    });

    $("#logout").click(function() {
        $.ajax({
            url: "/ajax_endpoint",
            type: "post",
            data: {'action':'logout'},
            success: function() {
                window.location.href = "/";
            }
        })
    });

    $("#delete_profile").click(function() {
        $.ajax({
            url: "/ajax_endpoint",
            type: "post",
            data: {'action':'delete_profile'},
            success: function() {
                window.location.href = "/"; 
            },
            error: function() {
                alert("Cannot perform that request at this time");
            }
        });
    });

    $('.add_item').click(function() {
        replaceWithInput($(this));
    });

    $('.remove_association').click(function(e) {
        e.preventDefault();
        var this_obj = $(this);
        removeItem(this_obj);
    });

    $('#update_sync').click(function() {
        $.ajax({
            url: "/ajax_endpoint",
            type: "post",
            data: {'action':'update_sync','sync':getNotchTime($('#srange_value').text(),$('#srange_units').text())},
            error: function() {
                alert("Unable to update Sync Time at this moment");
            }
        });
    });
});

function replaceWithInput (this_obj) {
    var id = this_obj.attr('id');
    var parent = this_obj.parent();
    this_obj.hide();
    var input = $("<input id='"+id+"_input'/>");
    input.appendTo(parent);
    var button = $('<input type="button" class="btn btn-default small-btn" value="Add"/>').click(function() {
        addItem(id, this_obj);
    }).appendTo(parent);
}

function removeItem (this_obj) {
    $.ajax({
        url: "/ajax_endpoint",
        type: "post",
        data: {'action':'remove_item','type':'team','name':this_obj.attr("data-name")},
        success: function(e) {
            this_obj.parent().remove();
        },
        error: function() {
            alert("Unable to remove this team");
        }
    });
}

function addItem (id, this_obj) {
    $.ajax({
        url: "/ajax_endpoint",
        type: "post",
        data: {'action':'add_item','type':id,'value':$('#'+id+'_input').val()},
        success: function(data) {
            handleAJAX(data);
        },
        error: function() {
            alert("An Error has occured");
        }
    });
}

function handleAJAX (data) {
    var json = JSON.parse(data);
    if (json.result != 'success') {
        handleError(json);
        return;
    }

    $('#'+json.type).parent().find('input').remove();
    $('#'+json.type).show();
    if (json.type == 'addTeam') {
        var div = $("<div data-id='"+json.Id+"'>"+json.value+"</div>");
        var a = $("<a data-name='"+json.Id+"' href='#'>Remove</a>");
        a.click(function() {
            removeItem(a);
        });
        div.append(a);
        $('#gus_team_div').append(div);
    } else if (json.type == 'addProduct') {
        $('#gus_product_div').append("<div data-id='"+json.Id+"'>"+json.value+"</div>");
    }
}

function handleError (json) {
    $('#error_bar').text(json.value + " Doesn't Exist");
    $('#error_bar').animate({'top': '0px'} ,{
        complete: function () {
            setTimeout(function() {
                $('#error_bar').animate({'top': '-50px'});
            }, 3000);
        }
    });
}

function getNotch (sync_time) {
    switch(sync_time) {
        case "10":
            return 0;
        case "60":
            return 1;
        case "300":
            return 2;
        case "600":
            return 3;
        case "1,800":
            return 4;
        case "3,600":
            return 5;
        case "7,200":
            return 6;
        case "21,600":
            return 7;
        case "43,200":
            return 8;
        default:
            return 9;
    }
}

function setNotch(value) {
    switch(value) {
        case '0':
        case 0:
            setNotchView("10","seconds");
            break;
        case '1':
        case 1:
            setNotchView("1","minute");
            break;
        case '2':
        case 2:
            setNotchView("5","minutes");
            break;
        case '3':
        case 3:
            setNotchView("10","minutes");
            break;
        case '4':
        case 4:
            setNotchView("30","minutes");
            break;
        case '5':
        case 5:
            setNotchView("1","hour");
            break;
        case '6':
        case 6:
            setNotchView("2","hours");
            break;
        case '7':
        case 7:
            setNotchView("6","hours");
            break;
        case '8':
        case 8:
            setNotchView("12","hours");
            break;
        case '9':
        case 9:
            setNotchView("1","day");
            break;
    } 
}

function getNotchTime (value, units) {
    var multiplier = 1;
    switch (units) {
        case "day":
        multiplier = multiplier * 24;
        case "hour":
        case "hours":
        multiplier = multiplier * 60;
        case "minute":
        case "minutes":
        multiplier = multiplier * 60;
        default:
        multiplier = multiplier * 1;
    }
    return value * multiplier;
}

function setNotchView(value, units) {
    $('#srange_value').text(value);
    $('#srange_units').text(units);
}

function makeSlidable(this_obj, close_height) {
    if(this_obj.find('.closed').length != 0) {
        this_obj.find('img:first-child').removeClass('rotate');
        this_obj.find('.closed').remove();
        var full_height = getFullHeight(this_obj.clone());
        this_obj.animate({'height': full_height + 'px'},{
            complete: function() {
                this_obj.css("height","auto");
            }
        });
    } else {
        this_obj.append("<div class='closed'></div>")
        this_obj.find('img:first-child').addClass('rotate');
        this_obj.animate({'height': close_height},{
            complete: function() {
                this_obj.css("overflow","hidden");
            }
        });
    }
}

function getFullHeight (this_obj) {
    this_obj.css({position: 'absolute', visibility: 'hidden', display: 'block', height: 'auto'}).appendTo($('body'));
    var h = this_obj.outerHeight();
    this_obj.remove();
    return h;
}