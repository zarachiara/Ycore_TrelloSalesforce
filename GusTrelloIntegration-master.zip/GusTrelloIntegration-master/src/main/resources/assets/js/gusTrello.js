
// Droppable fields titles
var gsus = 'Gus Team';
var tnl = "Trello 'New' List";
var tipl = "Trello 'In Progress' List";
var tdl = "Trello 'Done' List";

$(document).ready(function() {
    $(".myDraggable").draggable({revert: 'invalid', 
        helper: "clone", 
        cursorAt: {top: 25, left: 48},
        start: function(e, ui) {
            //alert($(this).height()/2.0 + " x " + $(this).width()/2.0);
            $(ui.helper).addClass("dragged-clone");
            $(ui.helper).width($(this).width());
        }
    });

    $("#profile").click(function() {
        window.location.href = "/profile";
    })

    $("#new_relation").click(function() {
        $("#new_relation").hide();
        var d = $("<div id='relation' class='panel'></div>");
        var divs = [];
        divs[0] = $("<div id='gus_team' class='drop_here drop_here_color'>Gus Sprint User Story</div>");
        divs[1] = $("<div id='trello_new' class='drop_here drop_here_color'>Trello 'New' List</div>");
        divs[2] = $("<div id='trello_progress' class='drop_here drop_here_color'>Trello 'In Progress' List</div>");
        divs[3] = $("<div id='trello_done' class='drop_here drop_here_color'>Trello 'Done' List</div>");

        $.each(divs, function(i, val) {
            makeDroppable(val, (i == 0 ? '.gus_drag' : '.trello_drag'));
            clearDroppable(val);
            val.text(getTitle(val.attr("id")));
            d.append(val);
        });

        var form = $("<form id='new_relation_form' action='/ajax_endpoint' method='post'></form>");
        $("#product_tag_div").clone().show().appendTo(form);
        $("<div class='filter_area gus_filter_div'><textarea id='gus_filter_in' name='gus_filter_in' placeholder='Select Gus Cards By Keywords'/></div>").appendTo(form);
        $("<div class='filter_area gus_filter_div'><textarea id='gus_filter_out' name='gus_filter_out' placeholder='Filter Out Gus Cards By Keywords'/></div>").appendTo(form);
        $("<div class='filter_area trello_filter_div'><textarea id='trello_filter_out' name='trello_filter_out' placeholder='Filter Out Trello Cards By Keywords'/></div>").appendTo(form);
        $("<div class='filter_area trello_filter_div'><textarea id='trello_filter_in' name='trello_filter_in' placeholder='Select In Trello Cards By Keywords'/></div>").appendTo(form);
        $("<div class='relation_submit'><input style='width:20%;' type='submit' value='Submit' name='new_relation' class='btn btn-default'/></div>").appendTo(form);
        d.appendTo("#new_relation_div");
        d.wrap("<div id='wrapper'></div>");
        $("<div class='panel' id='form_wrapper'></div>").append(form).appendTo("#wrapper");
        $("#new_relation_form").submit(function(e) { e.preventDefault(); handleSubmit()});
    });

    $(".delete").click(function() {
        confirmDeleteDialog($(this));
    });


    $(".old_relation .click_fold:first-child").click(function() {
        makeSlidable($(this).parent());
    });

    $("#logout").click(function() {
        $.ajax({
            url: "/ajax_endpoint",
            type: "post",
            data: {'action':'logout'},
            success: function() {
                window.location.href = "/";
            }
        })
    })

});

function confirmDeleteDialog(this_obj) {
    $("<div title='Remove this Relation?' id='confirm'></div>").dialog({
        resizable: false,
        height:140,
        modal: true,
        buttons: {
            Yes: function() {
                confirm = true;
                $(this).dialog("close");
                removeRelation(this_obj.attr("name"));
                this_obj.parent().remove();
                $(this).remove();
            },
            Cancel: function() {
                $(this).dialog("close");
                $(this).remove();
            }
        }
    });
}

function makeSlidable(this_obj) {
    if(this_obj.find('.closed').length != 0) {
        this_obj.find('img').removeClass('rotate');
        this_obj.find('.closed').remove();
        var fullHeight = getFullHeight(this_obj.clone());
        this_obj.animate({'height': fullHeight + 'px'},{
            complete: function() {
                this_obj.css("height","auto");
            }
        });
    } else {
        this_obj.append("<div class='closed'></div>")
        this_obj.find('img').addClass('rotate');
        this_obj.animate({'height': '40px'},{
            complete: function() {
                this_obj.css("overflow","hidden");
            }
        });
    }
}

function getFullHeight (this_obj) {
    this_obj.css({position: 'absolute', visibility: 'hidden', display: 'block', height: 'auto'}).appendTo($('body'));
    var h = this_obj.outerHeight();
    this_obj.remove();
    return h;
}

function removeRelation(id) {
    $.ajax({
        url: "/ajax_endpoint",
        type: "post",
        data: {'action':'remove_relation', 'id':""+id},
        error: function() {
            alert("error");
        }
    });
}

function makeDroppable(obj, accept_cl) {
    obj.droppable({accept: accept_cl,
        drop: function(e, ui) {
            $(this).text(ui.draggable.text());
            $(this).attr("data-id",ui.draggable.data("id"));
            $(this).attr("data-boardid",ui.draggable.data("boardid"));
            $(this).css("background-color","");
            $(this).removeClass("drop_here_color");
            $(this).addClass("droppable_populated");
    }});
}

function clearDroppable(obj) {
    obj.click(function() {
        obj.text(getTitle(obj.attr('id')));
        obj.attr("data-id","");
        obj.attr("data-boardid","");
        obj.removeClass('droppable_populated');
        obj.addClass("drop_here_color");
    });
}

function getTitle(id) {
    if(id.indexOf("gus") >= 0) {
        return gsus;
    } else if(id.indexOf("new") >= 0) {
        return tnl;
    } else if(id.indexOf("progress") >= 0) {
        return tipl;
    } else if(id.indexOf("done") >= 0) {
        return tdl;
    }
    return "";
}

function updateSrange(val) {
    $("#srange").text(val+" hours");
}

function handleSubmit() {
    $("#errors").empty();
    $.ajax({
        url: "/ajax_endpoint",
        type: "post",
        data: getData(),
        success: function(data) {
            handleAJAXResponse(data);
        },
        error: function() {
            alert("error");
        }
    });
    return false;
}

function getData() {
    var data = {};
    data['action'] = 'new_relation';

    data.gus_team = (gsus == $('#gus_team').text() ? "" : $('#gus_team').attr("data-id"));
    data.trello_new = (tnl == $('#trello_new').text() ? "" : $('#trello_new').attr("data-id"));
    data.trello_new_boardid = $('#trello_new').attr('data-boardid') || "";
    data.trello_progress = (tipl == $('#trello_progress').text() ? "" : $('#trello_progress').attr("data-id"));
    data.trello_progress_boardid = $('#trello_progress').attr('data-boardid') || "";
    data.trello_done = (tdl == $('#trello_done').text() ? "" : $('#trello_done').attr("data-id"));
    data.trello_done_boardid = $('#trello_done').attr('data-boardid') || "";

    data.product_tag = $('#product_tag').val();
    data.gus_filter_in = $('#gus_filter_in').val();
    data.gus_filter_out = $('#gus_filter_out').val();
    data.trello_filter_in = $('#trello_filter_in').val();
    data.trello_filter_out = $('#trello_filter_out').val();
    return data;
}

function handleAJAXResponse(data) {
    var json = JSON.parse(data);
    if(json['result'] == 'success') {
        renderNewRelation(json);
        $("#wrapper").remove();
        $("#new_relation").show();
    } else {
        handleErrors(json);
    }
}

function handleErrors(json) {
    var errors = json.errors.split("|");
    var error_box = $("<div class='error_message' style='width: 65%;margin: 0 auto;'></div>");
    for (var i = 0; i < errors.length; ++i) {
        error_box.append("<div>"+errors[i]+"</div>");
    };
    error_box.appendTo("#errors");
    var error_fields = json.error_fields.split("|");
    for (var i = 0; i < error_fields.length; ++i) {
        $("#"+error_fields[i]).css("background-color","#FFBBBB");
    };
}

function renderNewRelation(json) {
    var new_relation = $("<div class='panel old_relation'></div>");
    $("<div class='click_fold'><img class='arrow' src='/images/arrow.png' width='16' height='16'>"+json.gus_team+" - "+json.product_tag+"</div>").click(function() {
        makeSlidable($(this).parent());
    }).appendTo(new_relation);
    $("<input type='button' class='delete btn btn-default' name='"+json.delete_id+"' value='&#10006;' /><br/>").click(function() {
            confirmDeleteDialog($(this));
        }).appendTo(new_relation);
    $("<div class='drop_here droppable_populated old_relation_box'>"+json.gus_team+"</div>").appendTo(new_relation);
    $("<div class='drop_here droppable_populated old_relation_box'>"+json.trello_new+"</div>").appendTo(new_relation);
    $("<div class='drop_here droppable_populated old_relation_box'>"+json.trello_progress+"</div>").appendTo(new_relation);
    $("<div class='drop_here droppable_populated old_relation_box'>"+json.trello_done+"</div>").appendTo(new_relation);
    $("<div>Product Tag: "+json.product_tag+"</div>").appendTo(new_relation);
    var filters = $("<div class='filters'></div>");

    json.gus_filter_in = json.gus_filter_in.replace(/%0A/g,'<br/>');
    $("<div class='filter'><h5>Gus Select By</h5><div class='filter_text'>"+json.gus_filter_in+"</div></div>").appendTo(filters);
    json.gus_filter_out = json.gus_filter_out.replace(/%0A/g,'<br/>');
    $("<div class='filter'><h5>Gus Filter Out By</h5><div class='filter_text'>"+json.gus_filter_out+"</div></div>").appendTo(filters);
    json.trello_filter_in = json.trello_filter_in.replace(/%0A/g,'<br/>');
    $("<div class='filter'><h5>Trello Select By</h5><div class='filter_text'>"+json.trello_filter_in+"</div></div>").appendTo(filters);
    json.trello_filter_out = json.trello_filter_out.replace(/%0A/g,'<br/>');
    $("<div class='filter'><h5>Trello Filter Out By</h5><div class='filter_text'>"+json.trello_filter_out+"</div></div>").appendTo(filters);

    filters.appendTo(new_relation);
    new_relation.appendTo("#current_relations_div");
}
