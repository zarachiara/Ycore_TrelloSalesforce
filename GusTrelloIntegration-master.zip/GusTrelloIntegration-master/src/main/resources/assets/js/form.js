$(document).ready(function() {
    $("#register_user").click(function() {
        $("body").fadeTo(1,.5);
        $("#login_container").prepend("Loading");
    });
});
