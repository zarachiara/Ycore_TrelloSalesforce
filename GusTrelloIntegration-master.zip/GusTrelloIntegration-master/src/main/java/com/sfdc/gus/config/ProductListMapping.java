package com.sfdc.gus.config;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.OneToOne;
import javax.persistence.OneToMany;
import javax.persistence.ManyToOne;
import javax.persistence.JoinColumn;
import javax.persistence.FetchType;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.HashCodeBuilder;

@Entity
@Table(name="productlistmapping", schema="configuration")
public class ProductListMapping {

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private long productListMappingId;
    public long getProductListMappingId() { return productListMappingId; }

    @ManyToOne
    @JoinColumn(name="trellolistid")
    private TrelloList trelloList;
    public TrelloList getTrelloList() { return trelloList; }

    @ManyToOne
    @JoinColumn(name="gusproductid")
    private GusProduct gusProduct;
    public GusProduct getGusProduct() { return gusProduct; }

    private GusStatus gusStatus;
    public GusStatus getGusStatus() { return gusStatus; }

    private boolean syncEnabled;
    public boolean isSyncEnabled() { return syncEnabled; }
    public void setSyncEnabled(boolean syncEnabled) { this.syncEnabled = syncEnabled; }

    @ManyToOne
    @JoinColumn(name="projectconfigid")
    private ProjectConfig projectConfig;
    public ProjectConfig getProjectConfig() { return projectConfig; }

    @OneToMany(mappedBy="productListMapping", fetch=FetchType.EAGER)
    private List<FilterSet> filters;
    public List<FilterSet> getFilters() { return filters; }

    public ProductListMapping() {}
    public ProductListMapping(TrelloList trelloList, GusProduct gusProduct, GusStatus gusStatus, boolean syncEnabled, ProjectConfig projectConfig) {
        this.trelloList = trelloList;
        this.gusProduct = gusProduct;
        this.gusStatus = gusStatus;
        this.syncEnabled = syncEnabled;
        this.projectConfig = projectConfig;
    }

    @Override
    public String toString() {
        return "<productlistmapping "
            + "id=" + productListMappingId + " "
            + "enabled=" + syncEnabled + " "
            + "status=" + gusStatus.toString() + " "
            + "product=" + gusProduct.toString() + " "
            + "list=" + trelloList.toString() + " "
            + ">";
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder()
            .append(productListMappingId)
            .append(syncEnabled)
            .append(gusStatus)
            .append(gusProduct)
            .append(trelloList)
            .toHashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) { return false; }
        if (obj == this) { return true; }
        if (obj.getClass() != getClass()) {
            return false;
        }
        ProductListMapping tlobj = (ProductListMapping) obj;
        return tlobj.getProductListMappingId() == productListMappingId
            && tlobj.isSyncEnabled() == syncEnabled
            && tlobj.getGusStatus() == gusStatus
            && tlobj.getGusProduct().equals(gusProduct)
            && tlobj.getTrelloList().equals(trelloList)
            ;
    }
}
