package com.sfdc.gus.security;

import org.apache.log4j.Logger;

import java.io.UnsupportedEncodingException;

import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.InvalidParameterSpecException;
import java.security.spec.KeySpec;
import java.security.InvalidAlgorithmParameterException;

import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.BadPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;

/**
 * Class that upon initialization, will be able to encrypt and decrypt text using AES128 and a passphrase
 *
 * Core implementation came from https://gist.github.com/anonymous/4153639
 */
public class AESDualCrypt {
    // Shared across Encrypt and Decrypt, necesitating inner-classes to keep them in the same location, but still private
    private static final byte[] SALT = {(byte) 0xA9, (byte) 0x9B, (byte) 0xC8, (byte) 0x32, (byte) 0x56, (byte) 0x35, (byte) 0xE3, (byte) 0x03};
    private static final int ITERATION_COUNT = 65536;
    private static final int KEY_LENGTH = 128;
    private static final int IV_LENGTH = 16;

    private static Logger logger = Logger.getLogger(AESDualCrypt.class);

    private String passphrase;
    /**
     * Initialize a crypter using a passphrase. Once this object is created, any user of it
     * gains full decrypt and encrypt power (assuming the passphrase is correct).
     */
    public AESDualCrypt(String passphrase) { this.passphrase = passphrase; }

    /**
     * Decrypts a string to plain text
     * @param encrypted Encrypted string that should be decrypted
     * @return The original message after decryption
     */
    public String decrypt(String encrypted) {
        try {
            AESDecrypt decrypter = new AESDecrypt(passphrase, encrypted);
            return decrypter.decrypt();
        // TODO: More descriptive exceptions would be nice
        } catch (Exception e) { logger.error("Exception during decryption", e); }
        return null;
    }

    /**
     * Encrypts plain text using AES128
     * @param plaintext Plaintext that should become encrypted
     * @return The encrypted form of plaintext
     */
    public String encrypt(String plaintext) {
        try {
            AESEncrypt encrypter = new AESEncrypt(passphrase);
            return encrypter.encrypt(plaintext);
        // TODO: More descriptive exceptions would be nice
        } catch (Exception e) { logger.error("Exception during encryption", e); }
        return null;
    }

    /**
     * Component that handles decryption
     *
     * At one point, I tried to include these 2 classes into 1 base class, but upon doing
     * that, it ceased to function. Until further notice, these two inner-containers will
     * remain, since they work.
     */
    private class AESDecrypt {
        private Cipher eCipher;
        private Cipher dCipher;
        private byte[] encrypt;

        /**
         * An interesting thing to note about this decryption object is that upon
         * object initialization, it takes both the passphrase and the encrypted string.
         * I once tried to break this out so that the object can be initialized with only
         * a passphrase, and can be reused for decryptions, but that wound up failing,
         * so I left it as is. Any new decryption requires the creation of this object.
         */
        public AESDecrypt(String passPhrase, String encryptedString)
                throws NoSuchAlgorithmException
                , InvalidKeySpecException
                , InvalidKeyException
                , NoSuchPaddingException
                , InvalidAlgorithmParameterException
                , IllegalBlockSizeException
                , BadPaddingException {
            SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1");
            KeySpec keySpec = new PBEKeySpec(passPhrase.toCharArray(), SALT, ITERATION_COUNT, KEY_LENGTH);
            SecretKey secretKeyTemp = secretKeyFactory.generateSecret(keySpec);
            SecretKey secretKey = new SecretKeySpec(secretKeyTemp.getEncoded(), "AES");
            encrypt = Base64.decodeBase64(encryptedString);

            eCipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            eCipher.init(Cipher.ENCRYPT_MODE, secretKey);

            byte[] iv = extractIV();
            dCipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            dCipher.init(Cipher.DECRYPT_MODE, secretKey, new IvParameterSpec(iv));
        }


        private byte[] extractIV() throws IllegalBlockSizeException {
            byte[] iv = new byte[IV_LENGTH];
            System.arraycopy(encrypt, 0, iv, 0, iv.length);
            return iv;
        }

        public String decrypt() throws UnsupportedEncodingException, BadPaddingException, IllegalBlockSizeException {
            byte[] bytes = extractCipherText();
            byte[] decrypted = decrypt(bytes);
            return new String(decrypted, "UTF8");
        }
        private byte[] extractCipherText() throws BadPaddingException {
            byte[] ciphertext = new byte[encrypt.length - IV_LENGTH];
            System.arraycopy(encrypt, 16, ciphertext, 0, ciphertext.length);
            return ciphertext;
        }

        public byte[] decrypt(byte[] encrypt)  throws IllegalBlockSizeException, BadPaddingException {
            return dCipher.doFinal(encrypt);
        }
    }

    /**
     * Component that handles the encryption
     */
    private class AESEncrypt {
        private Cipher eCipher;
        private Cipher dCipher;
        private byte[] iv;

        public AESEncrypt(String passPhrase)
                throws NoSuchAlgorithmException
                , InvalidKeySpecException
                , InvalidKeyException
                , InvalidParameterSpecException
                , BadPaddingException
                , NoSuchPaddingException
                , InvalidAlgorithmParameterException {
            SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1");
            KeySpec keySpec = new PBEKeySpec(passPhrase.toCharArray(), SALT, ITERATION_COUNT, KEY_LENGTH);
            SecretKey secretKeyTemp = secretKeyFactory.generateSecret(keySpec);
            SecretKey secretKey = new SecretKeySpec(secretKeyTemp.getEncoded(), "AES");

            eCipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            eCipher.init(Cipher.ENCRYPT_MODE, secretKey);

            dCipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
            iv = eCipher.getParameters().getParameterSpec(IvParameterSpec.class).getIV();
            dCipher.init(Cipher.DECRYPT_MODE, secretKey, new IvParameterSpec(iv));
        }

        public String encrypt(String encrypt) throws UnsupportedEncodingException, IllegalBlockSizeException, BadPaddingException {
            byte[] bytes = encrypt.getBytes("UTF8");
            byte[] encrypted = encrypt(bytes);
            byte[] cipherText = new byte[encrypted.length + iv.length];
            System.arraycopy(iv, 0, cipherText, 0, iv.length);
            System.arraycopy(encrypted, 0, cipherText, iv.length, encrypted.length);
            return new String(Base64.encodeBase64(cipherText));
        }

        public byte[] encrypt(byte[] plain) throws IllegalBlockSizeException, BadPaddingException {
            return eCipher.doFinal(plain);
        }
    }
}
