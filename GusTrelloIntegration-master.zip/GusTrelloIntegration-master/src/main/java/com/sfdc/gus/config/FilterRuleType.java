package com.sfdc.gus.config;

public enum FilterRuleType {
    IMPORT,
    EXPORT
}
