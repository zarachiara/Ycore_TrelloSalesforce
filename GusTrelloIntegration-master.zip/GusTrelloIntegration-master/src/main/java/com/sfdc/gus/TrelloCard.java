package com.sfdc.gus;

import java.security.MessageDigest;
import java.util.Map;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.json.JSONException;
import org.json.JSONObject;
import org.apache.log4j.Logger;

import com.sfdc.gus.util.TextUtil;

public class TrelloCard {

	public static final String NAME_FIELD = "name";
	public static final String DESC_FIELD = "desc";
	public static final String ID_FIELD = "id";
	public static final int ID_LENGTH = 18;
	
	public String name;
	public String id;
	public String desc;
	public int points = 0;
	public String gusId;
	public String gusWorkItemUrl;
	public String oldHash;
	public boolean needsUpdating = false;
	public Map<String, String> changedValuesMap;

    private Logger logger = Logger.getLogger(TrelloCard.class);
	
	public TrelloCard(JSONObject card) throws JSONException {
		this.name = card.getString(NAME_FIELD);
		// Extract out points from name
		if (name.contains(":")) {
			int index = name.lastIndexOf(":");
			String pointString = name.substring(index + 1);
			try {
				this.points = Integer.parseInt(pointString.trim());
				this.name = name.substring(0, index);
			} catch (NumberFormatException nfe) {
				logger.debug("Parse error for " + pointString);
			}
		}
		this.desc = card.getString(DESC_FIELD);
		// Extract out GUS link from desc
		if (this.desc.contains(GusContext.GUS_ENDPOINT)) {
			int beginIdx = this.desc.indexOf(GusContext.GUS_ENDPOINT);
			int endIdx = this.desc.indexOf("\r", beginIdx);
			if (endIdx < 0) {
				endIdx = this.desc.indexOf("\n", beginIdx);
				if (endIdx < 0) {
					endIdx = this.desc.indexOf(" ", beginIdx);
				}
			}
			if (beginIdx >= 0) {
				if (endIdx > 0) {
					this.gusWorkItemUrl = this.desc.substring(beginIdx, endIdx);					
				}
				else {
					this.gusWorkItemUrl = this.desc.substring(beginIdx);					
				}
			}
			this.gusWorkItemUrl = this.gusWorkItemUrl.trim().replace("\n", "").replace("\r", "");
			beginIdx = this.gusWorkItemUrl.lastIndexOf("/") + 1;
			this.gusId = this.gusWorkItemUrl.substring(beginIdx);
		}

		int idx = desc.indexOf("Hash: ");
		if(idx > -1) {
			this.oldHash = this.desc.substring(idx + 6, idx + 6 + 32);
		}

		this.id = card.getString(ID_FIELD);


	}

	public TrelloCard(GusWorkItem gwi) {
		this.gusId = gwi.id;
		this.name = gwi.subject;
		this.desc = gwi.getDetails();

		updateDesc();
	}

	public String getName() {
		return name;
	}

	public String getId() {
		return id;
	}

	public String getDesc() {
		return desc.split("----------")[0].trim().replace("%0a","");
	}

	public int getPoints() {
		return points;
	}

	public String getGusId() {
		return gusId;
	}

	public String getGusWorkItemUrl() {
		return gusWorkItemUrl;
	}

	public Map<String, String> getChangedValuesMap() {
		return changedValuesMap;
	}

	public void setDesc(String desc) {
		if(!TextUtil.isNullEmptyOrWhitespace(desc) &&
			(TextUtil.isNullEmptyOrWhitespace(this.getDesc()) ||
				!this.getDesc().equals(desc.trim()))) {
			this.desc = desc;
			setValueChanged("desc", this.desc);
		}
	}

	public void setName(String name) {
		if(!TextUtil.isNullEmptyOrWhitespace(name) &&
			(TextUtil.isNullEmptyOrWhitespace(this.getName()) ||
				!this.getName().equals(name.trim()))) {
			this.name = name;
			setValueChanged("name", this.name);
		}
	}

	public void updateDesc() {
		updateDesc(this.gusId);
	}

	public void updateDesc(String gwiId) {
		String oldDesc = getDesc();
		this.desc = oldDesc;
		this.desc += "%0a%0a----------";
		this.desc += "%0a" + GusContext.GUS_ENDPOINT + "/" + gwiId;
		// System.out.println("update Hash: "+TextUtil.escapeString(name + oldDesc)+" = " + TextUtil.getMD5Hash(name + oldDesc));
		this.desc += "%0aHash: " + TextUtil.getMD5Hash(name + oldDesc);
		setValueChanged("desc", this.desc);
	}

	public synchronized void setValueChanged(String field, String value) {
		if (this.changedValuesMap == null) {
			this.changedValuesMap = new HashMap<String, String>();
		}
		this.changedValuesMap.put(field, value);
	}

	public boolean isChanged() {
		if(oldHash == null) return false;
		// System.out.println(oldHash + " | " + TextUtil.getMD5Hash(name + getDesc()));
		// System.out.println("ischanged Hash: "+TextUtil.escapeString(name + getDesc())+" = " + TextUtil.getMD5Hash(name + getDesc()));
		return !oldHash.equals(TextUtil.getMD5Hash(name + getDesc()));
	}

	public void setGusId(String gusId) {
		this.gusId = gusId;
	}

	public void setGusWorkItemUrl(String gusWorkItemUrl) {
		this.gusWorkItemUrl = gusWorkItemUrl;
		if (this.desc == null || this.desc.trim().length() == 0) {
			this.desc = gusWorkItemUrl;
		}
		else if (!this.desc.contains(gusWorkItemUrl)) {
			this.desc += "\r\n" + gusWorkItemUrl + "\r\n";
		}
	}
	
	public boolean hasGusWorkItem() {
		return this.gusWorkItemUrl != null && this.gusWorkItemUrl.length() > 0;
	}

	// Function will return true if this trellocard and gusworkitem have the same content i.e. detect changes between them
	public boolean equals(GusWorkItem gwi) {
		return gwi.subject.equals(this.name) && gwi.getDetails().equals(getDesc());
	}

	// Function will detect if this trellocard and gusworkitem are about the same topic and linked together (using gus id)
	// TODO: implement function
	public boolean same(GusWorkItem gwi) {
		return false;
	}

	// if this function return true, it means keep this work item 
	public boolean filter(String kw, boolean filterIn) {
	    Pattern pat = Pattern.compile(kw);
	    Matcher match = pat.matcher(this.name);
	    return (filterIn ? match.find() : !match.find());
	}

	public String toString() {
		String ret = "{Card Id: " + this.id;
		ret += ", Name: " + TextUtil.escapeString(this.name);
		ret += ", Desc: " + TextUtil.escapeString(this.desc);
		if(gusWorkItemUrl != null) ret += ", gusWorkItemUrl: " + this.gusWorkItemUrl;
		ret += "}";
		return ret;
	}

	public String getCreateQuery() {
		return "&name=" + (name == null ? "" : name.replaceAll(" ", "%20")) +
		"&desc=" + (desc == null ? "" : desc.replaceAll(" ", "%20"));
	}
}
