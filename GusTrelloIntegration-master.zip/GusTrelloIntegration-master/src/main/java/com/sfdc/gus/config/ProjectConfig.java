package com.sfdc.gus.config;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.OneToMany;
import javax.persistence.FetchType;
import javax.persistence.Table;

// import org.postgresql.util.int;

import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.sfdc.gus.config.GusLogin;

@Entity
@Table(name="projectconfig", schema="configuration")
public class ProjectConfig {

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name = "projectconfigid", unique = true, nullable = false)
    private long projectConfigId;
    public long getProjectConfigId() { return projectConfigId; }
    public long getId() { return getProjectConfigId(); }

    @OneToOne
    @JoinColumn(name="gusloginid")
    private GusLogin gusLogin = null;
    public GusLogin getGusLogin() { return gusLogin; }

    @OneToOne
    @JoinColumn(name="trellologinid")
    private TrelloLogin trelloLogin = null;
    public TrelloLogin getTrelloLogin() { return trelloLogin; }

    // @Column(name="syncfrequency", columnDefinition="interval")
    private int syncFrequency;
    public int getSyncFrequency() { return syncFrequency; }
    public void setSyncFrequency(int seconds) { syncFrequency = seconds; }

    @OneToMany(mappedBy="projectConfig", fetch=FetchType.EAGER)
    private List<ProductListMapping> productListMappings;
    public List<ProductListMapping> getProductListMappings() { return productListMappings; }

    @OneToMany(mappedBy="projectConfig", fetch=FetchType.EAGER)
    private List<ExtraTeamAssociation> extraAssociations;
    public List<ExtraTeamAssociation> getExtraTeamAssociations() { return extraAssociations; }

    public ProjectConfig() {}
    public ProjectConfig(int syncfreq, GusLogin gusLogin, TrelloLogin trellocfg) {
        // An ID is used internally (in DatabaseHelper sync functions) as an indication that the ID remains to be set
        this.gusLogin = gusLogin;
        this.trelloLogin = trellocfg;
        this.syncFrequency = syncfreq;
    }

    @Override
    public String toString() {
        return "<ProjectConfig "
                   + "id=" + projectConfigId
            + ", " + "guslogin=" + gusLogin.toString()
            + ", " + "trellologin=" + trelloLogin.toString()
            + ", " + "syncfrequency=" + syncFrequency
            + " >";
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder()
            .append(projectConfigId)
            .append(gusLogin)
            .append(trelloLogin)
            .append(syncFrequency)
            .toHashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) { return false; }
        if (obj == this) { return true; }
        if (obj.getClass() != getClass()) {
            return false;
        }
        ProjectConfig tlobj = (ProjectConfig) obj;
        return tlobj.getProjectConfigId() == projectConfigId
            && tlobj.getGusLogin().equals(gusLogin)
            && tlobj.getTrelloLogin().equals(trelloLogin)
            && tlobj.getSyncFrequency() == syncFrequency;
    }
}
