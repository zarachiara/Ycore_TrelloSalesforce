package com.sfdc.gus;
//import static spark.Spark.*;
import spark.Spark;

import java.io.Writer;
import java.io.StringWriter;
import java.io.File;
import java.io.IOException;
import java.io.BufferedReader;

import java.lang.InterruptedException;
import java.util.Map;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;

import spark.*;

import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;

import org.apache.log4j.Logger;

import org.json.JSONException;
import org.json.JSONArray;
import org.json.JSONObject;

import org.hibernate.SessionFactory;

import com.sforce.ws.ConnectionException;

import com.sfdc.gus.config.DatabaseHelper;
import com.sfdc.gus.config.FilterSet;
import com.sfdc.gus.config.FilterSource;
import com.sfdc.gus.config.FilterRuleType;
import com.sfdc.gus.config.FilterItem;
import com.sfdc.gus.config.GusLogin;
import com.sfdc.gus.config.GusStatus;
import com.sfdc.gus.config.GusTeam;
import com.sfdc.gus.config.ProjectConfig;
import com.sfdc.gus.config.ProductListMapping;
import com.sfdc.gus.config.TrelloLogin;
import com.sfdc.gus.security.AESDualCrypt;

public class IntegrationFrontEnd {
    private DatabaseHelper db;

    private Logger logger = Logger.getLogger(IntegrationFrontEnd.class);
    private Configuration cfg;
    private Map flash;
    private Map<Long, GusContext> gusCtxts;
    private Map<Long, TrelloContext> trelloCtxts;
    private Spark spark;

    private int GUS_USERNAME_IDX     = 0;
    private int GUS_PASSWORD_IDX     = 1;
    private int TRELLO_TOKEN_IDX     = 2;
    private String TRELLO_APIKEY = null;

    private static final String ACTION          = "action";
    private static final String ERRORS          = "errors";
    private static final String FAILURE         = "{ 'result':'failure' }";
    private static final String GUS_PASSWORD    = "gus_password";
    private static final String GUS_TEAM        = "gus_team";
    private static final String GUS_USERNAME    = "gus_username";
    private static final String SUCCESS         = "{ 'result':'success' }";
    private static final String TRELLO_TOKEN    = "trello_token";
    private static final String USER_ID         = "userId";
    private static final String TRELLO_NEW      = "trello_new";
    private static final String TRELLO_NEW_BID  = "trello_new_boardid";
    private static final String TRELLO_PROGRESS = "trello_progress";
    private static final String TRELLO_PROG_BID = "trello_progress_boardid";
    private static final String TRELLO_DONE     = "trello_done";
    private static final String TRELLO_DONE_BID = "trello_done_boardid";

    // List of threads to wait for when stopping
    private List<ProjectThread> allthreads;

    private AESDualCrypt crypter;

    // TODO: We should instead be taking in a DatabaseHelper here instead of a SessionFactory.
    public IntegrationFrontEnd(SessionFactory sessionFactory, AESDualCrypt crypter) {
        setup(sessionFactory, crypter);
    }

    private void setup(SessionFactory sessionFactory, AESDualCrypt crypter) {
        // Configure freemarker templating
        cfg = new Configuration();
        try {
            cfg.setDirectoryForTemplateLoading(new File("./templates"));
            cfg.setDefaultEncoding("UTF-8");
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Setup an object map that's used for intermediate storage of objects and keys
        flash = new HashMap();

        this.crypter = crypter;
        db = new DatabaseHelper(sessionFactory);

         // A context per thread that allows them to connect with GUS/Trello
        gusCtxts = new HashMap<Long, GusContext>();
        trelloCtxts = new HashMap<Long, TrelloContext>();

        TRELLO_APIKEY = db.getTrelloAPIKey();

        allthreads = new ArrayList<ProjectThread>();

        // Spawn the synchronizing threads
        ProjectThread.startup(db, crypter, allthreads);
    }

    /**
     * Shut down the web server, and stop all the synchronizing threads
     */
    public void stop() {
        // Stop the UI
        spark.stop();

        // Tell all the threads to stop in their next iteration
        ProjectThread.globalkeepalive = false;
        // Wait for all the threads to stop
        for (ProjectThread pt : allthreads) {
            try {
                pt.join();
            } catch (InterruptedException e) {
                logger.error("Could not stop a thread", e);
            }
        }
    }

    /**
     * Start the web server. First, routes are set for the spark server (which
     * also defines the operation at those routes), and then the spark server is ignited.
     */
    public void run() {
        spark = new Spark();
        // Spawning with HTTPS is as simple as stating where a keystore is
        // The trust store is used for connections we make to others, and is
        // not particularly needed.
        spark.secure("keystore.jks", "L1nuxRocks!", null, null);

        // location of images, css, and js
        spark.staticFileLocation("/assets");

        // Befores setup up the requirement to be logged in
        spark.before("/profile", (request, response) -> {
            isLoggedIn(request, response);
        });

        spark.before("/portal", (request, response) -> {
            isLoggedIn(request, response);
        });

        spark.get("/", (request, response) -> {
            if(request.session().attribute("logged_in") != null && (Boolean)request.session().attribute("logged_in")) {
                response.redirect("/portal");
                return "";
            } else {
                String ret = process("index.html.ftl");
                return handleProcessed(response, ret);
            }
        });

        spark.post("/route", (request, response) -> {
            logger.info("Either logging in, or creating a new user. submit=" + request.queryParams("submit"));
            if(request.queryParams("submit").equals("Login")) {
                try {
                    logger.info("Trying login with GUS an Trello");
                    if(loginUser(request, response)) {
                        logger.info("Login success. Redirecting to portal");
                        response.redirect("/portal");
                    } else {
                        logger.info("Login failed. Redirecting to login page");
                        response.redirect("/");
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else if (request.queryParams("submit").equals("New User")) {
                response.redirect("/form");
            } else {
                response.redirect("/");
            }
            return response;
        });

        // After the OAuth flow through salesforce, the user will redirected to here, and will now have allowed access to GUS
        spark.get("/sfcallback", (request, response) -> {
            if(request.queryParams("code") == null || request.queryParams("code").equals("")) {
                flashError("Can't complete the Salesforce Authentication Process");
            } else if(request.queryParams("error") != null) {
                flashError("Error during Authentication: " + request.queryParams("error_description"));
            } else {
                String code = request.queryParams("code");
                System.out.println("IFE got code : " + code);
                Map<String, String> params = new HashMap<String, String>();
                params.put("grant_type","authorization_code");
                params.put("client_id",crypter.decrypt(GusContext.GUS_CLIENT_ID));
                params.put("client_secret",crypter.decrypt(GusContext.GUS_CLIENT_SECRET));
                params.put("redirect_uri","http%3A%2F%2Fmbuland-wsl%3A4567%2Fsfcallback");
                params.put("code",code.replace("=","%3D"));

                Map<String, String> headers = new HashMap<String, String>();
                headers.put("Content-Type","application/x-www-form-urlencoded");

                try {
                    JSONObject json = RestUtil.simplePost(GusContext.GUS_ENDPOINT + "/services/oauth2/token", headers, params);
                    logger.debug("RESPONSE FROM CALLBACK: " + json.toString());
                    if (json.has("error")) {
                        flashError(json.getString("error_description"));
                    } else if (json.has("access_token")) {
                        String id = json.getString("id");
                        String gusUId = id.substring(id.length() - 18);
                        logger.debug("GUS USER ID: " + gusUId);
                        request.session().attribute("gusUId",gusUId);
                        request.session().attribute("access_token",json.getString("access_token"));
                        request.session().attribute("refresh_token",crypter.encrypt(json.getString("refresh_token")));
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            response.redirect("/form"); 
            return "";
        });

        spark.get("/form", (request, response) -> {
            if(request.session().attribute("access_token") != null) flash.put("gls", true);
            flash.put("trello_key",crypter.decrypt(TRELLO_APIKEY));
            String ret = process("form.html.ftl");
            return handleProcessed(response, ret);
        });

        spark.post("/ajax_endpoint", (request, response) -> {
            try {
                Map<String, String> body = parseBody(request.body());
                logger.debug("ajax_endpoint: body: " + body);
                if(body.get(ACTION).equals("new_relation")) {
                    logger.debug("Attempting to make a new relation");
                    return newRelation(request.session().attribute(USER_ID),body);
                } else if (body.get(ACTION).equals("remove_relation")) {
                    removeRelation(request.session().attribute(USER_ID),body.get("id"));
                    return jsonEncode(SUCCESS);
                } else if (body.get(ACTION).equals("logout")) {
                    logout(request);
                    return jsonEncode(SUCCESS);
                } else if (body.get(ACTION).equals("add_item")) {
                    String ret = addNewProfileItem(request.session().attribute(USER_ID),body);
                    gusCtxts.get(request.session().attribute(USER_ID)).refreshGusInfo();
                    return ret;
                } else if (body.get(ACTION).equals("remove_item")) {
                    String ret = removeProfileItem(request.session().attribute(USER_ID), body);
                    gusCtxts.get(request.session().attribute(USER_ID)).refreshGusInfo();
                    return ret;
                } else if (body.get(ACTION).equals("update_sync")) {
                    int sync_time = Integer.parseInt(body.get("sync"));
                    if (sync_time < 10) {
                        return jsonEncode(FAILURE);
                    }
                    updateSyncTime(request.session().attribute(USER_ID), sync_time);
                    return jsonEncode(SUCCESS);
                } else if (body.get(ACTION).equals("delete_profile")) {
                    logger.debug("----Deleting user----");
                    logger.debug("Session: " + request.session());
                    deleteThisUser(request);
                    return jsonEncode(SUCCESS);
                }

            } catch (Exception e) {
                logger.error("Error during ajax_endpoint for user " + request.session().attribute(USER_ID)+".",e);
                e.printStackTrace();
            }
            return jsonEncode(FAILURE);
        });

        spark.get("/portal", (request, response) -> {
            try {
                Long userId = request.session().attribute(USER_ID);
                flash.put("trello_boards",trelloCtxts.get(userId).getTrelloInfo());
                flash.put("gus_teams",gusCtxts.get(userId).getGusInfo(db.getExtraTeamAssociations(userId)));
                flash.put("current_relations", replaceIdsWithNames(userId,db.getProjectConfig(userId).getProductListMappings()));
            } catch(NullPointerException e) {
                // These occur when tctx and gctx are not set due to the user going to /portal without logging in
            } catch(Exception e) {
                logger.error("Portal recieved Exception", e);
            }
            String ret = process("portal.html.ftl");
            return handleProcessed(response, ret);
        });

        spark.get("/profile", (request, response) -> {
            try {
                Long userId = request.session().attribute(USER_ID);
                ProjectConfig pc = db.getProjectConfig(userId.longValue());
                flash.put("trello_boards",trelloCtxts.get(userId).getTrelloInfo());
                flash.put("gus_teams",gusCtxts.get(userId).getGusInfo(db.getExtraTeamAssociations(userId)));
                flash.put("sync_time",pc.getSyncFrequency());
                flash.put("username",gusCtxts.get(userId).getUserName());
            } catch (NullPointerException e) {

            } catch (Exception e) {
                logger.error("Profile received Exception", e);
            }
            String ret = process("profile.html.ftl");
            return handleProcessed(response, ret);
        });

        spark.get("/new", (request, response) -> {
            response.redirect("/");
            return "";
        });

        spark.post("/new", (request, response) -> {
            try {
                logger.debug("In /new");
                Boolean success = newUser(request);
                if(success) {
                    flash.put("first_time",true);
                    response.redirect("/profile");
                } else {
                    logger.debug("Login has failed. Redirecting to the form");
                    response.redirect("/form");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return "";
        });

    }

    /**
     * Requires the user to be logged in so that we know which user to delete.
     * This is called via AJAX
     */
    private void deleteThisUser(Request request) {
        logger.debug("---- Delete This User ----");
        logger.debug("DB: " + db);
        logger.debug("request: " + request);
        logger.debug("Session: " + request.session());
        for (String attr : request.session().attributes()) {
            logger.debug("\t" + attr + " -> " + request.session().attribute(attr));
        }
        logger.debug("userId: "  + request.session().attribute(USER_ID));
        logger.debug("ProjectConfig: " + db.getProjectConfig(request.session().attribute(USER_ID)));
        db.deleteUser(db.getProjectConfig(request.session().attribute(USER_ID)));
        logout(request);
    }

    /**
     * A user updates the frequency of their sync, which results in an AJAX call to here
     */
    private void updateSyncTime(Long userId, int sync_time) {
        ProjectConfig pc = db.getProjectConfig(userId);
        pc.setSyncFrequency(sync_time);
        db.saveUpdate(pc);
    }

    /**
     * Clears any attributes in the session that identify if a user is logged in
     */
    private void logout(Request request) {
        request.session().removeAttribute("logged_in");
        gusCtxts.remove(request.session().attribute(USER_ID));
        trelloCtxts.remove(request.session().attribute(USER_ID));
        request.session().removeAttribute(USER_ID);
    }

    /**
     * When a user clicks on the removal button for a relation, it calls into here
     * first to delete the relation.
     */
    private void removeRelation(Long userId, String id) {
        String[] ids = id.split("\\|");
        for(String i : ids) {
            logger.debug("Removing relation with id: " + i);
            db.removeRelationForUser(userId, i);
        }
    }

    /**
     * Checks the session perameters to see if a user is logged in
     */
    private void isLoggedIn(Request request, Response response) {
        if(request.session().attribute("logged_in") == null || !(Boolean)request.session().attribute("logged_in")) {
            response.redirect("/");
        }
    }

    /**
     * When a user tries to login, we need to verify that they put in their
     * credentials correctly, and then proceed to fill in the session with
     * identifications for the user, marking them as logged in.
     */
    private Boolean loginUser(Request request, Response response) {
        String uname = request.queryParams("uname");
        String pword = crypter.encrypt(request.queryParams("pword"));
        logger.info("Attempting to log in as '" + uname + "'");

        if(uname.length() == 0 || pword.length() == 0) {
            flashError("Username or Password are incorrect", new String[]{"uname","pword"});
        } else {
            try {
                GusContext gctx = GusContext.login(uname, pword, db, crypter);

                // Login will throw an exception on failure.
                gctx.getUserName();

                ProjectConfig pc = db.getProjectForUserId(gctx.getUserId());

                request.session().attribute(USER_ID, pc.getProjectConfigId());
                request.session().attribute("logged_in",true);

                gusCtxts.put(pc.getProjectConfigId(), gctx);
                TrelloContext tctx = new TrelloContext(pc.getTrelloLogin(), TRELLO_APIKEY, crypter);
                trelloCtxts.put(pc.getProjectConfigId(), tctx);

                return true;
            } catch(Exception e) {
                flashError("Username or Password are incorrect", new String[]{"uname","pword"});
                flash.put("uname",uname);
            }
        }

        return false;
    }

    /**
     * When first creating a user, we need to verify that they have access to
     * both GUS and Trello before spawning off a thread for their synchronization.
     */
    private Boolean newUser(Request request) {
        GusContext gctx = null;
        TrelloContext tctx = null;

        // Validate that Gus Authorization worked
        if (request.session().attribute("refresh_token") == null) {
            flashError("Gus needs to be Authorized!");
        } else {
            gctx = new GusContext(new GusLogin(request.session().attribute("gusUId"),request.session().attribute("refresh_token")), crypter);
            gctx.setSessionId(request.session().attribute("access_token"));
            try {
                //gctx.refresh();
                logger.debug("USERNAME: " + gctx.getUserName());
                gctx.getGusInfo();
            } catch (JSONException e) {
                flashError("We can't access your Gus user, please try a different account");
                request.session().attribute("gusUId",null);
                request.session().attribute("refresh_token",null);
                request.session().attribute("access_token",null);
            } catch (Exception e) {
                flashError("Caught Exception: " + e.getMessage());
                e.printStackTrace();
            }

            // Check if this user already exists
            ProjectConfig pc = db.getProjectForUserId(gctx.getUserId());
            if(pc != null) { 
                flashError("This Gus user is already registered with this app!");
            }
        }

        // Validation of Trello credentials
        String trelloToken = request.queryParams(TRELLO_TOKEN);
        if (trelloToken == null || trelloToken.equals("")) {
            flashError("Trello Token is required", new String[]{TRELLO_TOKEN});
        } else {
            tctx = new TrelloContext(new TrelloLogin(crypter.encrypt(trelloToken)), TRELLO_APIKEY, crypter);
            try {
                JSONArray json = tctx.getMyBoards();
            } catch (JSONException e) {
                e.printStackTrace();
                flashError("Invalid Trello Token", new String[]{TRELLO_TOKEN});
            } catch (IllegalArgumentException e) {
                e.printStackTrace();
                flashError("Invalid Trello Token", new String[]{TRELLO_TOKEN});
            } catch (Exception e) {
                e.printStackTrace();
                flashError("Exception: " + e.getMessage());
            }
        }

        // If no errors are present, this was a successful login
        if (flash.get("error") == null && gctx != null && tctx != null) { 
            request.session().attribute("logged_in",true);
            ProjectConfig projectConfig = db.createUser(request.session().attribute("gusUId"), request.session().attribute("refresh_token"), crypter.encrypt(trelloToken), 600);
            request.session().attribute("gusUId",null);
            request.session().attribute("refresh_token",null);
            request.session().attribute("access_token",null);
            request.session().attribute(USER_ID, projectConfig.getProjectConfigId());

            // Spawn off a thread dedicated to this user
            createNewProjectThread(projectConfig);

            gusCtxts.put(projectConfig.getProjectConfigId(), gctx);
            trelloCtxts.put(projectConfig.getProjectConfigId(), tctx);

            logger.info("New User was created");
            return true;
        } else {
            cpyFields(request);
        }

        return false;
    }

    /**
     * Notifications for the web page that a field or operation had an error
     */
    private void flashError(String err) { flashError(err, null); }
    private void flashError(String err, String[] fields) {
        if(flash.get("error") == null) flash.put("error",new ArrayList());
        ((ArrayList)flash.get("error")).add(err);
        if(fields == null) return;
        for(String field : fields) {
            flash.put("error_fields_"+field,true);
        }
    }

    /**
     * Process a freemarker template with the flash messages
     */
    private String process(String template) {
        try {
            Template t = cfg.getTemplate(template);
            Writer out = new StringWriter();
            t.process(flash, out);
            flash.clear();
            return out.toString();
        } catch (Exception e) {
            e.printStackTrace(); 
        }
        return null;
    }

    /**
     * If the response was null, indicate an internal server error
     */
    private String handleProcessed(Response response, String ret) {
        if(ret == null) {
            response.status(500);
            return "Something went wrong...";
        }
        return ret;
    }

    /**
     * Pass the trello token from the input request into the flash
     */
    private void cpyFields(Request req) {
        flash.put(TRELLO_TOKEN,req.queryParams(TRELLO_TOKEN));
    }

    /**
     * When a user wants to add a new relation, we call into the database to
     * save the inputs.
     */
    private String newRelation(Long projectId, Map<String, String> req) {
        if(!validateFields(req)) {
            req.put("result","failure");
        } else {
            if(db == null) logger.debug("DB somehow became null...");
            db.addRelationForUser(projectId, req);
            req.put("result","success");
        }

        replaceIdsWithNames(projectId, req);

        JSONObject json = new JSONObject(req);
        return json.toString();
    }

    /**
     * Operations for when a user wants to recognize a new team or product tag
     */
    private String addNewProfileItem(Long userId, Map<String, String> req) {
        if (req.get("type") == null || req.get("value") == null) {
            req.put("result","failure");
            JSONObject json = new JSONObject(req);
            return json.toString();
        }

        try {
            String temp = null;
            if(req.get("type").equals("addTeam") && (temp = gusCtxts.get(userId).getTeamIfExists(req.get("value"))) != null) {
                db.createExtraTeamAssociation(userId, req.get("value"));
                ProjectConfig pc = db.getProjectConfig(userId);
                logger.debug("After creating an getExtraTeamAssociation, there are now " + pc.getExtraTeamAssociations().size() + " ExtraTeamAssociations");
                req.put("id",temp);
                req.put("result","success");
            } else if(req.get("type").equals("addProduct") && (temp = gusCtxts.get(userId).getProductIfExists(req.get("value"))) != null) {
                // TODO: Add gus product to db
                req.put("id",temp);
                req.put("result","success");
            } else {
                req.put("result","failure");
            }
        } catch (Exception e) {
            logger.error("Caught Error while processing new profile item", e);
            req.put("result", "failure");
        }

        JSONObject json = new JSONObject(req);
        return json.toString();
    }

    /**
     * Operations for when a user does not want to include a team in their extra
     * list anymore.
     */
    private String removeProfileItem(Long userId, Map<String, String> req) {
        if (req.get("type") == null || req.get("name") == null) {
            req.put("result","failure");
            JSONObject json = new JSONObject(req);
            return json.toString();
        }

        try {
            if(req.get("type").equals("team")) {
                boolean result = db.deleteExtraTeamAssociation(userId,
                    req.get("name"));
                if (result) {
                    req.put("result","success");
                } else {
                    req.put("result","failure");
                }
            } else {
                req.put("result","failure");
            }
        } catch (Exception e) {
            logger.error("Caught Error while processing remove profile item", e);
            req.put("result", "failure");
        }

        JSONObject json = new JSONObject(req);
        return json.toString();
    }

    /**
     * Replace single quotes with doubles
     */
    private String jsonEncode(String json) {
        return json.replaceAll("'","\"");
    }

    /**
     * Encoded data comes back in the body for AJAX calls, but it's all
     * URL encoded. This de-URL-encodes.
     */
    private Map<String, String> parseBody(String body) {
        logger.debug("parseBody - recieved: " + body);
        if(body.isEmpty()) return new HashMap<String, String>();
        String[] keyVals = body.replaceAll("%5B","[")
            .replaceAll("%5D","]")
            .replaceAll("%7C","|")
            .split("&");
        Map<String, String> ret = new HashMap<String, String>();
        for(String str : keyVals) {
            String[] keyVal = str.replaceAll("%26","&").split("=",2);
            ret.put(keyVal[0].replaceAll("\\+"," "),keyVal[1].replaceAll("\\+"," "));
        }
        return ret;
    }

    /**
     * Validate that required input fields are input when creating a relation
     */
    private Boolean validateFields(Map<String, String> req) {
        if(req.get(GUS_TEAM) == null || req.get(GUS_TEAM).isEmpty()) {
            requestFieldsError(req,GUS_TEAM, "Gus Team can't be blank!");
        }

        if(req.get(TRELLO_NEW) == null || req.get(TRELLO_NEW).isEmpty()) {
            requestFieldsError(req,TRELLO_NEW, "Trello New List can't be blank!");
        }

        if(req.get(TRELLO_PROGRESS) == null || req.get(TRELLO_PROGRESS).isEmpty()) {
            requestFieldsError(req,TRELLO_PROGRESS, "Trello In Progress List can't be blank!");
        }

        if(req.get(TRELLO_DONE) == null || req.get(TRELLO_DONE).isEmpty()) {
            requestFieldsError(req,TRELLO_DONE, "Trello Done List can't be blank!");
        }

        if((req.get(TRELLO_DONE_BID) == null ||
            req.get(TRELLO_PROG_BID) == null ||
            req.get(TRELLO_NEW_BID) == null) ||
            (req.get(TRELLO_NEW_BID) != null && 
            req.get(TRELLO_PROG_BID) != null && 
            req.get(TRELLO_DONE_BID) != null) && 
                (!req.get(TRELLO_NEW_BID).equals(req.get(TRELLO_PROG_BID)) || 
                    !req.get(TRELLO_NEW_BID).equals(req.get(TRELLO_DONE_BID)))
            ) {
            requestFieldsError(req,"trello_new|trello_done|trello_progress", "Trello Lists must come from the same Trello Board");
        }

        if(req.get(ERRORS) != null) return false;
        return true;
    }

    /**
     * Adds error message to flash as well as which fields are causing the error. Will be parsed for error messages by the ftl files
     */
    private void requestFieldsError(Map<String, String> req, String field, String msg) {
        if(req.get(ERRORS) == null) {
            req.put(ERRORS,msg);
            req.put("error_fields",field);
        } else {
            req.put(ERRORS,req.get(ERRORS)+"|"+msg);
            req.put("error_fields",req.get("error_fields")+"|"+field);
        }
    }

    /**
     * We store the IDs of all the teams and lists and etc. This will translate them into
     * names/labels from the object.
     */
    private Map<String, String> replaceIdsWithNames(Long projectId, Map<String, String> req) {
        try {
            List<Map> gusInfo = gusCtxts.get(projectId).getGusInfo();
            List<Map> gusProdTags = gusCtxts.get(projectId).getProductTags();
            List<Map> trelloLists = trelloCtxts.get(projectId).getLists();
            findReplace(GUS_TEAM, gusInfo, req);
            findReplace(TRELLO_NEW, trelloLists, req);
            findReplace(TRELLO_PROGRESS, trelloLists, req);
            findReplace(TRELLO_DONE, trelloLists, req);
            findReplace("product_tag", gusProdTags, req);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return req;
    }

    /**
     * Our front end idea of a relation contains 3 mappings, one for each list.
     * We need to translate between the 2 models, which is largely what this does,
     * in addition to showing/translating between ID and Name.
     *
     * It's assumed that the list of mappings passed in contains sets of 3. Each triplet
     * represents one relation.
     */
    private List<Map<String,String>> replaceIdsWithNames(Long userId, List<ProductListMapping> mappings) {
        List<Map<String,String>> rels = new ArrayList<Map<String,String>>();
        try {
            List<Map> gusInfo = gusCtxts.get(userId).getGusInfo();
            List<Map> gusProdTags = gusCtxts.get(userId).getProductTags();
            List<Map> trelloLists = trelloCtxts.get(userId).getLists();

            // NOTE: Assume triplets in the list
            for (int i=0; i<mappings.size(); i+=3) {
                Map<String, String> req = new HashMap<String,String>();

                req.put("product_tag", getName(mappings.get(i).getGusProduct().getProductName(), gusProdTags));
                req.put(GUS_TEAM, getName(mappings.get(i).getGusProduct().getGusTeam().getTeamName(), gusInfo));

                req.put("gus_filter_in", getFilterNames(mappings.get(i).getFilters(), FilterSource.GUS, FilterRuleType.IMPORT));
                req.put("gus_filter_out", getFilterNames(mappings.get(i).getFilters(), FilterSource.GUS, FilterRuleType.EXPORT));
                req.put("trello_filter_in", getFilterNames(mappings.get(i).getFilters(), FilterSource.TRELLO, FilterRuleType.IMPORT));
                req.put("trello_filter_out", getFilterNames(mappings.get(i).getFilters(), FilterSource.TRELLO, FilterRuleType.EXPORT));
                String id = "";

                // In this next triplet, find these 3 by status
                for (int j=0; j < 3; j++) {
                    GusStatus status = mappings.get(i+j).getGusStatus();
                    switch (status) {
                    case NEW:
                        if (req.get(TRELLO_NEW) != null) { logger.error("Inside a relation, there should only be 1 mapping of each status. This triplet has 2 of one status"); }
                        id += mappings.get(i+j).getProductListMappingId() + "|";
                        req.put(TRELLO_NEW, getName(mappings.get(i+j).getTrelloList().getListName(), trelloLists));
                        break;
                    case IN_PROGRESS:
                        if (req.get(TRELLO_PROGRESS) != null) { logger.error("Inside a relation, there should only be 1 mapping of each status. This triplet has 2 of one status"); }
                        id += mappings.get(i+j).getProductListMappingId() + "|";
                        req.put(TRELLO_PROGRESS, getName(mappings.get(i+j).getTrelloList().getListName(), trelloLists));
                        break;
                    case COMPLETED:
                        if (req.get(TRELLO_DONE) != null) { logger.error("Inside a relation, there should only be 1 mapping of each status. This triplet has 2 of one status"); }
                        id += mappings.get(i+j).getProductListMappingId() + "|";
                        req.put(TRELLO_DONE, getName(mappings.get(i+j).getTrelloList().getListName(), trelloLists));
                        break;
                    default:
                        logger.error("A status of " + status.toString() + " was found, but was expecting NEW, IN_PROGRESS, or COMPLETED");
                    }
                }

                req.put("id",id);
                if(req.get("gus_filter_in") == null) req.put("gus_filter_in","");
                if(req.get("gus_filter_out") == null) req.put("gus_filter_out","");
                if(req.get("trello_filter_in") == null) req.put("trello_filter_in","");
                if(req.get("trello_filter_out") == null) req.put("trello_filter_out","");
                rels.add(req);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return rels;
    }

    /**
     * Takes in a Filtering, and produces a representation of it in text.
     */
    private String getFilterNames(List<FilterSet> fss, FilterSource fsrc, FilterRuleType ft) {
        logger.debug("Found filtersets: " + fss + ", looking for source: " + fsrc + " and type: " + ft);
        String ret = "";
        for (FilterSet fs : fss) {
            logger.debug("with filterItems: " + fs.getFilterItems());
            if(fs.getFilterSource() == fsrc && fs.getFilterRuleType() == ft) {
                for (FilterItem fi : fs.getFilterItems()) {
                    ret += (ret.length() == 0 ? "" : "<br/>") + fi.getKeyword();
                }
                logger.debug("returning: " + ret);
                return ret;
            }
        }
        return ret;
    }

    /**
     * Given a list of maps of the form {"Id" : "...", "Name" : "..."}, return
     * the name for the matched Id
     */
    private String getName(String id, List<Map> info) {
        for (Map m : info) {
            if (id.equals(m.get("Id"))) {
                return (String) m.get("Name");
            }
        }
        return "Not Found";
    }

    /**
     * Assumes that Map is a Map<String, String>, but is unable to explicitly state this (due to construction)
     * 
     * Provided a list of maps of the form {"Id": "some_id", "Name": "some_name", ...}, a req map of {"key": "some_id", ...}, and said key,
     * then replace "some_id" with "some_name" in the req map. Used when constructing the portal page since we store the team ids in the db.
     * Need to map the ids to the actual names of the teams. Or lists.
     */
    private void findReplace(String key, List<Map> list, Map req) {
        String temp = "Not Found";
        String id = (String)req.get(key);
        for(Map m : list) {
            if(id != null && id.equals(m.get("Id"))) {
                temp = (String)m.get("Name");
                break;
            }
        }
        req.put(key, temp);
    }

    /**
     * Spawn a project thread for a user (identified by ProjectConfig)
     */
    private void createNewProjectThread(ProjectConfig projectConfig) {
        ProjectThread pt = new ProjectThread(projectConfig, db, crypter);
        pt.start();
    }
}
