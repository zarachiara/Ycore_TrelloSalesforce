package com.sfdc.gus;

import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.Collection;
import java.util.Properties;
import java.util.List;
import java.util.ArrayList;
import java.io.IOException;

import org.json.JSONException;
import org.json.JSONArray;
import org.json.JSONObject;
import org.apache.http.client.ClientProtocolException;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.apache.log4j.EnhancedPatternLayout;
import org.apache.log4j.RollingFileAppender;
import org.apache.log4j.Level;

import org.hibernate.Session;

import com.sfdc.gus.config.DatabaseHelper;
import com.sfdc.gus.config.ProductListMapping;
import com.sfdc.gus.config.ProjectConfig;
import com.sfdc.gus.config.FilterSet;
import com.sfdc.gus.config.FilterSource;
import com.sfdc.gus.config.FilterRuleType;
import com.sfdc.gus.config.FilterItem;
import com.sfdc.gus.security.AESDualCrypt;
import com.sfdc.gus.config.GusStatus;
import com.sforce.soap.enterprise.fault.LoginFault;

class ProjectThread extends Thread {

    // Changing this to false will stop all the threads in their next iteration
    public static boolean globalkeepalive = true;

    // Each ProjectThread has its own logger with a file appender which will write to its own, 
    // unique file. If a specific user is having issues, their log could be looked at instead of
    // a monolithic one
    private Logger logger = null;

    private DatabaseHelper db;
    private ProjectConfig projectConfig;
    private long projectId;
    private int iteration = 1;

    private GusContext gctx;
    private TrelloContext tctx;

    private Boolean invalidGctx = false;
    private Boolean invalidTctx = false;

    /*
     * NOTE: It's true that holding onto the ProjectConfig object is "heavy", but that may be preferable
     * to hammering the database with full queries. Hibernate allows for refresh(), which should be more
     * efficient than fully loading every run
     */
    public ProjectThread(ProjectConfig project, DatabaseHelper dbHelper, AESDualCrypt crypter) {
        this.db = dbHelper;

        // Lookup the current information for this user/project
        this.projectConfig = project;
        this.projectId = project.getProjectConfigId();

        // create logger with name of the projectConfig
        logger = Logger.getLogger(ProjectThread.class+"["+projectId+"]");

        try {
            EnhancedPatternLayout layout = new EnhancedPatternLayout("%d [%-5p] %c:%L - %m%n");    
            RollingFileAppender appender = new RollingFileAppender(layout,"logs/user_"+projectId+".log",true);    
            logger.addAppender(appender);
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Unfortunately, no way to set the logging level when the logger name is dynamic
        logger.setLevel((Level) Level.DEBUG);

        gctx = new GusContext(projectConfig.getGusLogin(), crypter);
        // TODO: call gctx.refresh() here. Shouldn't break anything, but not enough time to test to verify

        tctx = new TrelloContext(projectConfig.getTrelloLogin(), db.getTrelloAPIKey(), crypter);
    }

    /*
     * Upon startup of the server, this function will be run and start a ProjectThread for each projectConfig that exists
     */
    public static void startup(DatabaseHelper db, AESDualCrypt crypter, List<ProjectThread> allthreads) {
        GusContext.setup(db);
        List<ProjectConfig> pcs = db.getAllProjectConfigs();
        for(ProjectConfig pc : pcs) {
            ProjectThread pt = new ProjectThread(pc, db, crypter);
            allthreads.add(pt);
            pt.start();
        }
    }

    /*
     * run function will go through each ProductListMapping and sync the Gus Work Items with the Trello Cards
     */
    public void run() {
        // We run only if the threads should run (easy way to stop all threads is setting this to false)
        while (globalkeepalive) {
            // If this projectConfig was deleted, this thread has nothing to do
            if(!db.userIdExists(projectConfig.getGusLogin().getUserId())) {
                logger.fatal("This thread has no user. Goodbye.");
                return;
            }

            // Refresh the ProjectConfig object from the database, keeping up to date
            db.refresh(projectConfig, projectConfig.getProjectConfigId());

            logger.debug("Running, on iteration: " + iteration + ", globalkeepalive = " + globalkeepalive);
            ++iteration;


            logger.debug("Gus User Id: " + projectConfig.getGusLogin().getUserId());

            // If there was an issue in a previous iteration, try and resolve it
            if(isInvalid()) {
                boolean stillInv = false;
                try {
                    gctx.refresh();
                    gctx.getUserName();
                } catch (Exception e) {
                    stillInv = true;
                }

                if(!stillInv) {
                    invalidGctx = false;
                }
            }

            // If resolved and/or not invalid, verify connection to Gus and Trello
            if(!isInvalid()) {
                try {
                    gctx.getUserName();

                } catch (JSONException e) {
                    logger.error("Caught JSONException, refreshing gus context", e);
                    try {
                        gctx.refresh();
                        gctx.getUserName();
                    } catch (Exception ne) {
                        logger.error("Re-login failed, setting thread to invalid", ne);
                        invalidGctx = true;
                    }
                } catch (Exception e) {
                    logger.error("encountered an Exception",e);
                }

                try {
                    tctx.getMe();
                } catch (Exception e) {
                    logger.error("Caught Exception, not much can be done for trello context...", e);
                    invalidTctx = true;
                }

                // If this thread is still valid, go ahead and start syncing things
                if(!isInvalid()) {
                    try {
                        syncRelations();
                    } catch (Exception e) {
                        logger.error("Encountered an Exception while trying to sync relations", e);
                    }
                }
            } else {
                logger.info("Thread is invalid, skipping");
            }

            try {
                logger.debug("Sleeping for " + projectConfig.getSyncFrequency() + " seconds");
                // we sleep for the interval specified by this user.
                Thread.sleep(projectConfig.getSyncFrequency()*1000);
            } catch (InterruptedException e) {
                logger.fatal("Was interrupted",e);
                return;
            }
        }
        logger.debug("globalkeepalive was set to false, Goodbye");
    }

    /*
     * Checks if either the GusContext or the TrelloContext has had connection issues
     */
    public Boolean isInvalid() {
        return invalidGctx || invalidTctx;
    }

    /* 
     * Meat of the syncing process - will iterate through all ProductListMappings and make sure everything is up to date
     */
    private void syncRelations() throws ClientProtocolException, JSONException, IOException {
        logger.debug("This thread has " + projectConfig.getProductListMappings().size() + " relations.");

        // Map each team to a map of work item ids to the actual work item
        Map<String, Map<String, GusWorkItem>> gusTeamCards = new HashMap<String, Map<String, GusWorkItem>>();
        List<ProductListMapping> plms = projectConfig.getProductListMappings();

        // For every product list mapping...
        for(ProductListMapping plm : plms) {
            // skip this plm if configured to do so
            if (!plm.isSyncEnabled()) {
                continue;
            }
            logger.debug("For relation " + plm.getProductListMappingId() + " with status " + plm.getGusStatus().getName());
            logger.debug("plm board id: " + plm.getTrelloList().getTrelloBoard().getBoardName());

            // Check if we've grabbed the work items for this team yet. If not, grab them.
            String gusTeamId = plm.getGusProduct().getGusTeam().getTeamName();
            if(gusTeamCards.get(gusTeamId) == null) {
                gusTeamCards.put(gusTeamId, gctx.getAllMyWorkItems(gusTeamId));
            }

            // Grab work items, then filter out the ones that are configured to be filtered out
            Map<String, GusWorkItem> gwis = gusTeamCards.get(gusTeamId);
            logger.debug("There are " + gwis.size() + " work items detected for Gus. Filtering now.");
            filterWorkItems(gwis, plm);
            logger.debug("There are now " + gwis.size() + " work items after filtering");


            // Grab cards, then filter out the ones that are configured to be filtered out
            Map<String, TrelloCard> tcs = tctx.getMyCards(plm.getTrelloList().getListName());
            logger.debug("Looking through " + tcs.size() + " TrelloCards for status changes");
            filterCards(tcs, plm);
            logger.debug("Thero are now " + tcs.size() + " cards after filtering");

            // This will check if the trello card status has been updated but the GWI has not been.
            // TODO: All of this logic should be done with the syncing of the name/details instead of separate
            for (TrelloCard tc : tcs.values()) {
                GusWorkItem gwi = null;
                if(gwis.get(tc.gusId) == null) {
                    try {
                        // If the gwi was filtered out before, grab it again
                        // TODO: try not to requery, just don't throw away. Save on SOQL queries, save the planet!
                        gwi = gctx.getGusWorkItem(tc.gusId);
                    } catch (Exception e) {
                        continue;
                    }
                    gwis.put(gwi.id, gwi);
                } else {
                    gwi = gwis.get(tc.gusId);
                }
                
                // Check the status of the plm and the gwi, see if it changed.
                if (!gwi.status.equalsIgnoreCase(plm.getGusStatus().getName())) {
                    logger.debug("For GWI: " + gwi.subject + ", was status " + gwi.status + ", now " + plm.getGusStatus().getName());
                    gwi.setStatus(plm.getGusStatus().getName());
                }
            }
            logger.debug("Attempting to sync " + tcs.size() + " TrelloCards now");

            // compare each gwi with the tc that we (may or may not) have for it
            for (GusWorkItem gwi : gwis.values()) {
                // If this work item isn't the same status as the trello list we're looking at, skip
                if(!gwi.status.equals(plm.getGusStatus().getName())) continue;

                // Check gus cards, see if any trello cards need creating
                boolean hasTrelloCard = gwi.trelloCardId != null;
                // Check if this GWI already has a trello card linked to it
                boolean trelloLinksToGwi = false;
                if (!hasTrelloCard) {
                    String trelloId = null;
                    for(TrelloCard tc : tcs.values()) {
                        if(gwis.get(tc.gusId) != null) {
                            trelloId = tc.id;
                            trelloLinksToGwi = true;
                            break;
                        }
                    }
                    if (trelloLinksToGwi) {
                        gwi.trelloCardId = trelloId;
                        hasTrelloCard = true;
                    }
                }
                
                if (!hasTrelloCard) {
                    // This Gus Work item has no Trello Cards, create one
                    createNewTrelloCard(gwi, plm.getTrelloList().getListName());
                } else {
                    // This gus work item has a trello card, time to check their values

                    TrelloCard tc = tcs.remove(gwi.trelloCardId);

                    // do we already have it?
                    if (tc == null) {
                        try {
                            // grab it if it exists
                            tc = tctx.getCard(gwi.trelloCardId);
                        } catch (JSONException e) {
                            // trello card no longer exists, deleted. Mark gus card as closed
                            tc = null;
                        }
                    }

                    // If tc doesn't exist, we need to recreate it as a Closed/Completed card
                    // TODO: is this really the behavior we want?
                    if (tc == null) {
                        if (plm.getGusStatus() == GusStatus.COMPLETED) {
                            createNewTrelloCard(gwi, plm.getTrelloList().getListName());
                        } else {
                            // Search for the Closed/Completed list for this Trello board
                            String boardId = plm.getTrelloList().getTrelloBoard().getBoardName();
                            String closedListId = null;

                            for (ProductListMapping searchPlm : plms) {
                                if (searchPlm.getTrelloList().getTrelloBoard().getBoardName().equals(boardId) &&
                                    searchPlm.getGusStatus() == GusStatus.COMPLETED) {
                                    closedListId = searchPlm.getTrelloList().getListName();                      
                                    logger.debug("Setting Gus Card to closed at id: " + closedListId);              
                                }
                            }

                            // update the status
                            gwi.setStatus(GusStatus.COMPLETED.getName());
                            if(closedListId != null) {
                                // Create trello card in closed list
                                createNewTrelloCard(gwi, closedListId);
                            } else {
                                // somehow this trello board doesn't have a closed list. Remove all linking information and update
                                gwi.details = gwi.getDetails();
                                gctx.updateGusWorkItem(gwi);
                            }
                            
                        }
                    } else {
                        // we have a gwi and tc that are associated with each other, update them
                        updateCards(tc, gwi, trelloLinksToGwi);
                    }
                } 
            }

            // Create new GUS work items from trello cards
            logger.debug("Trello Cards not picked up by Gus cards:");
            for (TrelloCard tc: tcs.values()) {
                logger.debug(tc);
                boolean createGusCard = tc.gusId == null;

                if (tc.gusId == null) {
                    // create gus card, update trello card
                    createNewGusCard(tc, plm.getGusProduct().getProductName(), plm.getGusStatus().getName());
                } else {
                    // update gus card with correct metadata
                    GusWorkItem gwi = gctx.getGusWorkItem(tc.gusId);
                    logger.debug("This trello card is associated with: " + gwi);
                    updateCards(tc, gwi);
                }

            }
            logger.debug("Done with PLM");
        }
    }

    /* 
     * Function will create a trello card from a gwi
     */
    private void createNewTrelloCard(GusWorkItem gwi, String trelloListId) {
        try {
            logger.debug("Creating trello card: " + gwi.subject);
            JSONObject newTrelloCard = tctx.createTrelloCard(gwi, trelloListId);
            gwi.updateDetails(newTrelloCard.getString("id"));
            gctx.updateGusWorkItem(gwi);
        } catch (Exception e) {
            logger.error("Caught Exception", e); 
        }
    }

    /*
     * Function will create a gwi from a tc
     */
    private void createNewGusCard(TrelloCard tc, String productTag, String status) {
        try {
            logger.debug("Creating gus card");
            gctx.createGusWorkItem(tc, productTag, status);
            tc.updateDesc();
            tctx.updateTrelloCard(tc);
        } catch (Exception e) {
            logger.error("Caught Exception", e);
        }
    }

    /*
     * will update the gwi handed to it
     */
    private void updateGwi(GusWorkItem gwi) {
        try {
            logger.debug("Updating Gus Work item"); 
            gwi.updateDetails();
            gctx.updateGusWorkItem(gwi);
        } catch (Exception e) {
            logger.error("Caught Exception", e);
        }
    }

    /*
     * will update the tc handed to it
     */
    private void updateTc(TrelloCard tc) {
        try {
            logger.debug("Updating Trello Card");
            tc.updateDesc();
            tctx.updateTrelloCard(tc);
        } catch (Exception e) {
            logger.error("Caught Exception", e);
        }
    }

    private void updateCards(TrelloCard tc, GusWorkItem gwi) {
        updateCards(tc, gwi, false);
    }

    /*
     * given the tc and gwi, make sure they're synced
     */
    private void updateCards(TrelloCard tc, GusWorkItem gwi, boolean trelloLinksToGwi) {
        // check if either card changed
        boolean update = didCardsChange(gwi, tc);
        // If the trello card status changed, need to update the gwi
        boolean gusStatusChanged = gwi.getChangedValuesMap() != null && gwi.getChangedValuesMap().containsKey("Status__c");

        // Nothing other than the status changed or the gwi lost its trello link changed, update gwi only
        if ((gusStatusChanged || trelloLinksToGwi) && !update) {
            logger.debug("Adding trello link to GWI or updating Gus Status: " + gwi);
            updateGwi(gwi);
        // Otherwise update both
        } else if(update) {
            logger.debug("Updating GWI: " + gwi + ", and TC: " + tc);
            updateGwi(gwi);
            updateTc(tc);
        }
    }

    /*
     * Will detect if either gwi or tc changed and update the appropriate cards (not on Gus or Trello yet)
     */
    private boolean didCardsChange(GusWorkItem gwi, TrelloCard tc) {
        boolean[] updates = {false, false};                   

        // check if either gwi or tc changed
        boolean gwiChanged = gwi.isChanged();
        logger.debug("Gus changed: " + gwiChanged + " | " + gwi);
        boolean tcChanged = tc.isChanged();
        logger.debug("Trello changed: " + tcChanged + " | " + tc);

        // if gwi changed and tc didn't, update tc with gwi info
        // TODO: move this logic to the GusWorkItem and TrelloCard instead of here
        if(gwiChanged && !tcChanged) {
            // TODO: sync everything, not just details
            if (!tc.getDesc().equalsIgnoreCase(gwi.getDetails())) {
                tc.setDesc(gwi.getDetails());
            }
            if (!tc.name.equalsIgnoreCase(gwi.subject + (gwi.points.equals("") ? "" : ":" + gwi.points))) {
                tc.name = gwi.subject + (gwi.points.equals("") ? "" : ":" + gwi.points);
            }
            tc.setDesc(gwi.getDetails());
            logger.debug("TC changedValuesMap: " + tc.getChangedValuesMap());
            updates[1] = true;
        }

        // if tc changed and gwi didn't, update gwi with tc info
        if(tcChanged && !gwiChanged) {
            // TODO: sync everything, not just the desc
            gwi.setDetails(tc.getDesc());
            logger.debug("Gwi changedValuesMap: " + gwi.getChangedValuesMap());
            updates[0] = true;
        }

        // TODO: if both changed, add to Error Resolution page asking which one is correct
        // TODO: create Error Resolution page

        // return if any changes were made
        return gwiChanged || tcChanged;
    }

    /*
     * Filter process: we grab everything, then filter out by keyword, and then filter back in from the filtered outs. 
     * Can easily flip this behavior if filter out keyword is .* regex (all kewords are regexes)
     */
    private void filterWorkItems(Map<String, GusWorkItem> gwis, ProductListMapping plm) {
        List<FilterSet> filters = plm.getFilters();
        List<String> filtOut = new ArrayList<String>();
        FilterSet gusFilterOut = null;
        FilterSet gusFilterIn = null;

        // Grab filtersets for filtering in/out and Gus
        for (FilterSet fs : filters) {
            if (fs.getFilterRuleType() == FilterRuleType.EXPORT && fs.getFilterSource() == FilterSource.GUS) gusFilterOut = fs;
            if (fs.getFilterRuleType() == FilterRuleType.IMPORT && fs.getFilterSource() == FilterSource.GUS) gusFilterIn = fs;
        }

        // filter out
        if (gusFilterOut != null) {
            for (FilterItem fi : gusFilterOut.getFilterItems()) {
                for (String id : gwis.keySet()) {
                    if(!gwis.get(id).filter(fi.getKeyword(), false)) {
                        logger.debug("for keyword " + fi.getKeyword() + ", filtering out " + gwis.get(id));
                        filtOut.add(id);
                    }
                }
            }
        }

        // filter back in after filter out
        if (gusFilterIn != null) {
            for (FilterItem fi : gusFilterIn.getFilterItems()) {
                logger.debug("Filtering in keyword " + fi.getKeyword());
                for (int i = filtOut.size() - 1; i > -1; --i) {
                    logger.debug("looking at card: " + gwis.get(filtOut.get(i)));
                    if(gwis.get(filtOut.get(i)).filter(fi.getKeyword(), true)) {
                        logger.debug("filtering in");
                        filtOut.remove(i);
                    } else {
                        logger.debug("Keeping out");
                    }
                }
            }
        }

        // remove the ones that need to be removed
        // TODO: Don't actually remove altogether, maybe save off somewhere else
        for (String id : filtOut) {
            gwis.remove(id);
        }
    }

    /* 
     * Filter process: we grab everything, then filter out by keyword, and then filter back in from the filtered outs. 
     * Can easily flip this behavior if filter out keyword is .* regex (all kewords are regexes)
     */
    private void filterCards(Map<String, TrelloCard> tcs, ProductListMapping plm) {
        List<FilterSet> filters = plm.getFilters();
        List<String> filtOut = new ArrayList<String>();
        FilterSet tcFilterOut = null;
        FilterSet tcFilterIn = null;

        // Grab filtersets for filtering in/out and Gus
        for (FilterSet fs : filters) {
            if (fs.getFilterRuleType() == FilterRuleType.EXPORT && fs.getFilterSource() == FilterSource.TRELLO) tcFilterOut = fs;
            if (fs.getFilterRuleType() == FilterRuleType.IMPORT && fs.getFilterSource() == FilterSource.TRELLO) tcFilterIn = fs;
        }

        // filter out
        if (tcFilterOut != null) {
            for (FilterItem fi : tcFilterOut.getFilterItems()) {
                for (String id : tcs.keySet()) {
                    if(!tcs.get(id).filter(fi.getKeyword(), false)) {
                        logger.debug("for keyword " + fi.getKeyword() + ", filtering out " + tcs.get(id));
                        filtOut.add(id);
                    }
                }
            }
        }

        // filter in
        if (tcFilterIn != null) {
            for (FilterItem fi : tcFilterIn.getFilterItems()) {
                logger.debug("Filtering in keyword " + fi.getKeyword());
                for (int i = filtOut.size() - 1; i > -1; --i) {
                    logger.debug("looking at card: " + tcs.get(filtOut.get(i)));
                    if(tcs.get(filtOut.get(i)).filter(fi.getKeyword(), true)) {
                        logger.debug("filtering in");
                        filtOut.remove(i);
                    } else {
                        logger.debug("Keeping out");
                    }
                }
            }
        }

        // remove the ones that need to be removed
        // TODO: Don't actually remove altogether, maybe save off somewhere else
        for (String id : filtOut) {
            tcs.remove(id);
        }
    }
}
