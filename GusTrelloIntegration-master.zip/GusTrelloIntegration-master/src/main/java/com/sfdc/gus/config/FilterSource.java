package com.sfdc.gus.config;

public enum FilterSource {
    GUS,
    TRELLO
}
