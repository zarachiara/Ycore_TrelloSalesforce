package com.sfdc.gus.config;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.OneToOne;
import javax.persistence.OneToMany;
import javax.persistence.ManyToOne;
import javax.persistence.JoinColumn;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.HashCodeBuilder;

@Entity
@Table(name="extrateamassociation", schema="configuration")
public class ExtraTeamAssociation {

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private long extraTeamAssociationId;
    public long getExtraTeamAssociationId() { return extraTeamAssociationId; }
    // public void setExtraTeamAssociationId(long id) { extraTeamAssociationId = id; }

    @ManyToOne
    @JoinColumn(name="gusteamid")
    private GusTeam gusTeam;
    public GusTeam getGusTeam() { return gusTeam; }
    // public void setGusTeam(GusTeam gusTeam) { this.gusTeam = gusTeam; }

    @ManyToOne
    @JoinColumn(name="projectconfigid")
    private ProjectConfig projectConfig;
    public ProjectConfig getProjectConfig() { return projectConfig; }
    // public void setProjectConfig(ProjectConfig projectConfig) { this.projectConfig = projectConfig; }

    public ExtraTeamAssociation() {}
    public ExtraTeamAssociation(ProjectConfig projectConfig, GusTeam gusTeam) {
        this.gusTeam = gusTeam;
        this.projectConfig = projectConfig;
    }
}
