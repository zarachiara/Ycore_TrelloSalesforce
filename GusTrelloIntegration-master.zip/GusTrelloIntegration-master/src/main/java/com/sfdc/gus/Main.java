package com.sfdc.gus;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Properties;

import java.security.KeyPair;
import java.security.Security;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;

import org.apache.log4j.Logger;

import org.hibernate.cfg.Configuration;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.service.ServiceRegistry;

import com.sfdc.gus.config.DatabaseHelper;
import com.sfdc.gus.config.ProjectConfig;

import com.sfdc.gus.security.AESDualCrypt;

/**
 * Launcher for all the functionality of the project. In general, there are 2 things it can do:
 * 1. Start up the web server and synchronization
 * 2. Generate code coverage
 *
 * Code coverage is launched here due to difficulty with lein-junit and the jacoco maven plugin
 * having to execution from leiningen.
 */
public class Main {
    private static Logger logger = Logger.getLogger(Main.class);

    /**
     * This top-level entry-point sets up the session factory, delegates down,
     * then makes sure it gets closed at the end, and then exits gracefully.
     */
    public static void main(String[] args) {

        // Setup hibernate session factory.
        SessionFactory sessionFactory;
        Configuration hbcfg = new Configuration()
                    .configure(); // configures settings from hibernate.cfg.xml

        // When messing around with resource paths, I came across lots of resistance.
        // To validate that this is not being started with a database meant for the
        // junit tests, a check on the URL is done. At any time in the future, this
        // can be deleted, and it shouldn't cause any problems. Just keep the else.
        // Since I'm still unsure about how the resource paths get added to jars,
        // I'm leaving this for safety.
        if (hbcfg.getProperty("hibernate.connection.url").contains("test")) {
            System.err.println("Testing resources are ONLY to be used for junit testing. Environment is NOT setup correctly. Exiting");
            return;
        } else {
            ServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder().applySettings(hbcfg.getProperties()).build();
            sessionFactory = hbcfg.buildSessionFactory(serviceRegistry);
        }

        main(sessionFactory, args);

        // Close the session factory once all operations are complete
        logger.info("Session factory is closing");
        sessionFactory.close();
    }

    // Main function that's the same as before, except a SessionFactory is not created; we already have it.
    public static void main(SessionFactory sessionFactory, String[] args) {
        // We can only close BufferedReader(STDIN) once. The moment it closes, STDIN closes
        // as well, so only get this one. Anything that needs stdin should use this object
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));

        if (args.length == 0) {
            printUsage();

        } else if (args[0].equals("coverage")) {
            // Generate a coverage report based on the "current directory"
            String[] reportargs = new String[] {
                "." };
            try {
                ReportGenerator.main(reportargs);
            } catch (IOException ioe) {
                ioe.printStackTrace();
                System.err.println("Could not create coverage report");
            }

        } else if (args[0].equals("web")) {
            DatabaseHelper db = new DatabaseHelper(sessionFactory);
            AESDualCrypt crypter = setupEncryption(input, db);

            if (crypter == null) {
                // Encryption setup is expected to output an appropriate error message
                return;
            }

            setUpGlobal("appkey", input, db, crypter);
            setUpGlobal("client_id", input, db, crypter);
            setUpGlobal("client_secret", input, db, crypter);

            IntegrationFrontEnd ife = new IntegrationFrontEnd(sessionFactory, crypter);
            ife.run();

            // commandline repl to issue server commands
            // stop: stop server
            String command = null;
            while ((command = readLinePrompt(input, "> ")) != null && !command.equals("stop")) {
                // TODO: Polishing this interface and adding some useful functions would be nice,
                // but is not in any way a requirement for the project

                // Java 7 added switch(String). This is somewhere between gross and helpful
                switch (command) {
                    default:
                        System.out.println("Unknown command");
                }
            }

            // Kindly stop the server
            ife.stop();


        } else {
            printUsage();
        }

        try {
            input.close();
        } catch (IOException e) { logger.error("Problem closing STDIN", e); }
    }

    public static void printUsage() {
        System.out.println("Usage: <trellointegration> <command>");
        System.out.println("");
        System.out.println("Commands:");
        System.out.println("");
        System.out.println("\tweb");
        System.out.println("\t\tStart actively trying to sync trello with GUS, with a web front-end for configuration");
        System.out.println("");
        System.out.println("While the web server is running, a REPL is present (even if it get mangled over by output). Here are the supported commands: ");
        System.out.println("");
        System.out.println("\tstop");
        System.out.println("\t\tNicely stop the web server and stop all the threads by letting their execution run out.");
    }

    /**
     * Read in the passphrase, test it against the database by trying to decrypt a known entity,
     * and validate the passphrase pending the correct decryption. If there is no known decryption
     * entity in the database, that indicates it's the first startup of the application,
     * and a passphrase needs to be setup, so it prompts for the new passphrase.
     *
     * @return Encryption object imbued with a correct passphrase. null upon any failures
     */
    private static AESDualCrypt setupEncryption(BufferedReader input, DatabaseHelper db) {
        AESDualCrypt crypter = null;

        // An encrypted string in the DB is decrypted to test passphrase correctness
        String decryptTester = db.getGlobalProperty("passphrasetester");
        if (decryptTester == null) {
            System.out.println("This looks to be a first-time startup. Let's setup your encryption passphrase.");
            System.out.println("Please enter a passphrase to be used for AES-128 encryption. This passphrase will "
                    + "need to be entered each time this application starts up, which hopefully will only be once.");

            String newPassphrase = null;
            while (newPassphrase == null) {
                newPassphrase = readLinePrompt(input, "new passphrase: ");
                String verify = readLinePrompt(input, "verify passphrase: ");
                if (! newPassphrase.equals(verify)) {
                    newPassphrase = null;
                    System.out.println("Passphrase and verification were not the same. Please enter again");
                    System.out.println("");
                }
            }
            AESDualCrypt tempcrypter = new AESDualCrypt(newPassphrase);

            // Insert a new tester, since this must be the first startup ever
            db.setGlobalProperty("passphrasetester", tempcrypter.encrypt("passphrasetester"));
            decryptTester = db.getGlobalProperty("passphrasetester");
            System.out.println("Passphrase set. Please continue with your new passphrase");
        }

        // Initialize the encryption engine with a passphrase
        String passphrase = readLinePrompt(input, "Encryption Passphrase? ");
        crypter = new AESDualCrypt(passphrase);

        // NOTE: Due to the nature of encryption, if this passphrase is ever lost,
        // all data that was previously encrypted will be useless, and UNRECOVERABLE.
        // Additionally, changing the passphrase requires the old passphrase. Since
        // everything must be decrypted w/ old, then re-encrypted with the new passphrase,
        // passphrase resets are IMPOSSIBLE. No effort was put into simply changing the passphrase
        if (! "passphrasetester".equals(crypter.decrypt(decryptTester))) {
            System.err.println("Passphrase incorrect. Exiting");
            crypter = null;
        }

        return crypter;
    }

    /**
     * Generic function to bootstrap specific required values. Namely, trello API key,
     * GUS connected app consumer key, and connected app secret key.
     */
    private static void setUpGlobal(String key, BufferedReader in, DatabaseHelper db, AESDualCrypt crypter) {
        String dbVal = db.getGlobalProperty(key);

        // Not having a value in the database indicates that the value is unset.
        if(dbVal == null) {
            System.out.println("Value for " + key + " is requested for future runs.");

            String val = null;
            while (val == null) {
                val = readLinePrompt(in, "New " + key + ": ");
                String verify = readLinePrompt(in, "Verify " + key + ": ");
                if(!val.equals(verify)) {
                    val = null;
                    System.out.println("No match, please try again");
                    System.out.println("");
                }
            }
            db.setGlobalProperty(key, crypter.encrypt(val));
            dbVal = db.getGlobalProperty(key);
        }
    }

    /**
     * Shortcut for prompting for a value. It simply prints without a newline at the end,
     * then returns the next readLine().
     */
    public static String readLinePrompt(BufferedReader br, String prompt) {
        try {
            System.out.print(prompt);
            return br.readLine();
        } catch (IOException ioe) {
            ioe.printStackTrace();
            return null;
        }
    }
}
