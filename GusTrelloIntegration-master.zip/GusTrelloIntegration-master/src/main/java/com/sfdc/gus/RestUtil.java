package com.sfdc.gus;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.Map;

import org.apache.log4j.Logger;

import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpResponseException;
import org.apache.http.HttpResponse;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.methods.HttpEntityEnclosingRequestBase;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPatch;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.sfdc.gus.util.TextUtil;
import com.sfdc.gus.http.Utf8ResponseHandler;
import com.sforce.soap.enterprise.EnterpriseConnection;
import com.sforce.ws.ConnectionException;
import com.sforce.ws.ConnectorConfig;


public class RestUtil {

    private static final Logger logger = Logger.getLogger(RestUtil.class);

    /*
     * Enum of the various HTTP methods that are used for the Update Object method
     */
	public enum HttpUpdateMethod {
		HTTP_POST(HttpPost.class),
		HTTP_PUT(HttpPut.class),
		HTTP_PATCH(HttpPatch.class);
		
		@SuppressWarnings("rawtypes")
		private Class httpClientMethod;
		
		@SuppressWarnings("rawtypes")
		private HttpUpdateMethod(Class httpClientMethod) {
			this.httpClientMethod = httpClientMethod;
		}
		
		@SuppressWarnings("unchecked")
		public HttpEntityEnclosingRequestBase newInstance(String url) throws SecurityException, NoSuchMethodException, IllegalArgumentException, InstantiationException, IllegalAccessException, InvocationTargetException {
			Constructor<HttpEntityEnclosingRequestBase> ctor = this.httpClientMethod.getConstructor(String.class);
			return ctor.newInstance(url);
		}
	}
	
	/**
     * Provided a url and headers, return a JSONObject of whatever JSON is returned from this endpoint
     */
    public static JSONObject getObject(String url, Map<String, String> headers) throws ClientProtocolException, IOException, JSONException {
        CloseableHttpClient httpClient = HttpClientBuilder.create().build();;
        try {
            logger.debug("URL: " + url);
            logger.debug("Headers: " + headers);
            //logger.debug("URL: " + url);
            HttpGet get = new HttpGet(url);
            ResponseHandler<String> handler = new Utf8ResponseHandler();
            get.setHeader("Content-Type", "application/json; charset=utf-8");
            if (headers != null && headers.size() > 0) {
                for(String header : headers.keySet()) {
                    get.setHeader(header, headers.get(header));
                }
            }
            String response = httpClient.execute(get, handler).replace("\r","").replace("\\r","");
            logger.debug("response: " + response);
            //logger.debug("RestUtil response: " + response);
            return new JSONObject(response);
        } finally {
            httpClient.close();
        }
    }


    /*
     * will send a request to provided url to update an object. Used by the GusContext. Request body looks like JSON
     */
    public static boolean updateObject(String url, Map<String, String> headers, Map<String, String> body, HttpUpdateMethod httpMethod) throws ClientProtocolException, IOException, JSONException {

        logger.debug("URL: " + url);
        logger.debug("Headers: " + headers);
        logger.debug("Body: " + body);
        logger.debug("Method: " + httpMethod.name());


        CloseableHttpClient httpClient = HttpClientBuilder.create().build();
        boolean success = true;
        try {
            HttpEntityEnclosingRequestBase update = httpMethod.newInstance(url);
            update.setHeader("Content-Type", "application/json; charset=utf-8");
            if (headers != null && headers.size() > 0) {
                for(String header : headers.keySet()) {
                    update.setHeader(header, headers.get(header));
                }
            }

            // if the body isn't null, send it in the request
            JSONObject requestBody = new JSONObject();
            if (body != null && body.size() > 0) {
                for(String bodyKey : body.keySet()) {
                    requestBody.put(bodyKey, body.get(bodyKey));
                }
            }

            // Set the body of the request
            StringEntity entity = new StringEntity(requestBody.toString());
            update.setEntity(entity);

            // execute request
            BasicResponseHandler handler = new BasicResponseHandler();
            httpClient.execute(update, handler);
        } catch(Exception ex) {
            // if exception occurs, request failed (status code 400, 404, anything not 2xx)
            logger.debug("Update failed due to: " + ex.getMessage());
            ex.printStackTrace();
            success = false;
        } finally {
            httpClient.close();
        }
        return success;
    }

    /**
     * return a jsonarray of the array returned by url. Used primarily by TrelloContext. Makes a get request
     */
    public static JSONArray getList(String url, Map<String, String> headers) throws IOException, JSONException {

        logger.debug("URL: " + url);
        logger.debug("Headers: " + headers);

        CloseableHttpClient httpClient = HttpClientBuilder.create().build();
        try {
            HttpGet get = new HttpGet(url);
            if (headers != null && headers.size() > 0) {
                for(String header : headers.keySet()) {
                    get.setHeader(header, headers.get(header));
                }
            }
            ResponseHandler<String> handler = new Utf8ResponseHandler();
            String response = httpClient.execute(get, handler).replace("\r","").replace("\\r","");
            logger.debug("Response: " + response);
            return new JSONArray(response);
        } finally {
            httpClient.close();
        }
    }

    /**
     * get a jsonobject of the json returned by url. Makes a get request.
     */
    public static JSONObject queryObjects(String queryUrl, Map<String, String> headers) throws ClientProtocolException, IOException, JSONException {
        CloseableHttpClient httpClient = HttpClientBuilder.create().build();

        logger.debug("URL: " + queryUrl);
        logger.debug("Headers: " + headers);
        
        try {
            HttpGet get = new HttpGet(queryUrl);
            if (headers != null && headers.size() > 0) {
	        	for(String header : headers.keySet()) {
	        		get.setHeader(header, headers.get(header));
	        	}
	        }
            BasicResponseHandler handler = new BasicResponseHandler();
            String response = httpClient.execute(get, handler).replace("\r","").replace("\\r","");
            logger.debug("Response: " + response);
            return new JSONObject(response);
        } finally {
            httpClient.close();
        }
    }
    
    /**
     * Makes a post request to the createUrl. POST body looks like JSON
     */
    public static JSONObject createObject(String createUrl, Map<String,String> headers, Map<String,String> keyValuePairs) throws ClientProtocolException, IOException, JSONException {
        CloseableHttpClient httpClient = HttpClientBuilder.create().build();
        logger.debug("createUrl: " + createUrl);
        logger.debug("Headers: " + headers);
        logger.debug("params: " + keyValuePairs);
        try {
            HttpPost post = new HttpPost(createUrl);
            if (headers != null && headers.size() > 0) {
	        	for(String header : headers.keySet()) {
	        		post.setHeader(header, headers.get(header));
	        	}
	        }
            JSONObject requestBody = new JSONObject();
            for(String key : keyValuePairs.keySet()) {
                requestBody.put(key, keyValuePairs.get(key));            	
            }
        
            StringEntity entity = new StringEntity(requestBody.toString());
            post.setEntity(entity);

            BasicResponseHandler handler = new BasicResponseHandler();
            HttpResponse response = httpClient.execute(post);
            logger.debug("Response: " + response);
            InputStream is = response.getEntity().getContent();
            java.util.Scanner s = new java.util.Scanner(is).useDelimiter("\\A");
            String str = s.hasNext() ? s.next() : "''";
            logger.debug("Body: " + str);
            return new JSONObject(str);
        } finally {
            httpClient.close();
        }
    }    

    /**
     * Make a simple post to the provided url. Used for OAuth. POST body looks like a url query string (key1=value1&key2=value2&...)
     */
    public static JSONObject simplePost(String url, Map<String, String> headers, Map<String, String> params) throws ClientProtocolException, IOException, JSONException {
        CloseableHttpClient httpClient = HttpClientBuilder.create().build();
        logger.debug("url: " + url);
        logger.debug("Headers: " + headers);
        logger.debug("params: " + params);
        try {
            HttpPost post = new HttpPost(url);
            if (headers != null && headers.size() > 0) {
                for(String header : headers.keySet()) {
                    post.setHeader(header, headers.get(header));
                }
            }
            String body = "";
            for(String key : params.keySet()) {
                body += (body.length() == 0 ? "" : "&") + key + "=" + params.get(key);
            }
            StringEntity entity = new StringEntity(body);
            post.setEntity(entity);

            BasicResponseHandler handler = new BasicResponseHandler();
            HttpResponse response = httpClient.execute(post);
            logger.debug("Response: " + response);
            InputStream is = response.getEntity().getContent();
            java.util.Scanner s = new java.util.Scanner(is).useDelimiter("\\A");
            String str = s.hasNext() ? s.next() : "''";
            logger.debug("Body: " + str);
            return new JSONObject(str);
        } finally {
            httpClient.close();
        }
    }

    /**
     * Makes a simple get request to the provided url. 
     */
    public static JSONObject simpleGet(String url, Map<String, String> headers) throws ClientProtocolException, IOException, JSONException {
        CloseableHttpClient httpClient = HttpClientBuilder.create().build();

        logger.debug("URL: " + url);
        logger.debug("Headers: " + headers);
        
        try {
            HttpGet get = new HttpGet(url);
            if (headers != null && headers.size() > 0) {
                for(String header : headers.keySet()) {
                    get.setHeader(header, headers.get(header));
                }
            }
            BasicResponseHandler handler = new BasicResponseHandler();
            String response = httpClient.execute(get, handler).replace("\r","").replace("\\r","");
            logger.debug("Response: " + response);
            return new JSONObject(response);
        } finally {
            httpClient.close();
        }
    }
    
    /**
     * Attempts to log into the provied authEndPoint using SOAP. Used exclusively by the GusContext
     */
    public static EnterpriseConnection soapLogin(String authEndPoint, String username, String password, String[] outParams) throws ConnectionException {
        ConnectorConfig config = new ConnectorConfig();
        config.setUsername(username);
        config.setPassword(password);
        config.setAuthEndpoint(authEndPoint);
        EnterpriseConnection conn = new EnterpriseConnection(config);
        outParams[0] = config.getSessionId();
        outParams[1] = conn.getUserInfo().getUserId();
        return conn;
    }
    
    /*
     * Encodes the provided string with the html entity codes
     */
    public static String RestEncode(String value) {
    	return value.replace(" ", "%20").replace("\r\n", "%0a").replace("\n","%0a");
    }
}
