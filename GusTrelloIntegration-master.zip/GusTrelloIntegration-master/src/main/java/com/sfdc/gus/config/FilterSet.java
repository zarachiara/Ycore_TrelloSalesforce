package com.sfdc.gus.config;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.OneToMany;
import javax.persistence.ManyToOne;
import javax.persistence.FetchType;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.HashCodeBuilder;

@Entity
@Table(name="filterset", schema="configuration")
public class FilterSet {

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private long filterSetId;
    public long getFilterSetId() { return filterSetId; }

    private FilterRuleType ruleType;
    public FilterRuleType getFilterRuleType() { return ruleType; }

    private FilterSource source;
    public FilterSource getFilterSource() { return source; }

    @OneToMany(mappedBy="filterSet", fetch=FetchType.EAGER)
    private Set<FilterItem> filterItems;
    public Set<FilterItem> getFilterItems() { return filterItems; }

    @ManyToOne
    @JoinColumn(name="productlistmappingid")
    private ProductListMapping productListMapping;
    public ProductListMapping getProductListMapping() { return productListMapping; }

    public FilterSet() {}

    public FilterSet(FilterRuleType ruleType, FilterSource filterSource, ProductListMapping plm) {
        this.ruleType = ruleType;
        this.source = filterSource;
        this.productListMapping = plm;
    }

    @Override
    public String toString() {
        return "<filterset "
            + "id=" + filterSetId + " "
            + "ruletype=" + ruleType + " "
            + "rulesource=" + source + " "
            + ">";
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder()
            .append(filterSetId)
            .append(ruleType)
            .append(source)
            .toHashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) { return false; }
        if (obj == this) { return true; }
        if (obj.getClass() != getClass()) {
            return false;
        }
        FilterSet tlobj = (FilterSet) obj;
        return tlobj.getFilterSetId() == filterSetId
            && tlobj.getFilterRuleType() == ruleType
            && tlobj.getFilterSource() == source;
    }
}
