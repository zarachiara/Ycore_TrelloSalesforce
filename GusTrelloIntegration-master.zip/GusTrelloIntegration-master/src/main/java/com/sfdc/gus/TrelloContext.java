package com.sfdc.gus;

import java.io.IOException;
import java.io.InputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Map;
import java.util.TimerTask;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.apache.log4j.Logger;

import org.apache.http.client.ClientProtocolException;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.boot.registry.classloading.spi.ClassLoaderService;

import com.sfdc.gus.config.ProjectConfig;
import com.sfdc.gus.config.TrelloLogin;
import com.sfdc.gus.security.AESDualCrypt;
import com.sforce.ws.ConnectionException;

public class TrelloContext {

    public TrelloLogin config;
    private String userId;
    private String trelloAPIKey;
    private List<Map> trelloInfo;
    private Map<String, String> headers = null;
    private AESDualCrypt crypter;

    private static Logger logger = Logger.getLogger(TrelloContext.class);

    public static final String TRELLO_SERVER; 
    /*
     * We use the default URL for trello unless we find an endpoint.properties file (found in resources dir) that specifies a different endpoint.
     * This is how we handle testing (we use a MockGus found under the testHelpers under test dir).
     */  
    static {
        String defaultURL = "https://api.trello.com/1";
        String chosenURL;
        try {
            Properties endpointProps = new Properties();

            InputStream endpointStream = null;

            try {
                endpointStream = new StandardServiceRegistryBuilder()
                    .getBootstrapServiceRegistry()
                    .getService(ClassLoaderService.class)
                    .locateResourceStream("endpoint.properties");
            } catch (Exception e) { System.out.println("Cannot find endpoint.properties using Hibernate ClassLoader"); }

            if (endpointStream == null) {
                // Neither URL lookup nor using hibernate's class/resource loader worked.
                // At this point, things have failed horribly, and there's probably no way
                // we'll be able to find the file ever. Try to load it, resulting in a
                // nearly-guaranteed FileNotFoundException
                endpointProps.load(new FileInputStream("endpoint.properties"));
            }

            endpointProps.load(endpointStream);
            chosenURL = endpointProps.getProperty("trello.url", defaultURL);
            logger.debug("endpoint.properties load successful. Loaded URL: " + chosenURL);
        } catch (FileNotFoundException e) {
            logger.debug("endpoint.properties could not be found. Using the default Trello URL: " + defaultURL);
            chosenURL = defaultURL;
        } catch (IOException e) {
            e.printStackTrace();
            chosenURL = defaultURL;
        }
        TRELLO_SERVER = chosenURL;
    }

    /*
     * Constructor
     */
    public TrelloContext(TrelloLogin config, String trelloAPIKey, AESDualCrypt crypter) {
        this.config = config;
        this.trelloAPIKey = trelloAPIKey;
        this.crypter = crypter;

        headers = new HashMap<String, String>();
        headers.put("Content-Type", "application/json; charset=utf-8");
    }
    
    /*
     * Get this users information (such as id). Good test to see if we're connected to trello
     */
    public void getMe() throws ClientProtocolException, IOException, JSONException {
        JSONObject me = RestUtil.getObject(TRELLO_SERVER + "/members/me?" + getTrelloAccessQuery(), headers);
        userId = me.getString("id");
    }

    /*
     * Get boards for this user
     */
    public JSONArray getMyBoards() throws ClientProtocolException, IOException, JSONException {
        return RestUtil.getList(TRELLO_SERVER + "/members/my/boards?" + getTrelloAccessQuery(), headers);
    }
    
    /*
     * Get lists for the provided boardId
     */
    public JSONArray getLists(String boardId) throws ClientProtocolException, IOException, JSONException {
        return RestUtil.getList(TRELLO_SERVER + "/boards/" + boardId + "/lists?" + getTrelloAccessQuery(), headers);
    }

    /*
     * Get the cards for the provided listId. Return a map of card ids to the cards themselves
     */
    public Map<String, TrelloCard> getCards(String listId) throws ClientProtocolException, IOException, JSONException {
        JSONArray cards = RestUtil.getList(TRELLO_SERVER + "/lists/" + listId + "/cards?" + getTrelloAccessQuery(), headers);
        Map<String, TrelloCard> tcs = new HashMap<String, TrelloCard>();
        for (int i = 0; i < cards.length(); ++i) {
            TrelloCard tc = new TrelloCard(cards.getJSONObject(i));
            tcs.put(tc.id, tc);
        }
        return tcs;
    }

    /*
     * Get all cards for this user and provided listId. Return a map of card ids to the cards themselves
     */
    public Map<String, TrelloCard> getMyCards(String listId) throws ClientProtocolException, IOException, JSONException {
        JSONArray cards = RestUtil.getList(TRELLO_SERVER + "/lists/" + listId + "/cards?actions=createCard&" + getTrelloAccessQuery(), headers);
        Map<String, TrelloCard> tcs = new HashMap<String, TrelloCard>();
        logger.debug("Received " + cards.length() + " trello cards, grabbing those owned by " + userId);
        // Filter out cards with an idMemberCreator field different that this user's id
        for (int i = 0; i < cards.length(); ++i) {
            if (cards.getJSONObject(i).getJSONArray("actions").getJSONObject(0).getString("idMemberCreator").equals(userId)) {
                TrelloCard tc = new TrelloCard(cards.getJSONObject(i));
                tcs.put(tc.id, tc);
            }
        }
        return tcs;
    }

    /*
     * Get the card with the provided card Id
     */
    public TrelloCard getCard(String cardId) throws ClientProtocolException, IOException, JSONException {
        JSONObject card = RestUtil.getObject(TRELLO_SERVER + "/cards/" +
             cardId + "?fields=name,desc&actions=createCard&" + getTrelloAccessQuery(), headers);
        return new TrelloCard(card);
    }

    public String getUserId() {
        return userId;
    }

    /*
     * Get all trello boards that are not closed
     */
    public List<String> getOpenBoards() throws ClientProtocolException, IOException, JSONException {
        JSONArray json = getMyBoards();
        logger.debug(json);
        List<String> arr = new ArrayList<String>();
        for(int i = 0; i < json.length(); ++i) {
            if(!json.getJSONObject(i).getBoolean("closed")) {
                arr.add(json.getJSONObject(i).getString("name"));
            }
        }
        return arr;
    }

    /*
     * re-get all trello boards and lists
     */
    public void refreshTrelloInfo() throws ClientProtocolException, JSONException, IOException {
        trelloInfo = null;
        getTrelloInfo();
    }

    /*
     * Get the name and id for all of the trello boards and trello lists this user is a part of
     */
    public List<Map> getTrelloInfo() throws ClientProtocolException, JSONException, IOException {
        if(trelloInfo == null) {
            trelloInfo = new ArrayList<Map>();
            JSONArray json = getMyBoards();
            // iterate through all of the boards
            for(int i = 0; i < json.length(); ++i) {
                if(json.getJSONObject(i).getBoolean("closed")) continue;
                Map board = new HashMap();
                board.put("Id",json.getJSONObject(i).getString("id"));
                board.put("Name",json.getJSONObject(i).getString("name"));

                // Iterate through all of the lists for this board
                List<Map> lsts = new ArrayList<Map>();
                JSONArray lists = getLists((String)board.get("Id"));
                for (int j = 0; j < lists.length(); ++j) {
                    Map l = new HashMap();
                    JSONObject list = lists.getJSONObject(j);
                    l.put("Name",list.getString("name"));
                    l.put("Id",list.getString("id"));
                    lsts.add(l);
                }
                board.put("lists",lsts);
                trelloInfo.add(board);
            }
        }
        return trelloInfo;
    }

    /*
     * Return all of the lists compiled from the trelloInfo object
     */
    public List<Map> getLists() throws ClientProtocolException, JSONException, IOException {
        List<Map> lists = new ArrayList<Map>();
        getTrelloInfo();
        for(Map board : trelloInfo) {
            lists.addAll((List<Map>)board.get("lists"));
        }
        return lists;
    }

    /*
     * Return the key=...&token=... part of the REST query string
     */
    public String getTrelloAccessQuery() {
        return "key=" + crypter.decrypt(trelloAPIKey) + "&token=" + crypter.decrypt(config.getAccessToken());
    }

    /*
     * Create a trello card from this gus work item
     */
    public JSONObject createTrelloCard(GusWorkItem gwi, String trelloListId) throws ClientProtocolException, JSONException, IOException {
        TrelloCard tc = new TrelloCard(gwi);
        return RestUtil.createObject(TRELLO_SERVER + "/lists/" + trelloListId + "/cards?" + 
            getTrelloAccessQuery() + 
            "&idList=" + trelloListId +
            RestUtil.RestEncode(tc.getCreateQuery()),
            null, headers);
    }

    /*
     * Provided a trello card, update the fields as necessary
     */
    public void updateTrelloCard(TrelloCard tc) throws ClientProtocolException, IOException, JSONException {
        Map<String, String> fields = tc.getChangedValuesMap();

        // if fields is null, it means the gus card was changed to be exactly like the trello card by someone else. No need to update ourselves.
        if(fields == null) {
            logger.debug("updateTrelloCard is returning, nothing to do");
            return;
        }

        // iterate through the fields that changed and update them on trello
        for(String field : fields.keySet()) {
            if(field.equals("name")) {
                RestUtil.updateObject(TRELLO_SERVER + "/cards/" + tc.id + "/name?" + getTrelloAccessQuery() +
                    "&value=" + RestUtil.RestEncode(tc.name), 
                    headers, null, RestUtil.HttpUpdateMethod.HTTP_PUT);
            }

            if(field.equals("desc")) {
                RestUtil.updateObject(TRELLO_SERVER + "/cards/" + tc.id + "/desc?" + getTrelloAccessQuery() + 
                    "&value=" + RestUtil.RestEncode(tc.desc), 
                    headers, null, RestUtil.HttpUpdateMethod.HTTP_PUT);
            }
        }
    }
}
