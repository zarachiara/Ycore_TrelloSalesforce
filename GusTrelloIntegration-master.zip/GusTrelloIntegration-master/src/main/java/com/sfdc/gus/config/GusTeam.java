package com.sfdc.gus.config;

import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.HashCodeBuilder;

@Entity
@Table(name="gusteam", schema="configuration")
public class GusTeam {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private long gusTeamId;
    public long getGusTeamId() { return gusTeamId; }

    private String teamName;
    public String getTeamName() { return teamName; }

    @OneToMany(mappedBy="gusTeam", fetch=FetchType.EAGER)
    private Set<GusProduct> gusProducts = null;
    public  Set<GusProduct> getGusProducts() { return gusProducts; }
    // public void setGusProducts(Set<GusProduct> gusProducts) { this.gusProducts = gusProducts; }

    public GusTeam() {}
    public GusTeam(String teamName) {
        // An ID is used internally (in DatabaseHelper sync functions) as an indication that the ID remains to be set
        this.gusTeamId = -1;
        this.teamName = teamName;
    }

    @Override
    public String toString() {
        return "<gusteam "
            + "id=" + gusTeamId + " "
            + "teamname=" + teamName + " "
            + ">";
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder()
            .append(gusTeamId)
            .append(teamName)
            .toHashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) { return false; }
        if (obj == this) { return true; }
        if (obj.getClass() != getClass()) {
            return false;
        }
        GusTeam tlobj = (GusTeam) obj;
        return tlobj.getGusTeamId() == gusTeamId
            && tlobj.getTeamName().equals(teamName);
    }
}
