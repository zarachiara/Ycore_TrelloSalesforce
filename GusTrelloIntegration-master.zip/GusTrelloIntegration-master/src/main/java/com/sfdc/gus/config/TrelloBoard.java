package com.sfdc.gus.config;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Timer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.HashCodeBuilder;

@Entity
@Table(name="trelloboard", schema="configuration")
public class TrelloBoard {

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private long trelloBoardId;
    public long getTrelloBoardId() { return trelloBoardId; }
    // public void setTrelloBoardId(long id) { trelloBoardId = id; }

    private String boardName;
    public String getBoardName() { return boardName; }

    @OneToMany(mappedBy="trelloBoard", fetch=FetchType.EAGER)
    private List<TrelloList> trelloList;
    public List<TrelloList> getTrelloLists() { return trelloList; }
    // public void setTrelloLists(List<TrelloList> blms) { trelloList = blms; }

    public TrelloBoard() {}
    public TrelloBoard(String boardName) {
        this.boardName = boardName;
        this.trelloList = new ArrayList<TrelloList>();
    }

    @Override
    public String toString() {
        return "<trelloboard "
            + "id=" + trelloBoardId + " "
            + "boardname=" + boardName + " "
            + ">";
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder()
            .append(trelloBoardId)
            .append(boardName)
            .toHashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) { return false; }
        if (obj == this) { return true; }
        if (obj.getClass() != getClass()) {
            return false;
        }
        TrelloBoard tlobj = (TrelloBoard) obj;
        return tlobj.getTrelloBoardId() == trelloBoardId
            && tlobj.getBoardName().equals(boardName);
    }
}
