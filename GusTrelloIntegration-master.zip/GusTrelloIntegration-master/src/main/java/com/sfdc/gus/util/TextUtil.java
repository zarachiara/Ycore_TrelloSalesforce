package com.sfdc.gus.util;

import java.security.MessageDigest;

public class TextUtil {
    /**
     * @return True if null, or if it's entirely whitespace
     */
    public static boolean isNullEmptyOrWhitespace(CharSequence str) {
        if (str == null)
            return true;

        return isEmptyOrWhitespace(str);
    }

    /**
     * @return True if every single character in the sequence is either whitespace
     * or non-printable (ascii value &lt; 20)
     */
    public static boolean isEmptyOrWhitespace(CharSequence str) {
        int end = str.length();
        char c;
        for (int i = 0; i < end; i++) {
            if (!((c = str.charAt(i)) <= ' ' || Character.isWhitespace(c))) {
                return false;
            }
        }
        return true;
    }

    /**
     * Performs an MD5 hash on a string. This is primarily used to determine if
     * there are differences between the content of a trello card and of a GUS
     * work item.
     *
     * @param plaintext
     * @return the MD5 hash of the string
     */
    public static String getMD5Hash(String str) {
        MessageDigest md = null;
        try {
            md = MessageDigest.getInstance("MD5");
        } catch (Exception e) {
            return "";
        }
        md.update(str.getBytes());
        byte[] digest = md.digest();
        StringBuffer sb = new StringBuffer();
        for (byte b : digest) {
            sb.append(String.format("%02x", b & 0xff));
        }
        return sb.toString();
    }

    /**
     * Return carriages get printed as [\r], newline as [\t] and tabs as [\t]
     * @param string That has some whitespace that's desired to be printed
     * @return A printable string that identifies non-visible whitespace
     */
    public static String escapeString(String str) {
        return str.replace("\r","[\\r]")
            .replace("\n","[\\n]")
            .replace("\t","[\\t]");
    }

}
