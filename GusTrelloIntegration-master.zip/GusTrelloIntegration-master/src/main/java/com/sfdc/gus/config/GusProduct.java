package com.sfdc.gus.config;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.HashCodeBuilder;


@Entity
@Table(name="gusproduct", schema="configuration")
public class GusProduct {

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private long gusProductId;
    public long getGusProductId() { return gusProductId; }
    // public void setGusProductId(long id) { gusProductId = id; }

    private String productName;
    public String getProductName() { return productName; }

    @ManyToOne
    @JoinColumn(name="gusteamid")
    private GusTeam gusTeam;
    public GusTeam getGusTeam() { return gusTeam; }
    // public void setGusTeam(GusTeam gusTeam) { this.gusTeam = gusTeam; }

    @OneToMany(mappedBy="gusProduct", fetch=FetchType.EAGER)
    private List<ProductListMapping> productListMappings;
    public List<ProductListMapping> getProductListMappings() { return productListMappings; }
    // public void setProductListMappings(List<ProductListMapping> plms) { this.productListMappings = plms; }

    public GusProduct() {}
    public GusProduct(String productName, GusTeam gusTeam) {
        this.productName = productName;
        this.gusTeam = gusTeam;
    }

    @Override
    public String toString() {
        return "<gusproduct "
            + "id=" + gusProductId + " "
            + "productname=" + productName + " "
            + ">";
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder()
            .append(gusProductId)
            .append(productName)
            .toHashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) { return false; }
        if (obj == this) { return true; }
        if (obj.getClass() != getClass()) {
            return false;
        }
        GusProduct tlobj = (GusProduct) obj;
        return tlobj.getGusProductId() == gusProductId
            && tlobj.getProductName().equals(productName);
    }
}
