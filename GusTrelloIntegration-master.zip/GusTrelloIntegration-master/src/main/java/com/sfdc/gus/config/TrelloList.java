package com.sfdc.gus.config;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Timer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.HashCodeBuilder;

@Entity
@Table(name="trellolist", schema="configuration")
public class TrelloList {

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private long trelloListId;
    public long getTrelloListId() { return trelloListId; }

    private String listName;
    public String getListName() { return listName; }

    @OneToMany(mappedBy="trelloList")
    private List<ProductListMapping> productListMappings;
    public List<ProductListMapping> getProductListMappings() { return productListMappings; }

    @ManyToOne
    @JoinColumn(name="trelloboardid")
    private TrelloBoard trelloBoard;
    public TrelloBoard getTrelloBoard() { return trelloBoard; }

    public TrelloList() {}
    public TrelloList(String listName, TrelloBoard trelloBoard) {
        this.listName = listName;
        this.trelloBoard = trelloBoard;
    }

    @Override
    public String toString() {
        return "<trellolist "
            + "id=" + trelloListId + " "
            + "listname=" + listName + " "
            + ">";
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder()
            .append(trelloListId)
            .append(listName)
            .toHashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) { return false; }
        if (obj == this) { return true; }
        if (obj.getClass() != getClass()) {
            return false;
        }
        TrelloList tlobj = (TrelloList) obj;
        return tlobj.getTrelloListId() == trelloListId
            && tlobj.getListName().equals(listName);
    }
}
