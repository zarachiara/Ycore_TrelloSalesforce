package com.sfdc.gus.config;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.HashCodeBuilder;

@Entity
@Table(name="guslogin", schema="configuration")
public class GusLogin {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private long gusLoginId;
    public long getGusLoginId() { return gusLoginId; }
    // public void setGusLoginId(long id) { gusLoginId = id; }

    private String gusUserId;
    public String getUserId() { return gusUserId; }

    private String refreshToken;
    public String getRefreshToken() { return refreshToken; }

    public GusLogin() {}
    public GusLogin(String gusUserId, String refreshToken) {
        this.gusUserId = gusUserId;
        this.refreshToken = refreshToken;
    }

    @Override
    public String toString() {
        return "<guslogin "
            + "id=" + gusLoginId + " "
            + "gusUserId=" + gusUserId + " "
            + "encrypted refreshToken=" + refreshToken
            + ">";
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder()
            .append(gusLoginId)
            .append(refreshToken)
            .toHashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) { return false; }
        if (obj == this) { return true; }
        if (obj.getClass() != getClass()) {
            return false;
        }
        GusLogin tlobj = (GusLogin) obj;
        return tlobj.getGusLoginId() == gusLoginId
            && tlobj.getRefreshToken().equals(refreshToken);
    }

}
