package com.sfdc.gus.config;

public enum GusStatus {
    NEW("New"),
    IN_PROGRESS("In Progress"),
    COMPLETED("Closed");

    private String gusStrStatus;

    private GusStatus(String gusStr) {
        this.gusStrStatus = gusStr;
    }

    public String getName() {
        return gusStrStatus;
    }
}
