package com.sfdc.gus.config;

import javax.persistence.Column;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.JoinColumn;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.HashCodeBuilder;

@Entity
@Table(name="filteritem", schema="configuration")
public class FilterItem {

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private long filterItemId;
    public long getFilterItemId() { return filterItemId; }

    private String keyword;
    public String getKeyword() { return keyword; }

    @ManyToOne
    //@PrimaryKeyJoinColumn
    @JoinColumn(name="filtersetid")
    private FilterSet filterSet;
    public FilterSet getFilterSet() { return filterSet; }
    public void setFilterSet(FilterSet filterSet) { this.filterSet = filterSet; }

    public FilterItem() {}
    public FilterItem(String keyword, FilterSet filterSet) {
        this.keyword = keyword;
        this.filterSet = filterSet;
    }

    @Override
    public String toString() {
        return "<filteritem "
            + "id=" + filterItemId + " "
            + "keyword=" + keyword + " "
            + ">";
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder()
            .append(filterItemId)
            .append(keyword)
            .toHashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) { return false; }
        if (obj == this) { return true; }
        if (obj.getClass() != getClass()) {
            return false;
        }
        FilterItem tlobj = (FilterItem) obj;
        return tlobj.getFilterItemId() == filterItemId
            && tlobj.getKeyword().equals(keyword);
    }
}
