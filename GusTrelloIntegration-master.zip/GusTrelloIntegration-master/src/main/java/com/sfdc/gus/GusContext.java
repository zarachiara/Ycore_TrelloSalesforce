package com.sfdc.gus;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.FileInputStream;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.http.client.ClientProtocolException;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.boot.registry.classloading.spi.ClassLoaderService;

import com.sfdc.gus.config.GusLogin;
import com.sfdc.gus.config.ProjectConfig;
import com.sfdc.gus.config.DatabaseHelper;
import com.sfdc.gus.security.AESDualCrypt;
import com.sforce.soap.enterprise.EnterpriseConnection;
import com.sforce.ws.ConnectionException;

public class GusContext {

    public static final String DEFAULT_PRIORITY = "P1";
    public static final String DETAILS_FIELD = "Details__c".intern();
    public static final String GUS_WOK_ITEM = "ADM_Work__c";
    public static final String ID_FIELD = "Id".intern();
    public static final String ID_LOWER_FIELD = "id".intern();
    public static final String NAME_FIELD = "Name".intern();
    public static final String PRIORITY_FIELD = "Priority__c".intern();
    public static final String PRODUCT_TAG_FIELD = "Product_Tag__c".intern();
    public static final String RECORDS_FIELD = "records".intern();
    public static final String RECORD_TYPE_FIELD = "Type__c".intern();
    public static final String RECORD_TYPE_ID_FIELD = "RecordTypeId".intern();
    public static final String RELEASE_FREEZE_BUILD_FIELD = "Release_Freeze__c".intern();
    public static final String SCHEDULED_BUILD_FIELD = "Scheduled_Build__c".intern();
    public static final String SPRINT_FIELD = "Sprint__c".intern();
    public static final String STATUS_FIELD = "Status__c".intern();
    public static final String STATUS_VALUE = "New";
    public static final String STORY_POINTS_FIELD = "Story_Points__c".intern();
    public static final String SUBJECT_FIELD = "Subject__c".intern();
    public static final String USER_STORY_VALUE = RestUtil.RestEncode("User Story");
	
	private GusLogin config;
    private EnterpriseConnection connection;
    private String sessionId;
    private String currentSprintId;
    private String userName;

    private List<Map> gusInfo;

    private Map<String, String> team_id;
    private Map<String, String> product_id;
    private Map<String, String> sprint_id;

    // Used to help with encryption/decryption of passwords
    private AESDualCrypt crypter;

    private static Logger logger = Logger.getLogger(GusContext.class);

    // The only thing we really require from the GusLogin is a refresh token
	public GusContext(GusLogin config, AESDualCrypt crypter) throws RuntimeException {
        if(config.getRefreshToken() == null) {
            throw new RuntimeException("Gus Context requires a refresh_token to run");
        }
		this.config = config;
        this.crypter = crypter;
	}

    public String getSessionId() {
        return sessionId;
    }

    public void setSessionId(String sess) {
        sessionId = sess;
    }

    public String getUserId() {
        return config.getUserId();
    }


    /*
     * TODO: These should be stored in GlobalConfig in the DB
     */
    public static final String GUS_API_VERSION = "v29.0";
    public static final String GUS_ENDPOINT;

    /*
     * We use the default URL for gus unless we find an endpoint.properties file (found in resources dir) that specifies a different endpoint.
     * This is how we handle testing (we use a MockGus found under the testHelpers under test dir).
     */
    static {
        String defaultURL = "https://gus.my.salesforce.com";
        String chosenURL;
        try {
            Properties endpointProps = new Properties();

            InputStream endpointStream = null;
            try {
                endpointStream = new URL("endpoint.properties").openStream();
            } catch (Exception e) { System.out.println("Cannot find endpoint.properties as a URL"); }

            try {
                endpointStream = new StandardServiceRegistryBuilder()
                    .getBootstrapServiceRegistry()
                    .getService(ClassLoaderService.class)
                    .locateResourceStream("endpoint.properties");
            } catch (Exception e) { System.out.println("Cannot find endpoint.properties using Hibernate ClassLoader"); }

            if (endpointStream == null) {
                // Neither URL lookup nor using hibernate's class/resource loader worked.
                // At this point, things have failed horribly, and there's probably no way
                // we'll be able to find the file ever. Try to load it, resulting in a
                // nearly-guaranteed FileNotFoundException
                endpointProps.load(new FileInputStream("endpoint.properties"));
            }

            endpointProps.load(endpointStream);
            chosenURL = endpointProps.getProperty("gus.url", defaultURL);
            logger.debug("endpoint.properties load successful. Loaded URL: " + chosenURL);
        } catch (FileNotFoundException e) {
            logger.debug("endpoint.properties could not be found. Using the default GUS URL: " + defaultURL);
            chosenURL = defaultURL;
        } catch (IOException e) {
            e.printStackTrace();
            chosenURL = defaultURL;
        }
        GUS_ENDPOINT = chosenURL;
    }

    public static String GUS_CLIENT_ID;
    public static String GUS_CLIENT_SECRET;


    /*
     * This will load the respective global properties into their own variables
     */
    public static void setup(DatabaseHelper db) {
        if(GUS_CLIENT_SECRET != null && GUS_CLIENT_ID != null) return;
        GUS_CLIENT_ID = db.getGlobalProperty("client_id");
        GUS_CLIENT_SECRET = db.getGlobalProperty("client_secret");
    }

	public static final String GUS_SOAP_URI = "/services/Soap/c/" + GUS_API_VERSION;
	public static final String GUS_REST_URI = "/services/data/" + GUS_API_VERSION + "/";

    /*
     * Return the full SOAP url for gus
     */
	public static String getGusSoapLoginUrl() {
		return GUS_ENDPOINT + GUS_SOAP_URI;
	}

    /*
     * Returns a string of the query in SOQL
     */
	public String getRestQueryUrlString(String type, String condition) {
        String conditional = "";
        if (condition != null && condition.length() > 0) {
        	conditional = "+WHERE+" + condition;
        }
		return GUS_ENDPOINT+ GUS_REST_URI + "query/?q=SELECT+Id+FROM+" + type + conditional;
	}

    /*
     * Returns a string of the query in SOQL
     */
	public String getRestQueryUrlString(String fields, String type, String condition) {
        String conditional = "";
        if (condition != null && condition.length() > 0) {
        	conditional = "+WHERE+" + condition;
        }
		return GUS_ENDPOINT + GUS_REST_URI + "query/?q=SELECT+"+fields+"+FROM+" + type + conditional;
	}

	public String getRestSObjectAccessUrlString(String type) {
		return getRestSObjectAccessUrlString(type, null);
	}

    /*
     * Get the describe information for this sobject
     */
	public String getRestSObjectAccessUrlString(String type, String id) {
		return GUS_ENDPOINT + GUS_REST_URI + "sobjects/" + type +"/" + (id != null ? id : "");
	}

    /*
     * Create a gus url link for this object
     */
	public String getAccessUrlString(String id) {
		return GUS_ENDPOINT +"/" + (id != null ? id : "");
    }

    /*
     * Headers required for all REST queries. Uses the sessionId
     */
	private Map<String, String> getRestHeaders() {
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Authorization", "Bearer " + this.sessionId);
		headers.put("Content-Type", "application/json; charset=utf-8");
		return headers;
	}

    /*
     * Provided a gwi, update it on the Gus itself
     */
    public void updateGusWorkItem(GusWorkItem workItem) throws ClientProtocolException, IOException, JSONException {
        Map<String, String> fields = workItem.getChangedValuesMap();
        logger.debug("Final check before GWI update. Will be updating: " + fields);
        String gusWorkItemId = workItem.getId();
        RestUtil.updateObject(getRestSObjectAccessUrlString("ADM_Work__c", gusWorkItemId),
                getRestHeaders(), fields, RestUtil.HttpUpdateMethod.HTTP_PATCH);
    }

    /*
     * Provided an ID, get the describe information of that work item and create a gwi from it
     */
    public GusWorkItem getGusWorkItem(String gusWorkItemId) throws ClientProtocolException, IOException, JSONException {
        JSONObject workItem = RestUtil.getObject(getRestSObjectAccessUrlString("ADM_Work__c", gusWorkItemId), getRestHeaders());
        return new GusWorkItem(workItem);
    }

    /*
     * Provided a tc, a productTag, and a status, create a gwi on Gus
     */
    public void createGusWorkItem(TrelloCard card, String productTag, String status) throws ClientProtocolException, IOException, JSONException {

        GusWorkItem gwi = new GusWorkItem(card);

        Map<String, String> fields = new HashMap<String, String>();
        fields.put("RecordTypeId", "0129000000006gDAAQ");
        fields.put(SUBJECT_FIELD, encodeSingleQuotes(gwi.subject));
        fields.put(DETAILS_FIELD, encodeSingleQuotes(gwi.details));
        fields.put(STATUS_FIELD, status);
        fields.put("Story_Points__c", gwi.points);
        fields.put("Sprint__c", currentSprintId);
        fields.put(PRIORITY_FIELD, DEFAULT_PRIORITY);
        if (card.getPoints() > 0) {
            fields.put(STORY_POINTS_FIELD, Integer.toString(card.getPoints()));
        }
        fields.put(PRODUCT_TAG_FIELD, productTag);

        JSONObject workItem = RestUtil.createObject(getRestSObjectAccessUrlString(GUS_WOK_ITEM), getRestHeaders(), fields);
        String id = workItem.getString(ID_LOWER_FIELD);
        // have this tc point to the gwi
        card.setGusId(id);
    }

    /*
     * Login to Gus using SOAP login, get the userId, and return a GusContext object with it. 
     * If login fails, a JSONException will be thrown (intercepted in IFE). Verify that the Gus UserId
     * exists within our system.
     */
    public static GusContext login(String userName, String password, DatabaseHelper db, AESDualCrypt crypter) throws ConnectionException, ClientProtocolException, IOException, JSONException {
        String[] outParams = new String[2];
        RestUtil.soapLogin(getGusSoapLoginUrl(), userName, crypter.decrypt(password), outParams);
        String sessionId = outParams[0];
        String userId = outParams[1];
        logger.debug("Logged in as " + userName + ", userId: " + userId + " and sessionId: " + sessionId);
        // Make sure this user exists within our system (that we have a refresh token for them)
        ProjectConfig pc = db.getProjectForUserId(userId);
        if (pc == null) return null;
        GusContext gctx = new GusContext(pc.getGusLogin(), crypter);
        gctx.setSessionId(sessionId);
        return gctx;
    }

    /*
     * This function will be called in the event of a connection error. Using the refresh token, the GusContext will request a new access_token
     */
    public void refresh() throws ConnectionException, ClientProtocolException, IOException, JSONException {
        Map<String, String> params = new HashMap<String, String>();
        params.put("grant_type","refresh_token");
        params.put("client_id",crypter.decrypt(GUS_CLIENT_ID));
        params.put("client_secret",crypter.decrypt(GUS_CLIENT_SECRET));
        params.put("refresh_token",crypter.decrypt(config.getRefreshToken()));

        Map<String, String> headers = new HashMap<String, String>();
        headers.put("Content-Type","application/x-www-form-urlencoded");

        // request for new sessionId
        JSONObject json = RestUtil.simplePost(GUS_ENDPOINT + "/services/oauth2/token", headers, params);
        logger.debug("REFRESH: " + json.toString());
        sessionId = json.getString("access_token");
    }

    /*
     * Get the user name of this GusContext. Usually a good test to see if we're connected to Gus
     */
    public String getUserName() throws ConnectionException, ClientProtocolException, IOException, JSONException {
        JSONObject json = RestUtil.getObject(getRestQueryUrlString("Name","User","Id+=+'"+config.getUserId()+"'"), getRestHeaders());
        userName = json.getJSONArray(RECORDS_FIELD).getJSONObject(0).getString("Name");
        return userName;
    }

    /*
     * If we have a sessionId, we consider ourselves logged in
     */
    public boolean isLoggedIn() {
        return (sessionId != null);
    }

    /*
     * Set our connection and sessionId to null
     */
    public void logout() throws ConnectionException {
        if (connection != null) {
            connection.logout();
            connection = null;
        }
        sessionId = null;
    }

    /*
     * Used to refresh the gusInfo list
     */
    public void refreshGusInfo() throws ClientProtocolException, JSONException, IOException {
        gusInfo = null;
        //getGusInfo();
    }

    /*
     * Get the gusInfo and assume no extraGusTeamNames
     */
    public List<Map> getGusInfo() throws ClientProtocolException, JSONException, IOException {
        return getGusInfo(null);
    }

    /*
     * Get all Gus Team names, Product Tags for this user, and any extra if a list is provided
     */
    public List<Map> getGusInfo(List<String> extraGusTeamNames) throws ClientProtocolException, JSONException, IOException {
        logger.debug("extraGusTeamNames: " + extraGusTeamNames);
        try {
            // don't reconstruct the gusInfo list if we don't need to.
            // This has the downside of not always being up to date with Gus changes (such as if you were just added to a new team),
            // but a log out/login will fix it, and this cuts down on network requirements.
            if(gusInfo == null) {
                gusInfo = new ArrayList<Map>();
                // Get all teams this person is a member of
                JSONObject json = RestUtil.getObject(getRestQueryUrlString("Scrum_Team__r.Name,Scrum_Team__r.Id", "ADM_Scrum_Team_Member__c","Member_Name__c+=+'"+config.getUserId()+"'"), getRestHeaders());
                JSONArray teams = json.getJSONArray(RECORDS_FIELD);
                // iterate through all of the teams, add them to the gusInfo list, and get the product tags for them
                for(int i = 0; i < teams.length(); ++i) {
                    Map team = new HashMap();
                    team.put("Id", teams.getJSONObject(i).getJSONObject("Scrum_Team__r").getString("Id"));
                    team.put("Name", teams.getJSONObject(i).getJSONObject("Scrum_Team__r").getString("Name"));
                    team.put("product_tags",getProductTags((String)team.get("Id")));
                    gusInfo.add(team);
                }

                // If we were provided a list of extra team names, add them as well
                if(extraGusTeamNames != null) {
                    for(String name : extraGusTeamNames) {
                        json = RestUtil.getObject(getRestQueryUrlString("Name,Id","ADM_Scrum_Team__c","Name+=+'" + name.replace(" ","+") + "'"),
                            getRestHeaders());
                        logger.debug("Extra Teams JSON: " + json);
                        teams = json.getJSONArray(RECORDS_FIELD);
                        for (int i = 0; i < teams.length(); ++i) {
                            Map team = new HashMap();
                            team.put("delete_name", name);
                            team.put("Id", teams.getJSONObject(i).getString("Id"));
                            team.put("Name", teams.getJSONObject(i).getString("Name"));
                            team.put("product_tags", getProductTags((String)team.get("Id")));
                            gusInfo.add(team);
                        }
                    }
                }
            }
        } catch (Exception e) {
            // In case an exception was encountered, need to reset appropriate variables
            gusInfo = null;

            // After reset, rethrow the exception to notify the calling function something messed up
            throw e;
        }
        return gusInfo;
    }

    /*
     * Get all ProductTags that are stored in the gusInfo object
     */
    public List<Map> getProductTags() throws ClientProtocolException, JSONException, IOException {
        List<Map> arr = new ArrayList<Map>();
        getGusInfo();
        for(Map team : gusInfo) {
            arr.addAll((List<Map>)team.get("product_tags"));
        }
        return arr;
    }

    /*
     * check with Gus if the teamname exists. If it does, return the id of that gus team (so we can properly link to it)
     */
    public String getTeamIfExists(String teamName) throws ClientProtocolException, JSONException, IOException {
        logger.debug("Checking for team " + teamName);
        JSONObject json = RestUtil.getObject(getRestQueryUrlString("Id","ADM_Scrum_Team__c","Name+=+'" + RestUtil.RestEncode(teamName) + "'"), getRestHeaders());
        logger.debug("Response: " + json);
        if (json.getString("totalSize").equals("0")) {
            return null;            
        }
        return json.getJSONArray("records").getJSONObject(0).getString("Id");
    }

    /*
     * check with Gus if the productTag exists. If it does, return the id of that gus product tag (so we can properly link to it)
     */
    public String getProductIfExists(String productName) throws ClientProtocolException, JSONException, IOException {
        JSONObject json = RestUtil.getObject(getRestQueryUrlString("Id","ADM_Product_Tag__c","Name+=+'" + RestUtil.RestEncode(productName) + "'"), getRestHeaders());
        if (json.getString("totalSize").equals("0")) {
            return null;            
        }
        return json.getJSONArray("records").getJSONObject(0).getString("Id");
    }

    /*
     * Return the sprint Id of the current sprint for this team
     */
    public String getTeamSprint(String teamId) throws ClientProtocolException, JSONException, IOException {
        JSONObject sprintList = RestUtil.queryObjects(getRestQueryUrlString("Id,Name","ADM_Sprint__c",
                    "Scrum_Team__c+=+'" + teamId + "'+AND+Days_Remaining__c+!=+'CLOSED'+AND+Days_Remaining__c+!=+'NOT%20STARTED'"),
                    getRestHeaders());
        if (sprintList.getInt("totalSize") == 0) {
            return null;
        }
        return sprintList.getJSONArray("records").getJSONObject(0).getString("Id");
    }

    /*
     * Get all product tags for this gus team
     */
    public List<Map<String,String>> getProductTags(String teamId) throws ClientProtocolException, JSONException, IOException {
        // 
        JSONObject productTags = RestUtil.queryObjects(getRestQueryUrlString("Id,Name","ADM_Product_Tag__c",
                "Team__c+=+'" + teamId + "'"),
                getRestHeaders());
        List<Map<String,String>> arr = new ArrayList<Map<String,String>>();
        // Iterate through the records field and gather all product tag names and their ids
        JSONArray json = productTags.getJSONArray(RECORDS_FIELD);
        for(int i = 0; i < json.length(); ++i) {
            HashMap<String, String> productTag = new HashMap<String, String>();
            productTag.put("Id",json.getJSONObject(i).getString("Id"));
            productTag.put("Name",json.getJSONObject(i).getString("Name"));
            arr.add(productTag);
        }
        return arr;
    }

    /*
     * Get all gwis from this sprint
     */ 
    public Map<String, GusWorkItem> getWorkItems(String sprintId) throws ClientProtocolException, JSONException, IOException {
        JSONObject c = RestUtil.queryObjects(getRestQueryUrlString("Id,Name,Subject__c,Status__c,Details__c,Story_Points__c", "ADM_Work__c",
            "Sprint__c+=+'" + sprintId + "'"),
            getRestHeaders());
        JSONArray cards = c.getJSONArray(RECORDS_FIELD);
        Map<String, GusWorkItem> gwis = new HashMap<String, GusWorkItem>();
        // Create a gwi for each gwi found in the sprint
        for(int i = 0; i < cards.length(); ++i) {
            GusWorkItem gwi = new GusWorkItem(cards.getJSONObject(i));
            gwis.put(gwi.id, gwi);
        }
        return gwis;
    }

    /*
     * Get all gwis that were created by this user
     */
    public Map<String, GusWorkItem> getMyWorkItems(String sprintId) throws ClientProtocolException, JSONException, IOException {
        if (sprintId == null) {
            return new HashMap<String, GusWorkItem>();
        }
        JSONObject c = RestUtil.queryObjects(getRestQueryUrlString("Id,Name,Subject__c,Status__c,Details__c,Story_Points__c", "ADM_Work__c",
            "Sprint__c+=+'" + sprintId + "'+AND+CreatedById+=+'" + config.getUserId() + "'"),
            getRestHeaders());
        JSONArray cards = c.getJSONArray(RECORDS_FIELD);
        Map<String, GusWorkItem> gwis = new HashMap<String, GusWorkItem>();
        for(int i = 0; i < cards.length(); ++i) {
            GusWorkItem gwi = new GusWorkItem(cards.getJSONObject(i));
            gwis.put(gwi.id, gwi);
        }
        return gwis;
    }

    /*
     * Get all gwis for the teams current sprint
     */
    public Map<String, GusWorkItem> getAllWorkItems(String teamId) throws ClientProtocolException, JSONException, IOException {
        currentSprintId = getTeamSprint(teamId);
        return getWorkItems(currentSprintId);
    }

    /*
     * Get all gwis for the teams current sprint and that are owned by this user
     */
    public Map<String, GusWorkItem> getAllMyWorkItems(String teamId) throws ClientProtocolException, JSONException, IOException {
        currentSprintId = getTeamSprint(teamId);
        return getMyWorkItems(currentSprintId);
    }

    /*
     * Helper function
     */
	public String encodeSingleQuotes(String text) {
		return text.replaceAll("'", "''");
	}
}
