package com.sfdc.gus.config;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.HashCodeBuilder;

@Entity
@Table(name = "globalkvconfig", schema="configuration")
public class GlobalKVConfig {

    @Id
    @Column(name="key", unique=true, nullable=false)
    private String key;
    public String getKey() { return key; }

    @Column(name="value")
    private String value;
    public String getValue() { return value; };
    public void setValue(String value) { this.value = value; }

    public GlobalKVConfig() {}
    public GlobalKVConfig(String key, String value) {
        this.key = key;
        this.value = value;
    }
}
