package com.sfdc.gus.http;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.Charset;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.ResponseHandler;

public class Utf8ResponseHandler implements ResponseHandler<String> {

	@Override
	public String handleResponse(HttpResponse response)
			throws IOException {
		HttpEntity entity = response.getEntity();
        if (entity != null) {
        	ByteArrayOutputStream oStream = new ByteArrayOutputStream();
        	entity.writeTo(oStream);
        	return new String(oStream.toByteArray(), Charset.forName("UTF-8"));
        } else {
            return null;
        }
    }
}
