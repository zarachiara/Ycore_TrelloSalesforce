package com.sfdc.gus;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.json.JSONException;
import org.json.JSONObject;
import org.apache.log4j.Logger;

import com.sfdc.gus.util.TextUtil;

public class GusWorkItem {
	public String id;
	public String subject;
	public String details;
	public String sprintId;
	public String buildId;
	public String status;
	public String trelloCardId;
	public String oldHash;
	public String points;
	public Map<String, String> changedValuesMap;

	private Logger logger = Logger.getLogger(GusWorkItem.class);
	
	public GusWorkItem(JSONObject workItem) throws JSONException {
		this.id = workItem.getString(GusContext.ID_FIELD);
		this.subject = workItem.getString(GusContext.SUBJECT_FIELD);
		this.details = workItem.isNull(GusContext.DETAILS_FIELD) ? "" : workItem.getString(GusContext.DETAILS_FIELD);
		this.sprintId = workItem.isNull(GusContext.SPRINT_FIELD) ? null : workItem.getString(GusContext.SPRINT_FIELD);
		this.buildId = workItem.isNull(GusContext.SCHEDULED_BUILD_FIELD) ? null : workItem.getString(GusContext.SCHEDULED_BUILD_FIELD);
		this.status = workItem.isNull("Status__c") ? "New" : workItem.getString("Status__c");
		this.points = workItem.isNull("Story_Points__c") ? "" : workItem.getString(GusContext.STORY_POINTS_FIELD);
		int idx = this.details.indexOf("trello card: ");
		int end = this.details.indexOf("\n",idx);
		if(idx > -1) {
			this.trelloCardId = this.details.substring(idx + 13, end);
		}
		idx = this.details.indexOf("Hash: ");
		if(idx > -1) {
			this.oldHash = this.details.substring(idx + 6, idx + 6 + 32);
		}
	}

	public GusWorkItem(TrelloCard tc) {
		this.trelloCardId = tc.id;
		if(tc.points > 0) {
			this.points = String.valueOf(tc.points);
		}
		this.subject = tc.name;
		this.details = tc.getDesc();

		updateDetails();
	}

	public String getId() {
		return id;
	}

	public String getSubject() {
		return subject;
	}

	// returns the details stripped of the extra data
	public String getDetails() {
		return details.split("----------")[0].trim();
	}

	public String getPoints() {
		return points;
	}
	
	public String getSprintId() {
		return sprintId;
	}

	public String getBuildId() {
		return buildId;
	}

	/*
	public boolean isChanged() {
		return this.changedValuesMap != null && !this.changedValuesMap.isEmpty();
	}
	*/

	public boolean isChanged() {
		if(oldHash == null) return false;
		return !oldHash.equals(TextUtil.getMD5Hash(this.subject + getDetails()));
	}

	public Map<String, String> getChangedValuesMap() {
		return changedValuesMap;
	}

	public void setSubject(String subject) {
		if (!TextUtil.isNullEmptyOrWhitespace(subject) && 
				(TextUtil.isNullEmptyOrWhitespace(this.subject) ||
						!this.subject.trim().equals(subject.trim()))) {
			this.subject = subject;
			setValueChanged(GusContext.SUBJECT_FIELD, this.subject);
		}
	}

	public void setDetails(String details) {
		if (!TextUtil.isNullEmptyOrWhitespace(details) && 
				(TextUtil.isNullEmptyOrWhitespace(this.details) ||
						!this.details.trim().equals(details.trim()))) {
			this.details = details.trim();
			setValueChanged(GusContext.DETAILS_FIELD, this.details);
		}
	}

	public void setStatus(String status) {
		if (this.status == null || !this.status.equals(status)) {
			this.status = status;
			setValueChanged("Status__c", this.status);
		}
	}

	public void updateDetails() {
		this.details = getDetails();
		updateDetails(this.trelloCardId);
	}

	public void updateDetails(String newTrelloCardId) {
		String oldDetails = getDetails();
		this.details = oldDetails;
		this.details += "\n\n----------";
		this.details += "\ntrello card: " + newTrelloCardId;
		this.details += "\nHash: " + TextUtil.getMD5Hash(this.subject + oldDetails);
		setValueChanged(GusContext.DETAILS_FIELD, this.details);
	}

	public void setPoints(String points) {
		if (this.points != points) {
			this.points = points;
			setValueChanged(GusContext.STORY_POINTS_FIELD, this.points);
		}
	}

	public void setSprintId(String sprintId) {
		if (!TextUtil.isNullEmptyOrWhitespace(sprintId) && 
				(TextUtil.isNullEmptyOrWhitespace(this.sprintId) ||
						!this.sprintId.trim().equals(sprintId.trim()))) {
			this.sprintId = sprintId;
			setValueChanged(GusContext.SPRINT_FIELD, this.sprintId);
		}
	}

	private synchronized void setValueChanged(String field, String value) {
		if (this.changedValuesMap == null) {
			this.changedValuesMap = new HashMap<String, String>();
		}
		this.changedValuesMap.put(field, value);
	}

	// used to see if this gusworkitem corrosponds to this trellocard
	public boolean equals(TrelloCard tc) {
		return tc.name.equals(this.subject) && tc.getDesc().equals(getDetails());
	}

	// used to check for differences between this gusworkitem and this trellocard
	// TODO: implement function
	public boolean same(TrelloCard tc) {
		return false;
	}

	// if this function return true, it means keep this work item 
	public boolean filter(String kw, boolean filterIn) {
	    Pattern pat = Pattern.compile(kw);
	    Matcher match = pat.matcher(this.subject);
	    return (filterIn ? match.find() : !match.find());
	}

	public String toString() {
		String ret = "{Work Item ID: " + id;
		ret += ", Subject: " + TextUtil.escapeString(subject);
		ret += ", Status: " + status;
		ret += ", Details: " + TextUtil.escapeString(details);
		if(trelloCardId != null) ret += ", Trello Card ID: " + trelloCardId;
		ret += "}";
		return ret;
	}
}
