package com.sfdc.gus.config;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.apache.log4j.Logger;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

public class DatabaseHelper {
    private Logger logger = Logger.getLogger(DatabaseHelper.class);

    private SessionFactory sessionFactory;

    public DatabaseHelper(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    /*
     * Close the session factory. Note that the session factory is passed in
     * to the constructor, so if anything else is using it, errors will occur
     * after this function is called
     */
    public void close() { sessionFactory.close(); }

    /**
     * Proxy to SessionFactory#update(object)
     *
     * Given an object that may or may not exist, save it to the database.
     * If it is a new object, it will be inserted. If it previously existed,
     * it will be updated.
     */
    public void saveUpdate(Object object) {
        Session sess = sessionFactory.openSession();
        sess.beginTransaction();
        sess.update(object);
        sess.getTransaction().commit();
        sess.close();
    }

    /**
     * Used to be a proxy to SessionFactory#refresh(object), but that didn't seem
     * to quite always work. Instead, this is a proxy to SessionFactory#load. The
     * downside is that it also takes the object's ID. Since we don't always know
     * how to retrieve it from the object, we have to bring it in as another argument.
     *
     * Given a saved object, refresh all its fields from the database.
     * @param object An object that was previously saved in the database
     * @param id     The primary key on the object
     */
    public void refresh(Object object, long id) {
        Session sess = sessionFactory.openSession();
        sess.load(object, id);
        sess.close();
    }

    /**
     * Retrieve the encrypted Trello API key from the database
     * @return Encrypted Trello API Key
     */
    public String getTrelloAPIKey() {
        return getGlobalProperty("appkey");
    }

    /**
     * Generic interface to the KV store that's loosely in the database
     * @param key Key to lookup in the KV store
     * @return Value for the key or null if there is not a record of the key
     */
    public String getGlobalProperty(String key) {
        Session sess = sessionFactory.openSession();
        List<GlobalKVConfig> kvpairs = sess.createQuery("from GlobalKVConfig where key=:key")
            .setParameter("key", key)
            .list();

        String value=null;
        if (kvpairs.size() == 1) {
            value = kvpairs.get(0).getValue();
        } else {
            // That key was not found in the KV store. Politely return null
            value = null;
        }

        sess.close();
        return value;
    }

    /**
     * Removes the key and its value from the KV store. This is equivalent to
     * java.util.Map.put(key, null) in terms of effect.
     *
     * @param key The key to unset
     */
    public void unsetGlobalProperty(String key) {
        Session sess = sessionFactory.openSession();
        sess.beginTransaction();

        List<GlobalKVConfig> kvpairs = sess.createQuery("from GlobalKVConfig where key=:key")
            .setParameter("key", key)
            .list();
        if (kvpairs.size() >= 1) {
            sess.delete(kvpairs.get(0));
        } else {
            // Doesn't exist
        }

        sess.getTransaction().commit();
        sess.close();
    }

    /**
     * Changes the value of a key in the KV store. Setting a value to null will
     * caused the key to become unset.
     *
     * @param key Key to lookup
     * @param value Value to change it to
     */
    public void setGlobalProperty(String key, String value) {
        // avoid saving nulls to the DB by deleting the record if setting to null
        if (value == null) {
            unsetGlobalProperty(key);
            return;
        }
        // First, check if we have to do an insert, or an update
        Session sess = sessionFactory.openSession();
        sess.beginTransaction();

        List<GlobalKVConfig> kvpairs = sess.createQuery("from GlobalKVConfig where key=:key")
            .setParameter("key", key)
            .list();

        if (kvpairs.size() >= 1) {
            // Update
            GlobalKVConfig kvpair = kvpairs.get(0);
            kvpair.setValue(value);
            sess.save(kvpair);
        } else {
            // Insert
            GlobalKVConfig kvpair = new GlobalKVConfig(key, value);
            sess.save(kvpair);
        }

        sess.getTransaction().commit();
        sess.close();
    }

    /**
     * Check whether a user (ProjectConfig), identified by their ID, exists in the
     * database.
     *
     * @param projectId The user's ID (ProjectConfig ID)
     * @return True if they have a record, False otherwise
     */
    public Boolean userExists(Long projectId) {
        Session sess = sessionFactory.openSession();
        ProjectConfig pc = (ProjectConfig)sess.get(ProjectConfig.class, projectId);
        if(pc == null) return false;
        return true;
    }

    /**
     * Using a GUS user ID, check to see if we have a record of the user in our
     * database.
     *
     * @param id User ID from GUS
     * @return True if we have record of them
     */
    public Boolean userIdExists(String id) {
        Session sess = sessionFactory.openSession();
        int userMatches = sess.createQuery("from GusLogin where gususerid=:userId")
            .setParameter("userId", id)
            .list()
            .size();
        sess.close();
        if (userMatches == 1) {
            return true;
        } else {
            // Either there are 2 users, or they do not yet exist.
            return false;
        }
    }

    /**
     * Create a user.
     *
     * @param gusUserId     GUS User Id returned when logging into GUS
     * @param refresh_token Token return by an OAuth flow that can be used to start a session with GUS
     * @param trelloToken   The token returned from Trello that allows our API key access to the user's account
     * @param syncFrequency Seconds between synchronization checks
     */
    public ProjectConfig createUser(String gusUserId, String refresh_token, String trelloToken, int syncFrequency) {
        ProjectConfig pc = new ProjectConfig(
                syncFrequency,
                new GusLogin(gusUserId, refresh_token),
                new TrelloLogin(trelloToken)
                );
        Session sess = sessionFactory.openSession();
        sess.beginTransaction();
        sess.save(pc.getGusLogin());
        sess.save(pc.getTrelloLogin());
        sess.save(pc);
        sess.getTransaction().commit();
        sess.close();

        return pc;
    }

    /**
     * Given a logged in user identified by their ProjectConfig object, cascade-delete
     * that user and their configurations entirely.
     */
    public void deleteUser(ProjectConfig project) {
        Session sess = sessionFactory.openSession();
        sess.beginTransaction();

        // Make sure this object is fully loaded from the DB
        refresh(project, project.getProjectConfigId());

        // Delete all the mappings first
        for (ProductListMapping plm : project.getProductListMappings()) {
            for(FilterSet fs : plm.getFilters()) {
                for(FilterItem fi : fs.getFilterItems()) {
                    sess.delete(fi);
                }
                sess.delete(fs);
            }
            sess.delete(plm);
        }

        // Delete all the extra associations
        for (ExtraTeamAssociation ea : project.getExtraTeamAssociations()) {
            sess.delete(ea);
        }

        sess.delete(project);
        sess.delete(project.getGusLogin());
        sess.delete(project.getTrelloLogin());

        sess.getTransaction().commit();
        sess.close();
    }

    /**
     * Add a relation (multiple ProductListMappings for a user) to a user's config.
     *
     * @param projectId User's ID (ProjectConfig ID)
     * @param rel   Map describing the desired gus to trello mapping
     */
    public List<ProductListMapping> addRelationForUser(long projectId, Map<String, String> rel) {
        // Lookup the Project, and delegate
        return addRelationForUser(getProjectConfig(projectId), rel);
    }

    /**
     * Add a relation (multiple ProductListMappings for a user) to a user's config.
     *
     * @param project User's full identification object
     * @param rel   String map that identifies which lists link with which product and status
     *              product_tag: GUS Product tag ID
     *              gus_team:   GUS team ID
     *              trello_(done|progress|new)(|boardid):   Identification of
     *                  the list that maps to a specific status, both the name and the trello ID for it
     * @return All the ProductListMappings that were created in this process
     */
    public List<ProductListMapping> addRelationForUser(ProjectConfig project, Map<String, String> rel) {
        // NOTE: This function assumes that the fields in rel have been validated
        // What is the format of this Map?

        GusProduct gusProduct = lookupOrCreateProduct(rel.get("product_tag"), rel.get("gus_team"));
        TrelloList done_list = lookupOrCreateList(rel.get("trello_done"), rel.get("trello_done_boardid"));
        TrelloList inprog_list = lookupOrCreateList(rel.get("trello_progress"), rel.get("trello_progress_boardid"));
        TrelloList new_list = lookupOrCreateList(rel.get("trello_new"), rel.get("trello_new_boardid"));

        // Create the 3 mappings
        ProductListMapping done = new ProductListMapping(done_list, gusProduct, GusStatus.COMPLETED, true, project);
        ProductListMapping inprog = new ProductListMapping(inprog_list, gusProduct, GusStatus.IN_PROGRESS, true, project);
        ProductListMapping newmap = new ProductListMapping(new_list, gusProduct, GusStatus.NEW, true, project);

        // Save it
        Session sess = sessionFactory.openSession();
        sess.beginTransaction();
        sess.save(done);
        sess.save(inprog);
        sess.save(newmap);
        sess.getTransaction().commit();

        rel.put("delete_id",done.getProductListMappingId() + "|" +
            inprog.getProductListMappingId() + "|" +
            newmap.getProductListMappingId() + "|");
        // return the three newly created productListMappings
        List<ProductListMapping> newlyCreated = new ArrayList<ProductListMapping>();
        newlyCreated.add(done);
        newlyCreated.add(inprog);
        newlyCreated.add(newmap);

        // Add the 4 types of filetsets to each plm
        addFilterSet(rel.get("gus_filter_in"),
            FilterSource.GUS,
            FilterRuleType.IMPORT,
            newlyCreated,
            sess);
        addFilterSet(rel.get("gus_filter_out"),
            FilterSource.GUS,
            FilterRuleType.EXPORT,
            newlyCreated,
            sess);
        addFilterSet(rel.get("trello_filter_in"),
            FilterSource.TRELLO,
            FilterRuleType.IMPORT,
            newlyCreated,
            sess);
        addFilterSet(rel.get("trello_filter_out"),
            FilterSource.TRELLO,
            FilterRuleType.EXPORT,
            newlyCreated,
            sess);

        sess.close();

        return newlyCreated;
    }

    /**
     * Specify that a group of keywords will now be filtered on.
     * @param kws   Text input for the keywords
     * @param src   Which side we are coming from: Gus or Trello?
     * @param rt    Rule type: exclude matches or include only if it matches
     * @param plms  All the product list mappings that this applies to
     * @param sess  Hibernate session that's already in progress
     */
    private void addFilterSet(String kws, FilterSource src, FilterRuleType rt, List<ProductListMapping> plms, Session sess) {
        logger.debug("Will be creating filterset for " + kws + " from source " + src.name() + " of type " + rt.name() + " for plms " + plms);
        if(kws == null || kws.equals("")) {
            return;
        }
        List<FilterSet> filters = new ArrayList<FilterSet>();
        sess.beginTransaction();
        for(ProductListMapping plm : plms) {
            FilterSet fs = new FilterSet(rt, src, plm);
            filters.add(fs);
            logger.debug("Adding filter set: " + fs + " to plm: " + plm);
            sess.save(fs);
        }
        sess.getTransaction().commit();

        List<FilterItem> items = new ArrayList<FilterItem>();
        String[] kwsStr = kws.split("%0A");
        sess.beginTransaction();
        for (String kw : kwsStr) {
            logger.debug("Will be adding filter keyword: " + kw);
            for (FilterSet fs : filters) {
                FilterItem fi = new FilterItem(kw, fs);
                items.add(fi);
                logger.debug("Adding filter item: " + fi + " to filterset: " + fs);
                sess.save(fi);
            }
        }
        sess.getTransaction().commit();
    }

    /**
     * Delete a single list-status mapping
     * @param userId User ID (ProjectConfig ID) of the user that owns the relation
     * @param relationId The specific product list mapping ID to be deleted. Naturally, this
     *      should be a long... But it's either do it here, or do it in the Integration Front End.
     */
    public void removeRelationForUser(Long userId, String relationId) {
        try {
            Session sess = sessionFactory.openSession();
            ProductListMapping plm = (ProductListMapping)sess.load(ProductListMapping.class,Long.parseLong(relationId));
            logger.debug("Deleting Relation:"
                    + " PLMid: " + plm.getProductListMappingId()
                    + " product: " + plm.getGusProduct().getProductName()
                    + " list: " + plm.getTrelloList().getListName()
                    + " status: " + plm.getGusStatus().toString());

            sess.beginTransaction();
            for(FilterSet fs : plm.getFilters()) {
                for(FilterItem fi : fs.getFilterItems()) {
                    sess.delete(fi);
                }
                sess.delete(fs);
            }

            sess.delete(plm);
            sess.getTransaction().commit();
            sess.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Lookup all users that are registered.
     * @return All ProjectConfigs that are known about
     */
    public List<ProjectConfig> getAllProjectConfigs() {
        Session sess = sessionFactory.openSession();
        List<ProjectConfig> pcs = sess.createQuery("from ProjectConfig").setTimeout(10).list();
        sess.close();
        return pcs;
    }

    /**
     * Lookup the ProjectConfig object from its ID
     * @param projectId ID that identifies the ProjectConfig
     * @return The object saved by that ID
     */
    public ProjectConfig getProjectConfig(long projectId) {
        Session sess = sessionFactory.openSession();
        List<Object[]> objarrs = sess.createQuery("from ProjectConfig pc left join pc.productListMappings join pc.gusLogin join pc.trelloLogin where pc.projectConfigId = :projectId")
            .setParameter("projectId", projectId)
            .list();
        ProjectConfig pc;
        if (objarrs.size() < 1) {
            // We can't find that project... how did you get an ID?
            pc = null;
        } else {
            pc = (ProjectConfig) (objarrs.get(0)[0]);
        }

        sess.close();
        return pc;
    }

    /**
     * Lookup the team IDs (names) of all the extra teams that a user
     * wants to recognize or synchronize.
     * @param projectId The user's ID
     * @return Team IDs that are desired to be syncable.
     */
    public List<String> getExtraTeamAssociations(long projectId) {
        ProjectConfig pc = getProjectConfig(projectId);
        List<String> teams = new ArrayList<String>();
        logger.debug("Getting team associations for id " + projectId);
        logger.debug("Counted " + pc.getExtraTeamAssociations().size() + " ExtraTeamAssociations");
        for(ExtraTeamAssociation eta : pc.getExtraTeamAssociations()) {
            teams.add(eta.getGusTeam().getTeamName());
        }
        logger.debug("They are " + teams);
        return teams;
    }

    /**
     * Lookup a user's configuration by using a GUS Id.
     * @param gusUserId User ID from GUS
     * @return That user's configuration
     */
    public ProjectConfig getProjectForUserId(String gusUserId) {
        Session sess = sessionFactory.openSession();
        List<Object[]> pcs = sess.createQuery("from ProjectConfig pc join pc.gusLogin join pc.trelloLogin where pc.gusLogin.gusUserId = :gusUserId")
            .setParameter("gusUserId", gusUserId)
            .list();
        ProjectConfig pc = null;
        if(pcs.size() > 0) {
            pc = (ProjectConfig)(pcs.get(0)[0]);
        }

        sess.close();
        return pc;
    }

    /**
     * Add that a user wants to be able to sync with an extra team in GUS
     * @param projectId ProjectConfigId
     * @param teamName  Name of the team in GUS
     * @return The association object that was created
     */
    public ExtraTeamAssociation createExtraTeamAssociation(Long projectId, String teamName) {
        return createExtraTeamAssociation(getProjectConfig(projectId), teamName);
    }

    /**
     * Add that a user wants to be able to sync with an extra team in GUS
     * @param projectConfig The user's configuration
     * @param teamName  Name of the team in GUS
     * @return The association object that was created
     */
    public ExtraTeamAssociation createExtraTeamAssociation(ProjectConfig projectConfig, String teamName) {
        Session sess = sessionFactory.openSession();
        sess.beginTransaction();
        GusTeam gusTeam = lookupOrCreateTeam(sess, teamName);

        logger.debug("Creating ExtraTeamAssociation for " + teamName);
        ExtraTeamAssociation extraAssoc = new ExtraTeamAssociation(projectConfig, gusTeam);
        sess.save(extraAssoc);

        sess.getTransaction().commit();
        sess.close();

        // Update the object, which with eager loading, will include this new record
        refresh(projectConfig, projectConfig.getProjectConfigId());
        logger.debug("There are now " + projectConfig.getExtraTeamAssociations().size() + " ExtraTeamAssociations");
        return extraAssoc;
    }

    /**
     * Removes the specification that a user wants to sync with an extra team
     * @param projectId User's ID (ProjectConfig ID)
     * @param name Name of the team to forget
     * @return True upon success
     */
    public boolean deleteExtraTeamAssociation(Long projectId, String name) {
        ProjectConfig pc = getProjectConfig(projectId);
        for(ExtraTeamAssociation eta : pc.getExtraTeamAssociations()) {
            if(eta.getGusTeam().getTeamName().equals(name)) {
                deleteExtraTeamAssociation(eta);
                refresh(pc, projectId);
                getExtraTeamAssociations(projectId);
                return true;
            }
        }
        return false;
    }

    /**
     * Removes the specification that a user wants to sync with an extra team
     * @param eta Extra Team Association that will be deleted
     */
    public void deleteExtraTeamAssociation(ExtraTeamAssociation eta) {
        Session sess = sessionFactory.openSession();
        sess.beginTransaction();
        sess.delete(eta);
        sess.getTransaction().commit();
        sess.close();
    }

    /**
     * Tries to find the desired product-team. If it does not exist, it will be added
     * @param product  GUS Product ID
     * @param team  GUS Team ID
     * return The newly added or previously existing Product
     */
    public GusProduct lookupOrCreateProduct(String product, String team) {
        GusProduct gusProduct;
        Session sess = sessionFactory.openSession();
        sess.beginTransaction();
        List<Object[]> products = sess.createQuery(
                "from GusProduct gp join gp.gusTeam " +
                "where productName=:productName")
            .setString("productName", product)
            .list();

        if (products.size() == 0) {
            // We at least need to insert the product. Can we find the team?
            GusTeam gusTeam = lookupOrCreateTeam(team);

            // Add the product
            gusProduct = new GusProduct(product, gusTeam);
            sess.save(gusProduct);
        } else {
            gusProduct = (GusProduct) products.get(0)[0];
        }
        sess.getTransaction().commit();
        sess.close();

        // Make sure the parent object knows about this list object
        refresh(gusProduct.getGusTeam(), gusProduct.getGusTeam().getGusTeamId());

        return gusProduct;
    }

    /**
     * Tries to find the desired team. If it does not exist, it will be added
     * @param team  GUS Team ID
     * return The newly added or previously existing team
     */
    public GusTeam lookupOrCreateTeam(String team) {
        Session sess = sessionFactory.openSession();
        sess.beginTransaction();
        GusTeam gt = lookupOrCreateTeam(sess, team);
        sess.getTransaction().commit();
        sess.close();
        return gt;
    }
    /**
     * Meant to allow for conjunction with lookupOrCreateProduct, which already has an open session
     *
     * Tries to find the desired team. If it does not exist, it will be added
     * @param team  GUS Team ID
     * return The newly added or previously existing team
     */
    public GusTeam lookupOrCreateTeam(Session sess, String team) {
        GusTeam gusTeam;
        List<GusTeam> teams = (List<GusTeam>) sess.createQuery("from GusTeam where teamName=:teamName")
            .setParameter("teamName", team)
            .list();
        if (teams.size() == 0) {
            // We need to create the team
            gusTeam = new GusTeam(team);
            sess.save(gusTeam);
        } else {
            gusTeam = teams.get(0);
        }
        return gusTeam;
    }

    /**
     * Tries to find the desired list-board. If it does not exist, it will be added
     * @param listId    Trello List ID
     * @param boardId   Trello Board ID
     * @return The newly created or previously existing list
     */
    public TrelloList lookupOrCreateList(String listId, String boardId) {
        TrelloList trelloList;
        Session sess = sessionFactory.openSession();
        sess.beginTransaction();
        List<Object[]> lists = sess.createQuery(
                "from TrelloList tl join tl.trelloBoard " + 
                "where listName=:listName")
            .setString("listName", listId)
            .list();

        if (lists.size() == 0) {

            TrelloBoard trelloBoard = lookupOrCreateBoard(sess, boardId);
            trelloList = new TrelloList(listId, trelloBoard);
            sess.save(trelloList);

        } else {
            trelloList = (TrelloList)lists.get(0)[0];
        }

        sess.getTransaction().commit();
        sess.close();

        // Make sure the parent object knows about this list object
        refresh(trelloList.getTrelloBoard(), trelloList.getTrelloBoard().getTrelloBoardId());


        return trelloList;
    }

    /**
     * Tries to find the desired board. If it does not exist, it will be added
     * @param boardId   Trello Board ID
     * @return The newly created or previously existing board
     */
    public TrelloBoard lookupOrCreateBoard(String board) {
        Session sess = sessionFactory.openSession();
        sess.beginTransaction();
        TrelloBoard tb = lookupOrCreateBoard(sess, board);
        sess.getTransaction().commit();
        sess.close();
        return tb;
    }
    /**
     * Tries to find the desired board. If it does not exist, it will be added
     * Meant to be used in conjunction with lookupOrCreateList, which already has an open session
     * @param boardId   Trello Board ID
     * @return The newly created or previously existing board
     */
    public TrelloBoard lookupOrCreateBoard(Session sess, String board) {
        // We at least need to insert the list. Can we find the board?
        TrelloBoard trelloBoard;
        List<TrelloBoard> boards = (List<TrelloBoard>) sess.createQuery("from TrelloBoard where boardName=:boardName")
            .setParameter("boardName", board)
            .list();

        if (boards.size() == 0) {
            // Need to create the board, too
            trelloBoard = new TrelloBoard(board);
            sess.save(trelloBoard);
        } else {
            trelloBoard = boards.get(0);
        }
        return trelloBoard;
    }

    /**
     * WARNING: NOT INTENDED FUNCTIONALITY - ONLY MEANT FOR TESTING
     */
    void deleteList(TrelloList tl) {
        refresh(tl, tl.getTrelloListId());
        Session sess = sessionFactory.openSession();
        sess.beginTransaction();
        sess.delete(tl);
        sess.getTransaction().commit();
        sess.close();
    }

    /**
     * WARNING: NOT INTENDED FUNCTIONALITY - ONLY MEANT FOR TESTING
     */
    void deleteBoard(TrelloBoard tb) {
        refresh(tb, tb.getTrelloBoardId());
        Session sess = sessionFactory.openSession();
        sess.beginTransaction();
        for (TrelloList tl : tb.getTrelloLists()) {
            sess.delete(tl);
        }
        sess.delete(tb);
        sess.getTransaction().commit();
        sess.close();
    }

    /**
     * WARNING: NOT INTENDED FUNCTIONALITY - ONLY MEANT FOR TESTING
     */
    void deleteTeam(GusTeam gt) {
        refresh(gt, gt.getGusTeamId());
        Session sess = sessionFactory.openSession();
        sess.beginTransaction();
        for (GusProduct gp : gt.getGusProducts()) {
            sess.delete(gp);
        }
        sess.delete(gt);
        sess.getTransaction().commit();
        sess.close();
    }

    /**
     * WARNING: NOT INTENDED FUNCTIONALITY - ONLY MEANT FOR TESTING
     */
    void deleteProduct(GusProduct gp) {
        refresh(gp, gp.getGusProductId());
        Session sess = sessionFactory.openSession();
        sess.beginTransaction();
        sess.delete(gp);
        sess.getTransaction().commit();
        sess.close();
    }
}
