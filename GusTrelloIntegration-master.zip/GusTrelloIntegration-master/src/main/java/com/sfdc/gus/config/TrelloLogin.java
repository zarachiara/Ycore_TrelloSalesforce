package com.sfdc.gus.config;

import java.util.List;
import java.util.ArrayList;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.apache.commons.lang3.builder.HashCodeBuilder;

@Entity
@Table(name="trellologin", schema="configuration")
public class TrelloLogin {

    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    private long trelloLoginId;
    public long getTrelloLoginId() { return trelloLoginId; }
    // public void setTrelloLoginId(long id) { trelloLoginId = id; }

    private String accessToken;
    public String getAccessToken() { return accessToken; }

    public TrelloLogin() {}

    public TrelloLogin(String accessToken) {
        this.accessToken = accessToken;
    }

    
	// TODO: move this to project-specific config file
	// public static final String[] EXCLUDE_ITEMS_BEGINS_WITH = new String[] {"[lma]", "on-call", "[flapper]", "ai", "test com.force.platform"};
	// public static final String[] EXCLUDE_ITEMS_CONTAINS = new String[] {"-----", "partner bt"};

    @Override
    public String toString() {
        return "<trellologin "
            + "id=" + trelloLoginId + " "
            + "accesstoken=" + accessToken + " "
            + ">";
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder()
            .append(trelloLoginId)
            .append(accessToken)
            .toHashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) { return false; }
        if (obj == this) { return true; }
        if (obj.getClass() != getClass()) {
            return false;
        }
        TrelloLogin tlobj = (TrelloLogin) obj;
        return trelloLoginId == tlobj.getTrelloLoginId()
            && accessToken.equals(tlobj.getAccessToken());
    }

}
