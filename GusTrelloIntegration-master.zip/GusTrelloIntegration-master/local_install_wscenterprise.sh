mvn install:install-file -Dfile=lib/wsc_enterprisewsdl.jar -DgroupId=com.sforce -DartifactId=wsc_enterprisewsdl -Dversion=1.0 -Dpackaging=jar
