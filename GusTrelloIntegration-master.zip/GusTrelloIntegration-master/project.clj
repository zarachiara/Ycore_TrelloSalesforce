; Leiningen project file
;; (use 'clojure.core)
;; (def jvmargs (clojure.core/unquote (clojure.core/vec (clojure.core/unquote (clojure.core/str "-javaagent:/Users/mbuland/"
;;                         ".m2/repository/org/jacoco/org.jacoco.agent/0.7.1.201405082137/org.jacoco.agent-0.7.1.201405082137-runtime.jar="
;;                         "output=file,"
;;                         "destfile=target/jacoco.exec")))))

(defproject gus-trello-integration "0.1.0-SNAPSHOT"
  :description "Standalone java program that synchronizes GUS and Trello"
  :url "https://git.soma.salesforce.com/kherbig/GusTrelloIntegration"
  :license { ; TODO: EPL is almost guaranteed to NOT be the liscense we want
            :name "Eclipse Public License"
            :url "http://www.eclipse.org/legal/epl-v10.html"}
  :resource-paths ["src/main/resources"]

  :java-source-paths ["src/main/java" "src/test/java"]
  :junit ["src/test/java"]
  :jvm-opts ["-javaagent:lib/jacocoagent.jar=output=file,destfile=target/jacoco.exec"]

  :profiles { :test { :resource-paths ["src/test/resources"] } }
  :aliases {"test" ["with-profile" "test" "junit"]}

  :java-test-paths ["src/test/java"]
  :javac-options ["-source" "1.8" "-Xlint:deprecation"]
  :dependencies [[org.clojure/clojure "1.5.1"]
                 [org.freemarker/freemarker "2.3.20"]
                 [com.sparkjava/spark-core "2.0.1-SNAPSHOT"]
                 [org.apache.httpcomponents/httpclient "4.4-alpha1"]
                 [org.apache.httpcomponents/httpcore "4.4-alpha1"]
                 [commons-codec/commons-codec "1.7"]
                 [org.apache.commons/commons-lang3 "3.3.2"]
                 [commons-logging/commons-logging "1.1.1"]
                 [org.json/json "20090211"]
                 [junit/junit "4.11"]
                 [com.force.api/force-wsc "22.0.0"]
                 [log4j/log4j "1.2.16"]
                 [org.slf4j/slf4j-nop "1.7.7"]
                 [com.sforce/wsc_enterprisewsdl "1.0"]
                 [net.sf.json-lib/json-lib "2.4" :classifier "jdk15"]
                 [org.postgresql/postgresql "9.3-1101-jdbc41"]
                 [org.hibernate/hibernate-core "4.3.5.Final"]
                 [org.jacoco/org.jacoco.core   "0.7.1.201405082137"]
                 [org.jacoco/org.jacoco.report "0.7.1.201405082137"]
                 [org.hamcrest/hamcrest-all "1.3"]
                ]
  :main com.sfdc.gus.Main
  :javac-target 1.8
  :target-path "target/%s"
  :plugins [[lein-localrepo "0.5.3"]
            [lein-junit "1.1.6"]
            [lein-pprint "1.1.1"]
           ]
  ; Maven plugins are unusable by Leiningen >.<
  ; plugins here will get placed in the pom, and are therefore usable by maven
  ; :pom-plugins [[org.jacoco/jacoco-maven-plugin "0.7.1.201405082137"] ]
  )
