# Gus Trello Integration

Gus is a great work system that provides a rich interface for work items but is
primarily targetted at a sprint work flow. Trello is a visually pleasing system that provides
similar functionality as Gus but more with a kanban work flow. The aim of this project
is to use the interface of Trello but the history and work items in Gus by continually syncing them.

For the time being, it is assumed this app will only run within salesforce until development
is completed. As such, it's assumed that the reader is an employee of salesforce and has
access to git.soma.salesforce.com .

The guidelines this project was designed to follow can be found at:
https://docs.google.com/a/salesforce.com/document/d/1294MUMBXGp9VTaKBW1hsF_8FAazu1gjdxds9Fmi3r3U/edit
(Owned by Kyle Herbig)

## Installation

###Prerequisites: 
* Java 8
    * (http://www.webupd8.org/2012/09/install-oracle-java-8-in-ubuntu-via-ppa.html "Using apt repository")
    * OR (http://www.oracle.com/technetwork/java/javase/downloads/jdk8-downloads-2133151.html "Direct install from Oracle")
* Maven
    * Use maven from package manager
    * Development was done with Maven 3.2.1 but all Maven 3.x.x should work
* Leinegen 2.X
    * Do NOT use the leiningen in the debian/ubuntu repositories, it will NOT work. (http://leiningen.org/#install)
    * Development was done with version 2.3.4
* Git (http://git-scm.com/book/en/Getting-Started-Installing-Git)
* Access to git.soma.salesforce.com (SFM is required)

### Post Prerequisites:

#### Spark Java
Spark Java (http://www.sparkjava.com/) is used as our web framework. We use a modified version
that supports starting up multiple servers on different ports simultaneously. To download and
install for a Linux/Mac machine, open up a terminal, navigate to an appropriate workspace, and run:

<pre>> git clone https://git.soma.salesforce.com/isv/spark.git
> cd spark/
> mvn install</pre>

#### Gus Trello Integration
This will ensure that the appropriate version of Spark is in your local maven repository. To download 
and install the app itself for Linux/Mac, run:

<code>> git clone https://git.soma.salesforce.com/isv/GusTrelloIntegration.git</code>

#### PostgreSQL 9.X
The project comes configured to connect to a postgreSQL 9.4b1 server on mbuland-wsl. Following
are instructions to setup a fresh postgreSQL server in Ubuntu 12.04.

1. <code>> sudo apt-get install postgresql</code>
2. Optional: add address listeners to /etc/postgresql/9.1/main/pg_hba.conf
<pre># SFDC VPN
host    all             all             10.126.148.0/24         md5
</pre>
    This allows any one with an IP like 10.126.148.XXX to connect to the postgresql server.
    If you want the GusTrelloIntegration server and the postgresql server to exist
    on the same machine, this is not necesary. If you try to connect to the postgresql server, and
    get a "server does not listen" error, it indicates that the pg_hba.conf is not configured to
    allow the client to connect.
3. <code>cd <gustrellodir>/postgresql</code>
4. On nearly all SFDC liunx installs, the directory you clone the GusTrelloIntegration project to,
    the postgres user will not have read-access to the postgresql files, so we just need to set those
    files to be readable, and the directory to be enterable (executable).
    <pre>> chmod -R a+r .
    > chmod a+x .</pre>
4. <code>> ./postgresql_setup.sh</code>
    * Just a warning, it's a fairly basic script, so you HAVE to run it from the postgresql directory
    * sudo password is SSO, and I'm still unsure about whether the postgres user uses SSO or not.
5. change <gustrellodir>/src/main/resources/hibernate.cfg.xml to reflect the new database (the script will output
    the database URL each time a database is created
6. Optional: set the test database URL in src/test/resources/hibernate.cfg.xml

Extra tips
* postgres schema to DDL: pg_dump -sc -U trellogususer -W trellogus -h localhost > schema.sql

#### Connected App

GUS currently exists inside the production auth pool, which means we can have an org
on prod with a connected app, and can use that to gain authentication to GUS with an OAuth flow.

0. Have an org in a prod instance. ex. na17
1. Setup > Create > Apps > Connected Apps > New
2. Fill in all the required fields, and try to pick something descriptive for
    the App Name. ex. Gus Trello Integration. This App Name will appear when a
    user creates an account in the GusTrelloIntegration app.
3. Enable OAuth Settings
4. Set the Callback URL to https://<machineWithGusTrelloIntegration>:4567/sfcallback
5. We need these OAuth scopes:
    * Access and manage your data (api)
    * Perform requests on your behalf at any time (refresh_token, offline_access)
6. Save, then you can now get the Consumer Key and Consumer Secret from the connected app for use
    in GusTrelloIntegration

### Testing
Both the Spark Java and the GusTrelloIntegration have tests that should be run. For the Spark Java,
navigate to the spark/ directory and run:

<code>> mvn test</code>

For the GusTrelloIntegration, navigate to GusTrelloIntegration/ and run:

<code>> lein test</code>

To check code coverage of the GusTrelloIntegration after testing, run:

<code>> lein run coverage </code>

This command will generate html files located in GusTrelloIntegration/target/coveragereport/ . A 
good starting place to look at the coverage report would be <code>index.html</code>.

## Usage

### Startup

To start up the GusTrellointergation server, navigate to GusTrelloIntegration/ and run:

<code>> lein run web </code>

It will then ask for an Encryption Passphrase. For development, we used:

<code>Encryption Passphrase? L1nuxRocks! </code>

Other global information that is required (from a connected app):
<code>> New client_id: </code>
We used: 3MVG9xOCXq4ID1uG_7ohxy5543Jzfy2_DbkOqXLSVfkQEVor4dkqUjowpucsmZzpWq1AvXHM_JB2E31usOJCo

<code>> New client_secret: </code>
We used: 8331138368655338432

Note: Literally any connected app on any org will work.

This will start a Spark server on port <code>4567</code> where users can signup, login, and setup
their preferences for syncing between Gus and Trello. Instructions on how to use the App should
appear after first signup.

### Signup/Register

After startup, go to <code>http://localhost:4567</code> and you'll be greeted with this page:
![Login](/src/main/resources/assets/images/Screenshots/login_screen.png)

To create a new user, hit the <code>New User</code> button and you'll be redirected to:
![Register](/src/main/resources/assets/images/Screenshots/register_screen_1.png)

Since this App is designed to integrate both Gus and Trello, we need the Gus Login Credentials. These
take the form of &lt;username&gt;@gus.com with your SSO password. Assuming you already have a Trello
account and have logged into it recently, clicking the <code>Get Trello Token</code> link will bring
you to:
![Trello Confirm](/src/main/resources/assets/images/Screenshots/trello_token_1.png)

This App will only ever create Trello cards associated with Gus work items and will never delete anything.
After confirming, you'll be shown your Trello token that allows our App read and write access to your Trello
boards:
![Trello Token](/src/main/resources/assets/images/Screenshots/trello_token_2.png)

Copy and paste this token into the register screen and click submit:
![Completed Registration Form](/src/main/resources/assets/images/Screenshots/register_screen_2.png)

First time logging in will redirect you to your profile page with instructions (everything after this screenshot)
as well as display what Gus teams you're on, what products are used by those teams, and what Trello boards you
are a part of:
![Profile 1](/src/main/resources/assets/images/Screenshots/profile_1.png)
<hr/>
![Profile 2](/src/main/resources/assets/images/Screenshots/profile_2.png)

You also have the option to decide at what time intervals you wish the App to sync your Trello cards and Gus work
items. Every time interval, a thread will query both Gus and Trello for the work items and cards respectively as
your user and attempt to update cards that are already synchronized or create work items or cards for items that
aren't already synchronized. If you know cards will only be created once per day and that updates aren't likely to happen
very often, you can lengthen the sync time to lighten the load on the server, but it's up to you.

In order to start syncing things between your Gus team and Trello boards, click on the <code>View Relations</code>
button on the top and you'll be brought to:
![Relations 1](/src/main/resources/assets/images/Screenshots/relations_1.png)

A Relation is a relationship between a Gus team and three Trello lists from the same board. A Relationship will sync
a Gus work item status (New, In Progress, Closed) with a Trello list. When a Trello card is created in a Trello list
that is being monitored, a new Gus work item will be created with the associated status and other details. To create
a Relation, click the <code>New Relation</code> button:
![Relations 2](/src/main/resources/assets/images/Screenshots/relations_2.png)

The gray boxes for the Gus teams and the Trello lists are draggable. Populate the respective boxes with appropriate the Gus team
or Trello list by dragging the appropriate gray box to the empty white box on the Relation. Also select a Gus product tag that will
be associated with all Gus work items created by Trello cards.
Finally, decide on some filtering criteria you wish to use to sync certain cards.

It's popular to use "separation" cards
on Trello that are a bunch of dashes (<code>-------------</code>). Adding <code>----------------</code> to the Trello
filter out text area will cause the Relation to skip over syncing Trello cards whose name contains <code>----------------</code>.
These keywords used for filtering are all treated as regexs, which allows for a large degree of flexibility for filtering.
If you wish to not sync any Gus work items except for a select few, you can set the Gus filter out to <code>.*</code> and then
add the specific keywords you wish to filter in by to the Gus select by text area. Keywords are newline delimited, so multiple
can be added. The select by keywords are always filtered after the filter out keywords have already been run and take precedence
to whether a card will be synced or not.
![Relations 3](/src/main/resources/assets/images/Screenshots/relations_3.png)

Clicking <code>Submit</code> will enter that relation into the database and will be
synced based on your sync time preferences:
![Relations 4](/src/main/resources/assets/images/Screenshots/relations_4.png)

### Running Tests

Both the Spark Java and the GusTrelloIntegration have tests that should be run. For the Spark Java,
navigate to the spark/ directory and run:

<code>> mvn test</code>

For the GusTrelloIntegration, navigate to GusTrelloIntegration/ and run:

<code>> lein test</code>

To check code coverage of the GusTrelloIntegration after testing, run:

<code>> lein run coverage </code>

This command will generate html files located in GusTrelloIntegration/target/coveragereport/ . A
good starting place to look at the coverage report would be <code>index.html</code>. Do note that
the framework we are using for coverage works on the byte-code level, and not on a per-line basis.

## Development Comments
* Webpages are being served up by Spark (http://www.sparkjava.com/) with the actualy html being generated by Freemarker (http://freemarker.org/). All Freemarker templates are stored in the templates/ directory in root of this project.

## Bugs

* Under rare conditions involving deleting a relation and attempting to create a new one in the same session,
the db object can become null and a NullPointerException will be thrown on line 477 in IntegrationFrontEnd.java
( db.addRelationForUser(projectId, req); ). Unable to reproduce the bug consistently.

* Adding a new ExtraTeamAssociation to a ProjectConfig and then querying for it afterwards can result in multiple
of the same ETA returned. For instance, adding a single team has returned that same team 6 times in future queries,
overpopulating the list of Gus Teams. Problem exists in hibernate or our usage of it.

## Future Features

* Use OAuth flow when logging into the app (this is different from when making an account)
* Sync more than just the card/work item description/details
    * Sync name/subject
    * Sync points
    * Sync checklists/tasks
    * Sync labels
    * Sync comments
    * Sync position/rank
    * Others
* Correct the backlog synchronization (currently the backlog is only defined by the status 'New' in Gus)
* Identify a better place to store the Hash info for the cards/work items (Additional_Details__c is a field that can be explored for WI)
* Handle work item owner, QE, Test, etc. for Gus work items to Trello cards
* Have an option to grab all work items/cards instead of just your cards that you created
    * In the event that work item/card created by someone who will not be using the app but still wants to be represented by team leader in other system.
* Conditionally set which system is correct for some statuses but not others
    * Trello should be the correct one most of the time
    * Use case where something sets Gus status to QA In Progress (or any status) and Trello should be updated instead
* Switch to a more administrator-role model, where a scrum master sets up a synchronization config, and all the people in those teams are only required to login and say they are part of that team
* Sync more than just 3 lists/statuses: allow for 1 list for each GUS Status
* Tag Trello Cards with Gus tags (User Story, Bug, etc.)
* Create an Error Resolution page where conflicts can be managed (where both GWI and TC were changed, which one is correct?)
