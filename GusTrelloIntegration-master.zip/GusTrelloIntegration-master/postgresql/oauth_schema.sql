--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- Name: configuration; Type: SCHEMA; Schema: -; Owner: trellogususer
--

CREATE SCHEMA configuration;


ALTER SCHEMA configuration OWNER TO trellogususer;

SET search_path = public, pg_catalog;


SET search_path = configuration, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: extrateamassociation; Type: TABLE; Schema: configuration; Owner: trellogususer; Tablespace: 
--

CREATE TABLE extrateamassociation (
    extrateamassociationid integer NOT NULL,
    projectconfigid integer NOT NULL,
    gusteamid integer NOT NULL
);


ALTER TABLE extrateamassociation OWNER TO trellogususer;

--
-- Name: TABLE extrateamassociation; Type: COMMENT; Schema: configuration; Owner: trellogususer
--

COMMENT ON TABLE extrateamassociation IS 'If a user wants to synchronize a team that they are not normally a part of, they will add a record in this table, indicating that the team is also to be included. This table is meant to be only extra mappings that are not normaly found in GUS.';


--
-- Name: extrateamassociation_extrateamassociationid_seq; Type: SEQUENCE; Schema: configuration; Owner: trellogususer
--

CREATE SEQUENCE extrateamassociation_extrateamassociationid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE extrateamassociation_extrateamassociationid_seq OWNER TO trellogususer;

--
-- Name: extrateamassociation_extrateamassociationid_seq; Type: SEQUENCE OWNED BY; Schema: configuration; Owner: trellogususer
--

ALTER SEQUENCE extrateamassociation_extrateamassociationid_seq OWNED BY extrateamassociation.extrateamassociationid;


--
-- Name: filteritem; Type: TABLE; Schema: configuration; Owner: trellogususer; Tablespace: 
--

CREATE TABLE filteritem (
    filteritemid integer NOT NULL,
    keyword character varying(255) NOT NULL,
    filtersetid integer NOT NULL
);


ALTER TABLE filteritem OWNER TO trellogususer;

--
-- Name: filteritem_filteritemid_seq; Type: SEQUENCE; Schema: configuration; Owner: trellogususer
--

CREATE SEQUENCE filteritem_filteritemid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE filteritem_filteritemid_seq OWNER TO trellogususer;

--
-- Name: filteritem_filteritemid_seq; Type: SEQUENCE OWNED BY; Schema: configuration; Owner: trellogususer
--

ALTER SEQUENCE filteritem_filteritemid_seq OWNED BY filteritem.filteritemid;


--
-- Name: filterset; Type: TABLE; Schema: configuration; Owner: trellogususer; Tablespace: 
--

CREATE TABLE filterset (
    filtersetid integer NOT NULL,
    productlistmappingid integer NOT NULL,
    source integer,
    ruletype integer
);


ALTER TABLE filterset OWNER TO trellogususer;

--
-- Name: filterset_filtersetid_seq; Type: SEQUENCE; Schema: configuration; Owner: trellogususer
--

CREATE SEQUENCE filterset_filtersetid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE filterset_filtersetid_seq OWNER TO trellogususer;

--
-- Name: filterset_filtersetid_seq; Type: SEQUENCE OWNED BY; Schema: configuration; Owner: trellogususer
--

ALTER SEQUENCE filterset_filtersetid_seq OWNED BY filterset.filtersetid;


--
-- Name: globalkvconfig; Type: TABLE; Schema: configuration; Owner: trellogususer; Tablespace: 
--

CREATE TABLE globalkvconfig (
    key character varying(255) NOT NULL,
    value character varying(255)
);


ALTER TABLE globalkvconfig OWNER TO trellogususer;

--
-- Name: TABLE globalkvconfig; Type: COMMENT; Schema: configuration; Owner: trellogususer
--

COMMENT ON TABLE globalkvconfig IS 'Key-value store for global config';


--
-- Name: guslogin; Type: TABLE; Schema: configuration; Owner: trellogususer; Tablespace: 
--

CREATE TABLE guslogin (
    gusloginid integer NOT NULL,
    gususerid character varying(255),
    refreshtoken character varying(4098)
);


ALTER TABLE guslogin OWNER TO trellogususer;


--
-- Name: guslogin_gusloginid_seq; Type: SEQUENCE; Schema: configuration; Owner: trellogususer
--

CREATE SEQUENCE guslogin_gusloginid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE guslogin_gusloginid_seq OWNER TO trellogususer;

--
-- Name: guslogin_gusloginid_seq; Type: SEQUENCE OWNED BY; Schema: configuration; Owner: trellogususer
--

ALTER SEQUENCE guslogin_gusloginid_seq OWNED BY guslogin.gusloginid;


--
-- Name: gusproduct; Type: TABLE; Schema: configuration; Owner: trellogususer; Tablespace: 
--

CREATE TABLE gusproduct (
    gusproductid integer NOT NULL,
    productname character varying(255),
    gusteamid integer NOT NULL
);


ALTER TABLE gusproduct OWNER TO trellogususer;

--
-- Name: gusproduct_gusproductid_seq; Type: SEQUENCE; Schema: configuration; Owner: trellogususer
--

CREATE SEQUENCE gusproduct_gusproductid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE gusproduct_gusproductid_seq OWNER TO trellogususer;

--
-- Name: gusproduct_gusproductid_seq; Type: SEQUENCE OWNED BY; Schema: configuration; Owner: trellogususer
--

ALTER SEQUENCE gusproduct_gusproductid_seq OWNED BY gusproduct.gusproductid;


--
-- Name: gusteam; Type: TABLE; Schema: configuration; Owner: trellogususer; Tablespace: 
--

CREATE TABLE gusteam (
    gusteamid integer NOT NULL,
    teamname character varying(255)
);


ALTER TABLE gusteam OWNER TO trellogususer;

--
-- Name: gusteam_gusteamid_seq; Type: SEQUENCE; Schema: configuration; Owner: trellogususer
--

CREATE SEQUENCE gusteam_gusteamid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE gusteam_gusteamid_seq OWNER TO trellogususer;

--
-- Name: gusteam_gusteamid_seq; Type: SEQUENCE OWNED BY; Schema: configuration; Owner: trellogususer
--

ALTER SEQUENCE gusteam_gusteamid_seq OWNED BY gusteam.gusteamid;


--
-- Name: productlistmapping; Type: TABLE; Schema: configuration; Owner: trellogususer; Tablespace: 
--

CREATE TABLE productlistmapping (
    productlistmappingid integer NOT NULL,
    projectconfigid integer,
    gusproductid integer NOT NULL,
    trellolistid integer NOT NULL,
    gusstatus integer,
    syncenabled boolean NOT NULL
);


ALTER TABLE productlistmapping OWNER TO trellogususer;

--
-- Name: productlistmapping_productlistmappingid_seq; Type: SEQUENCE; Schema: configuration; Owner: trellogususer
--

CREATE SEQUENCE productlistmapping_productlistmappingid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE productlistmapping_productlistmappingid_seq OWNER TO trellogususer;

--
-- Name: productlistmapping_productlistmappingid_seq; Type: SEQUENCE OWNED BY; Schema: configuration; Owner: trellogususer
--

ALTER SEQUENCE productlistmapping_productlistmappingid_seq OWNED BY productlistmapping.productlistmappingid;


--
-- Name: projectconfig; Type: TABLE; Schema: configuration; Owner: trellogususer; Tablespace: 
--

CREATE TABLE projectconfig (
    projectconfigid integer NOT NULL,
    gusloginid integer NOT NULL,
    trellologinid integer NOT NULL,
    syncfrequency integer NOT NULL
);


ALTER TABLE projectconfig OWNER TO trellogususer;

--
-- Name: projectconfig_projectconfigid_seq; Type: SEQUENCE; Schema: configuration; Owner: trellogususer
--

CREATE SEQUENCE projectconfig_projectconfigid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE projectconfig_projectconfigid_seq OWNER TO trellogususer;

--
-- Name: projectconfig_projectconfigid_seq; Type: SEQUENCE OWNED BY; Schema: configuration; Owner: trellogususer
--

ALTER SEQUENCE projectconfig_projectconfigid_seq OWNED BY projectconfig.projectconfigid;


--
-- Name: trelloboard; Type: TABLE; Schema: configuration; Owner: trellogususer; Tablespace: 
--

CREATE TABLE trelloboard (
    trelloboardid integer NOT NULL,
    boardname character varying(255)
);


ALTER TABLE trelloboard OWNER TO trellogususer;

--
-- Name: trelloboard_trelloboardid_seq; Type: SEQUENCE; Schema: configuration; Owner: trellogususer
--

CREATE SEQUENCE trelloboard_trelloboardid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE trelloboard_trelloboardid_seq OWNER TO trellogususer;

--
-- Name: trelloboard_trelloboardid_seq; Type: SEQUENCE OWNED BY; Schema: configuration; Owner: trellogususer
--

ALTER SEQUENCE trelloboard_trelloboardid_seq OWNED BY trelloboard.trelloboardid;


--
-- Name: trellolist; Type: TABLE; Schema: configuration; Owner: trellogususer; Tablespace: 
--

CREATE TABLE trellolist (
    trellolistid integer NOT NULL,
    listname character varying(255),
    trelloboardid integer
);


ALTER TABLE trellolist OWNER TO trellogususer;

--
-- Name: trellolist_trellolistid_seq; Type: SEQUENCE; Schema: configuration; Owner: trellogususer
--

CREATE SEQUENCE trellolist_trellolistid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE trellolist_trellolistid_seq OWNER TO trellogususer;

--
-- Name: trellolist_trellolistid_seq; Type: SEQUENCE OWNED BY; Schema: configuration; Owner: trellogususer
--

ALTER SEQUENCE trellolist_trellolistid_seq OWNED BY trellolist.trellolistid;


--
-- Name: trellologin; Type: TABLE; Schema: configuration; Owner: trellogususer; Tablespace: 
--

CREATE TABLE trellologin (
    trellologinid integer NOT NULL,
    accesstoken character varying(255)
);


ALTER TABLE trellologin OWNER TO trellogususer;

--
-- Name: trellologin_trellologinid_seq; Type: SEQUENCE; Schema: configuration; Owner: trellogususer
--

CREATE SEQUENCE trellologin_trellologinid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE trellologin_trellologinid_seq OWNER TO trellogususer;

--
-- Name: trellologin_trellologinid_seq; Type: SEQUENCE OWNED BY; Schema: configuration; Owner: trellogususer
--

ALTER SEQUENCE trellologin_trellologinid_seq OWNED BY trellologin.trellologinid;


--
-- Name: extrateamassociationid; Type: DEFAULT; Schema: configuration; Owner: trellogususer
--

ALTER TABLE ONLY extrateamassociation ALTER COLUMN extrateamassociationid SET DEFAULT nextval('extrateamassociation_extrateamassociationid_seq'::regclass);


--
-- Name: filteritemid; Type: DEFAULT; Schema: configuration; Owner: trellogususer
--

ALTER TABLE ONLY filteritem ALTER COLUMN filteritemid SET DEFAULT nextval('filteritem_filteritemid_seq'::regclass);


--
-- Name: filtersetid; Type: DEFAULT; Schema: configuration; Owner: trellogususer
--

ALTER TABLE ONLY filterset ALTER COLUMN filtersetid SET DEFAULT nextval('filterset_filtersetid_seq'::regclass);


--
-- Name: gusloginid; Type: DEFAULT; Schema: configuration; Owner: trellogususer
--

ALTER TABLE ONLY guslogin ALTER COLUMN gusloginid SET DEFAULT nextval('guslogin_gusloginid_seq'::regclass);


--
-- Name: gusproductid; Type: DEFAULT; Schema: configuration; Owner: trellogususer
--

ALTER TABLE ONLY gusproduct ALTER COLUMN gusproductid SET DEFAULT nextval('gusproduct_gusproductid_seq'::regclass);


--
-- Name: gusteamid; Type: DEFAULT; Schema: configuration; Owner: trellogususer
--

ALTER TABLE ONLY gusteam ALTER COLUMN gusteamid SET DEFAULT nextval('gusteam_gusteamid_seq'::regclass);


--
-- Name: productlistmappingid; Type: DEFAULT; Schema: configuration; Owner: trellogususer
--

ALTER TABLE ONLY productlistmapping ALTER COLUMN productlistmappingid SET DEFAULT nextval('productlistmapping_productlistmappingid_seq'::regclass);


--
-- Name: projectconfigid; Type: DEFAULT; Schema: configuration; Owner: trellogususer
--

ALTER TABLE ONLY projectconfig ALTER COLUMN projectconfigid SET DEFAULT nextval('projectconfig_projectconfigid_seq'::regclass);


--
-- Name: trelloboardid; Type: DEFAULT; Schema: configuration; Owner: trellogususer
--

ALTER TABLE ONLY trelloboard ALTER COLUMN trelloboardid SET DEFAULT nextval('trelloboard_trelloboardid_seq'::regclass);


--
-- Name: trellolistid; Type: DEFAULT; Schema: configuration; Owner: trellogususer
--

ALTER TABLE ONLY trellolist ALTER COLUMN trellolistid SET DEFAULT nextval('trellolist_trellolistid_seq'::regclass);


--
-- Name: trellologinid; Type: DEFAULT; Schema: configuration; Owner: trellogususer
--

ALTER TABLE ONLY trellologin ALTER COLUMN trellologinid SET DEFAULT nextval('trellologin_trellologinid_seq'::regclass);


--
-- Name: boardlistmappingid_pk; Type: CONSTRAINT; Schema: configuration; Owner: trellogususer; Tablespace: 
--

ALTER TABLE ONLY productlistmapping
    ADD CONSTRAINT boardlistmappingid_pk PRIMARY KEY (productlistmappingid);


--
-- Name: filteritemid_pk; Type: CONSTRAINT; Schema: configuration; Owner: trellogususer; Tablespace: 
--

ALTER TABLE ONLY filteritem
    ADD CONSTRAINT filteritemid_pk PRIMARY KEY (filteritemid);


--
-- Name: filtersetid_pk; Type: CONSTRAINT; Schema: configuration; Owner: trellogususer; Tablespace: 
--

ALTER TABLE ONLY filterset
    ADD CONSTRAINT filtersetid_pk PRIMARY KEY (filtersetid);


--
-- Name: gusconfig_pk; Type: CONSTRAINT; Schema: configuration; Owner: trellogususer; Tablespace: 
--

ALTER TABLE ONLY guslogin
    ADD CONSTRAINT gusconfig_pk PRIMARY KEY (gusloginid);


--
-- Name: guslogin_unique_gususerids; Type: CONSTRAINT; Schema: configuration; Owner: trellogususer; Tablespace: 
--

ALTER TABLE ONLY guslogin
    ADD CONSTRAINT guslogin_unique_gususerids UNIQUE (gususerid);


--
-- Name: gusproductid_pk; Type: CONSTRAINT; Schema: configuration; Owner: trellogususer; Tablespace: 
--

ALTER TABLE ONLY gusproduct
    ADD CONSTRAINT gusproductid_pk PRIMARY KEY (gusproductid);


--
-- Name: gussprintid_pk; Type: CONSTRAINT; Schema: configuration; Owner: trellogususer; Tablespace: 
--

ALTER TABLE ONLY gusteam
    ADD CONSTRAINT gussprintid_pk PRIMARY KEY (gusteamid);


--
-- Name: key_pk; Type: CONSTRAINT; Schema: configuration; Owner: trellogususer; Tablespace: 
--

ALTER TABLE ONLY globalkvconfig
    ADD CONSTRAINT key_pk PRIMARY KEY (key);


--
-- Name: project_team_extra_association_pk; Type: CONSTRAINT; Schema: configuration; Owner: trellogususer; Tablespace: 
--

ALTER TABLE ONLY extrateamassociation
    ADD CONSTRAINT project_team_extra_association_pk PRIMARY KEY (extrateamassociationid);


--
-- Name: projectconfig_pk; Type: CONSTRAINT; Schema: configuration; Owner: trellogususer; Tablespace: 
--

ALTER TABLE ONLY projectconfig
    ADD CONSTRAINT projectconfig_pk PRIMARY KEY (projectconfigid);


--
-- Name: trelloboard_pk; Type: CONSTRAINT; Schema: configuration; Owner: trellogususer; Tablespace: 
--

ALTER TABLE ONLY trelloboard
    ADD CONSTRAINT trelloboard_pk PRIMARY KEY (trelloboardid);


--
-- Name: trellolistid_pk; Type: CONSTRAINT; Schema: configuration; Owner: trellogususer; Tablespace: 
--

ALTER TABLE ONLY trellolist
    ADD CONSTRAINT trellolistid_pk PRIMARY KEY (trellolistid);


--
-- Name: trellologinid_pk; Type: CONSTRAINT; Schema: configuration; Owner: trellogususer; Tablespace: 
--

ALTER TABLE ONLY trellologin
    ADD CONSTRAINT trellologinid_pk PRIMARY KEY (trellologinid);


--
-- Name: fki_gusproduct_gusteam_fk; Type: INDEX; Schema: configuration; Owner: trellogususer; Tablespace: 
--

CREATE INDEX fki_gusproduct_gusteam_fk ON gusproduct USING btree (gusteamid);


--
-- Name: fki_projectconfig_guslogin_fk; Type: INDEX; Schema: configuration; Owner: trellogususer; Tablespace: 
--

CREATE INDEX fki_projectconfig_guslogin_fk ON projectconfig USING btree (gusloginid);


--
-- Name: fki_projectconfig_trellologinid_fk; Type: INDEX; Schema: configuration; Owner: trellogususer; Tablespace: 
--

CREATE INDEX fki_projectconfig_trellologinid_fk ON projectconfig USING btree (trellologinid);


--
-- Name: filteritem_filterset_pk; Type: FK CONSTRAINT; Schema: configuration; Owner: trellogususer
--

ALTER TABLE ONLY filteritem
    ADD CONSTRAINT filteritem_filterset_pk FOREIGN KEY (filtersetid) REFERENCES filterset(filtersetid);


--
-- Name: filterset_productlistmapping_fk; Type: FK CONSTRAINT; Schema: configuration; Owner: trellogususer
--

ALTER TABLE ONLY filterset
    ADD CONSTRAINT filterset_productlistmapping_fk FOREIGN KEY (productlistmappingid) REFERENCES productlistmapping(productlistmappingid);


--
-- Name: gusproduct_gusteam_fk; Type: FK CONSTRAINT; Schema: configuration; Owner: trellogususer
--

ALTER TABLE ONLY gusproduct
    ADD CONSTRAINT gusproduct_gusteam_fk FOREIGN KEY (gusteamid) REFERENCES gusteam(gusteamid);


--
-- Name: gusteam_extraassociation_fk; Type: FK CONSTRAINT; Schema: configuration; Owner: trellogususer
--

ALTER TABLE ONLY extrateamassociation
    ADD CONSTRAINT gusteam_extraassociation_fk FOREIGN KEY (gusteamid) REFERENCES gusteam(gusteamid);


--
-- Name: productlistmapping_gusproduct_fk; Type: FK CONSTRAINT; Schema: configuration; Owner: trellogususer
--

ALTER TABLE ONLY productlistmapping
    ADD CONSTRAINT productlistmapping_gusproduct_fk FOREIGN KEY (gusproductid) REFERENCES gusproduct(gusproductid);


--
-- Name: productlistmapping_projectconfig_fk; Type: FK CONSTRAINT; Schema: configuration; Owner: trellogususer
--

ALTER TABLE ONLY productlistmapping
    ADD CONSTRAINT productlistmapping_projectconfig_fk FOREIGN KEY (projectconfigid) REFERENCES projectconfig(projectconfigid);


--
-- Name: productlistmapping_trellolist_fk; Type: FK CONSTRAINT; Schema: configuration; Owner: trellogususer
--

ALTER TABLE ONLY productlistmapping
    ADD CONSTRAINT productlistmapping_trellolist_fk FOREIGN KEY (trellolistid) REFERENCES trellolist(trellolistid);


--
-- Name: projectconfig_guslogin_fk; Type: FK CONSTRAINT; Schema: configuration; Owner: trellogususer
--

ALTER TABLE ONLY projectconfig
    ADD CONSTRAINT projectconfig_guslogin_fk FOREIGN KEY (gusloginid) REFERENCES guslogin(gusloginid) DEFERRABLE;


--
-- Name: projectconfig_projecteamextraassociation_fk; Type: FK CONSTRAINT; Schema: configuration; Owner: trellogususer
--

ALTER TABLE ONLY extrateamassociation
    ADD CONSTRAINT projectconfig_projecteamextraassociation_fk FOREIGN KEY (projectconfigid) REFERENCES projectconfig(projectconfigid);


--
-- Name: projectconfig_trellologinid_fk; Type: FK CONSTRAINT; Schema: configuration; Owner: trellogususer
--

ALTER TABLE ONLY projectconfig
    ADD CONSTRAINT projectconfig_trellologinid_fk FOREIGN KEY (trellologinid) REFERENCES trellologin(trellologinid) DEFERRABLE;


--
-- Name: configuration; Type: ACL; Schema: -; Owner: trellogususer
--

REVOKE ALL ON SCHEMA configuration FROM PUBLIC;
REVOKE ALL ON SCHEMA configuration FROM trellogususer;
GRANT ALL ON SCHEMA configuration TO trellogususer;
GRANT USAGE ON SCHEMA configuration TO PUBLIC;


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- Name: extrateamassociation; Type: ACL; Schema: configuration; Owner: trellogususer
--

REVOKE ALL ON TABLE extrateamassociation FROM PUBLIC;
REVOKE ALL ON TABLE extrateamassociation FROM trellogususer;
GRANT ALL ON TABLE extrateamassociation TO trellogususer;
GRANT SELECT ON TABLE extrateamassociation TO PUBLIC;


--
-- Name: filteritem; Type: ACL; Schema: configuration; Owner: trellogususer
--

REVOKE ALL ON TABLE filteritem FROM PUBLIC;
REVOKE ALL ON TABLE filteritem FROM trellogususer;
GRANT ALL ON TABLE filteritem TO trellogususer;
GRANT SELECT ON TABLE filteritem TO PUBLIC;


--
-- Name: filterset; Type: ACL; Schema: configuration; Owner: trellogususer
--

REVOKE ALL ON TABLE filterset FROM PUBLIC;
REVOKE ALL ON TABLE filterset FROM trellogususer;
GRANT ALL ON TABLE filterset TO trellogususer;
GRANT SELECT ON TABLE filterset TO PUBLIC;


--
-- Name: globalkvconfig; Type: ACL; Schema: configuration; Owner: trellogususer
--

REVOKE ALL ON TABLE globalkvconfig FROM PUBLIC;
REVOKE ALL ON TABLE globalkvconfig FROM trellogususer;
GRANT ALL ON TABLE globalkvconfig TO trellogususer;
GRANT SELECT ON TABLE globalkvconfig TO PUBLIC;


--
-- Name: guslogin; Type: ACL; Schema: configuration; Owner: trellogususer
--

REVOKE ALL ON TABLE guslogin FROM PUBLIC;
REVOKE ALL ON TABLE guslogin FROM trellogususer;
GRANT ALL ON TABLE guslogin TO trellogususer;
GRANT SELECT ON TABLE guslogin TO PUBLIC;


--
-- Name: gusproduct; Type: ACL; Schema: configuration; Owner: trellogususer
--

REVOKE ALL ON TABLE gusproduct FROM PUBLIC;
REVOKE ALL ON TABLE gusproduct FROM trellogususer;
GRANT ALL ON TABLE gusproduct TO trellogususer;
GRANT SELECT ON TABLE gusproduct TO PUBLIC;


--
-- Name: gusteam; Type: ACL; Schema: configuration; Owner: trellogususer
--

REVOKE ALL ON TABLE gusteam FROM PUBLIC;
REVOKE ALL ON TABLE gusteam FROM trellogususer;
GRANT ALL ON TABLE gusteam TO trellogususer;
GRANT SELECT ON TABLE gusteam TO PUBLIC;


--
-- Name: productlistmapping; Type: ACL; Schema: configuration; Owner: trellogususer
--

REVOKE ALL ON TABLE productlistmapping FROM PUBLIC;
REVOKE ALL ON TABLE productlistmapping FROM trellogususer;
GRANT ALL ON TABLE productlistmapping TO trellogususer;
GRANT SELECT ON TABLE productlistmapping TO PUBLIC;


--
-- Name: projectconfig; Type: ACL; Schema: configuration; Owner: trellogususer
--

REVOKE ALL ON TABLE projectconfig FROM PUBLIC;
REVOKE ALL ON TABLE projectconfig FROM trellogususer;
GRANT ALL ON TABLE projectconfig TO trellogususer;
GRANT SELECT ON TABLE projectconfig TO PUBLIC;


--
-- Name: trelloboard; Type: ACL; Schema: configuration; Owner: trellogususer
--

REVOKE ALL ON TABLE trelloboard FROM PUBLIC;
REVOKE ALL ON TABLE trelloboard FROM trellogususer;
GRANT ALL ON TABLE trelloboard TO trellogususer;
GRANT SELECT ON TABLE trelloboard TO PUBLIC;


--
-- Name: trellolist; Type: ACL; Schema: configuration; Owner: trellogususer
--

REVOKE ALL ON TABLE trellolist FROM PUBLIC;
REVOKE ALL ON TABLE trellolist FROM trellogususer;
GRANT ALL ON TABLE trellolist TO trellogususer;
GRANT SELECT ON TABLE trellolist TO PUBLIC;


--
-- Name: trellologin; Type: ACL; Schema: configuration; Owner: trellogususer
--

REVOKE ALL ON TABLE trellologin FROM PUBLIC;
REVOKE ALL ON TABLE trellologin FROM trellogususer;
GRANT ALL ON TABLE trellologin TO trellogususer;
GRANT SELECT ON TABLE trellologin TO PUBLIC;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: configuration; Owner: trellogususer
--

ALTER DEFAULT PRIVILEGES FOR ROLE trellogususer IN SCHEMA configuration REVOKE ALL ON TABLES  FROM PUBLIC;
ALTER DEFAULT PRIVILEGES FOR ROLE trellogususer IN SCHEMA configuration REVOKE ALL ON TABLES  FROM trellogususer;
ALTER DEFAULT PRIVILEGES FOR ROLE trellogususer IN SCHEMA configuration GRANT SELECT ON TABLES  TO PUBLIC;


--
-- PostgreSQL database dump complete
--

