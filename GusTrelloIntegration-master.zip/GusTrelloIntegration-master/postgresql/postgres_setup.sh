#!/bin/bash

# Authored by Matt Buland: mbuland@salesforce.com

# Script to help guide postgres setup

makeRole() {
    echo "Making the trellogususer role"
    sudo su postgres -c psql < trellogususer.sql
}

createdb() {
    echo "Creating database trellogus_$1"
    # $1 = database name
    sudo su postgres -c psql < "$1"_db.sql
}

loadschema() {
    echo "Loading schema $2 into database trellogus_$1"
    # $1 = database name
    # $2 = schema name
    # Avoid auth for schema deploy as trellogususer
    PGPASSWORD="L1nuxRocks!" psql -U trellogususer -d "trellogus_$1" -f "$2"_schema.sql
}

echo "Welcome to Matt's postgresql setup script for Gus-Trello Integration"
echo "Since the project has been fragmented to support OAuth flows in the future, there are now 2 schemas to choose from:"
echo "    Username and Password combination for Gus Login"
echo "    OAuth refresh token for Gus Login"
echo ""
echo "There are also two main databases you may need: a main database and a testing database"
echo ""
echo "Which schema would you like to use?"
echo "    1: Username/password"
echo "    2: OAuth"
echo ""
read schema
if [[ $schema != "1" && $schema != "2" ]]; then
    echo "I'm sorry Dave, I'm afraid I can't do that"
    exit -1
fi

echo "First trying to make the trellogususer role. If this script has already been run, this will fail. That's fine. We only need one trellogususer role"
makeRole

if [[ $schema == "1" ]]; then
    schema="unpw"
    db="unpw"
else
    schema="oauth"
    db="oauth"
fi
createdb "$db"
loadschema "$db" "$schema"

echo "Please set src/main/resource/hibernate.cfg.xml connection_url to: jdbc:postgresql://localhost/trellogus_$db"

echo ""
echo "Would you like to create a test database? [y/N]"
read testdb
if [[ "$testdb" == "y" || "$testdb" == "Y" ]]; then
    if [[ "$schema" == "1" ]]; then
        db="unpw_test"
        schema="unpw"
    else
        db="oauth_test"
        schema="oauth"
    fi

    createdb "$db"
    loadschema "$db" "$schema"
    echo "Please set src/test/resource/hibernate.cfg.xml connection_url to: jdbc:postgresql://localhost/trellogus_$db"
fi
